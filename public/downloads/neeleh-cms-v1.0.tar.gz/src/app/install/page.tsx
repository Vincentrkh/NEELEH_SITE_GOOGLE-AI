import { redirect } from "next/navigation";
import { isInstalled, getInstallInfo } from "@/lib/installer";
import { InstallerWizard } from "@/components/installer-wizard";

export const dynamic = "force-dynamic";

/**
 * صفحه نصب — /install
 *
 * اگر سیستم قبلاً نصب شده باشد (فایل .installed وجود دارد)،
 * به /login هدایت می‌شود.
 */
export default async function InstallPage() {
  if (isInstalled()) {
    const info = getInstallInfo();
    redirect(`/login?installed=${encodeURIComponent(info?.installedAt ?? "unknown")}`);
  }

  return (
    <main className="min-h-[100svh] bg-background">
      <InstallerWizard />
    </main>
  );
}
