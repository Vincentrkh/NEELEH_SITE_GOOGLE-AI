import { HomeInteractive } from "@/components/home-interactive";
import { FeaturedCoursesSection } from "@/components/home-featured-courses";
import { LatestPostsSection } from "@/components/home-latest-posts";
import { ConsultationSection } from "@/components/home-consultation";
import { SiteFooter } from "@/components/site-footer";

export const dynamic = "force-dynamic";

/**
 * صفحه اصلی آکادمی نیله.
 *
 * ساختار:
 * 1. HomeInteractive (client) — پورتفولیو تعاملی فعلی دست‌نخورده:
 *    Hero, WorkSection, AwardsSection, StickyName, Philosophy, Contact
 * 2. FeaturedCoursesSection (server) — ۳ دوره برجسته از دیتابیس
 * 3. ConsultationSection (server) — فرم مشاوره رایگان + آمار از دیتابیس
 * 4. LatestPostsSection (server) — ۳ مقاله اخیر از دیتابیس
 * 5. SiteFooter (server) — فوتر پویا با اطلاعات تماس از دیتابیس
 *
 * اگر هر بخشی در دیتابیس داده‌ای نداشت، آن بخش نمایش داده نمی‌شود
 * (به‌جای خطا) — این رفتار تضمین می‌کند سایت همیشه کار می‌کند.
 */
export default function Home() {
  return (
    <>
      <HomeInteractive />
      <FeaturedCoursesSection />
      <ConsultationSection />
      <LatestPostsSection />
      <SiteFooter />
    </>
  );
}
