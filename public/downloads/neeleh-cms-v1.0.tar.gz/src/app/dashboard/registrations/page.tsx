import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { RegistrationsTable } from "@/components/registrations-table";

export const dynamic = "force-dynamic";

export default async function DashboardRegistrationsPage() {
  const user = await getCurrentUser();
  const canUpdate = user?.permissions.includes("registration.update");
  const canDelete = user?.permissions.includes("registration.delete");
  const canExport = user?.permissions.includes("registration.export");

  const registrations = await db.registration.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      student: {
        select: { id: true, name: true, phone: true, email: true, field: true, education: true },
      },
      course: {
        select: { id: true, title: true, slug: true, price: true, tier: true },
      },
    },
  });

  return (
    <div className="space-y-8">
      <div>
        <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
          [ اصلی ]
        </p>
        <h1 className="text-3xl sm:text-4xl font-medium tracking-[-0.03em]">
          ثبت‌نام‌ها
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          مدیریت ثبت‌نام هنرجویان، تأیید/لغو، تغییر وضعیت پرداخت و خروجی اکسل.
        </p>
      </div>

      <RegistrationsTable
        initialRegistrations={registrations.map((r) => ({
          ...r,
          status: r.status as "PENDING" | "CONFIRMED" | "CANCELLED",
          paymentStatus: r.paymentStatus as "PAID" | "UNPAID",
        }))}
        canUpdate={canUpdate}
        canDelete={canDelete}
        canExport={canExport}
      />
    </div>
  );
}
