import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { LeadsTable } from "@/components/leads-table";
import { faNumber } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function DashboardLeadsPage() {
  const user = await getCurrentUser();
  const canUpdate = user?.permissions.includes("lead.update");
  const canDelete = user?.permissions.includes("lead.delete");

  const [leads, newCount, contactedCount, convertedCount] = await Promise.all([
    db.lead.findMany({ orderBy: { createdAt: "desc" } }),
    db.lead.count({ where: { status: "NEW" } }),
    db.lead.count({ where: { status: "CONTACTED" } }),
    db.lead.count({ where: { status: "CONVERTED" } }),
  ]);

  return (
    <div className="space-y-8">
      <div>
        <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
          [ اصلی ]
        </p>
        <h1 className="text-3xl sm:text-4xl font-medium tracking-[-0.03em]">
          لیدها
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          پیام‌های فرم مشاوره رایگان — تماس بگیرید، تبدیل به هنرجو کنید یا حذف کنید.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatBox label="کل" value={faNumber(leads.length)} />
        <StatBox label="جدید" value={faNumber(newCount)} color="amber" />
        <StatBox label="تماس گرفته شد" value={faNumber(contactedCount)} />
        <StatBox label="تبدیل به هنرجو" value={faNumber(convertedCount)} color="emerald" />
      </div>

      <LeadsTable
        initialLeads={leads.map((l) => ({
          ...l,
          status: l.status as "NEW" | "CONTACTED" | "CONVERTED",
        }))}
        canUpdate={canUpdate}
        canDelete={canDelete}
      />
    </div>
  );
}

function StatBox({
  label,
  value,
  color,
}: {
  label: string;
  value: string;
  color?: "amber" | "emerald";
}) {
  const colorClass =
    color === "amber" ? "text-amber-700" : color === "emerald" ? "text-emerald-700" : "";
  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className={`text-2xl font-medium tabular-nums ${colorClass}`}>{value}</div>
      <div className="mt-0.5 text-xs text-muted-foreground">{label}</div>
    </div>
  );
}
