import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { DashboardSidebar, type DashboardUser } from "@/components/dashboard-sidebar";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getCurrentUser();

  // اگر لاگین نیست → /login
  if (!user) {
    redirect("/login?next=/dashboard");
  }

  // اگر نقش ADMIN یا EDITOR ندارد → به /panel می‌رود (پنل هنرجو)
  const canAccessDashboard = user.roles.some((r) =>
    ["ADMIN", "EDITOR"].includes(r)
  );
  if (!canAccessDashboard) {
    redirect("/panel");
  }

  // شمارش آمار برای نمایش در داشبورد — اینجا فقط می‌خوانیم
  // تا اگر جدولی خالی بود صفحه بدون خطا باز شود.
  let stats = null;
  try {
    const [registrations, leads, courses, students, posts, drafts, files] =
      await Promise.all([
        db.registration.count(),
        db.lead.count({ where: { status: "NEW" } }),
        db.course.count({ where: { published: true } }),
        db.user.count({
          where: {
            userRoles: { some: { role: { name: "STUDENT" } } },
          },
        }),
        db.post.count({ where: { status: "PUBLISHED" } }),
        db.post.count({ where: { status: "DRAFT" } }),
        db.fileAsset.count(),
      ]);
    stats = { registrations, leads, courses, students, posts, drafts, files };
  } catch {
    // در صورتی که دیتابیس هنوز آماده نیست، خالی برمی‌گردد
    stats = null;
  }

  const userForClient: DashboardUser = {
    id: user.id,
    name: user.name,
    phone: user.phone,
    email: user.email,
    avatarUrl: user.avatarUrl,
    roles: user.roles,
    permissions: user.permissions,
  };

  return (
    <div className="flex min-h-[100svh] bg-background">
      <DashboardSidebar user={userForClient} />
      <main className="flex-1 min-w-0">
        <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12 py-8 sm:py-10">
          {children}
        </div>
      </main>
    </div>
  );
}
