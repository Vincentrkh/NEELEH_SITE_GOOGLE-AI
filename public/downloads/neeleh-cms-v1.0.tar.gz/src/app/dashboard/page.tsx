import Link from "next/link";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { faNumber, faDate, faDateTime } from "@/lib/format";
import {
  ClipboardList,
  Inbox,
  BookOpen,
  Users,
  Newspaper,
  FileText,
  ArrowUpRight,
  TrendingUp,
} from "lucide-react";

export const dynamic = "force-dynamic";

export default async function DashboardHome() {
  const user = await getCurrentUser();

  // آمار صفحه اصلی
  const [
    regsTotal,
    regsPending,
    paidCount,
    leadsNew,
    leadsTotal,
    coursesPublished,
    coursesTotal,
    studentsCount,
    postsPublished,
    postsDraft,
    filesCount,
    recentRegs,
    recentLeads,
  ] = await Promise.all([
    db.registration.count(),
    db.registration.count({ where: { status: "PENDING" } }),
    db.registration.count({ where: { paymentStatus: "PAID" } }),
    db.lead.count({ where: { status: "NEW" } }),
    db.lead.count(),
    db.course.count({ where: { published: true } }),
    db.course.count(),
    db.user.count({
      where: { userRoles: { some: { role: { name: "STUDENT" } } } },
    }),
    db.post.count({ where: { status: "PUBLISHED" } }),
    db.post.count({ where: { status: "DRAFT" } }),
    db.fileAsset.count(),
    db.registration.findMany({
      take: 6,
      orderBy: { createdAt: "desc" },
      include: {
        student: { select: { name: true, phone: true } },
        course: { select: { title: true, slug: true } },
      },
    }),
    db.lead.findMany({
      take: 6,
      orderBy: { createdAt: "desc" },
    }),
  ]);

  const isAdmin = user?.roles.includes("ADMIN");

  const stats = [
    {
      icon: ClipboardList,
      label: "ثبت‌نام کل",
      value: faNumber(regsTotal),
      hint: `${faNumber(regsPending)} در انتظار`,
      href: "/dashboard/registrations",
      color: "text-emerald-600",
    },
    {
      icon: Inbox,
      label: "لیدهای جدید",
      value: faNumber(leadsNew),
      hint: `${faNumber(leadsTotal)} کل لیدها`,
      href: "/dashboard/leads",
      color: "text-amber-600",
    },
    {
      icon: BookOpen,
      label: "دوره‌های فعال",
      value: faNumber(coursesPublished),
      hint: `${faNumber(coursesTotal)} کل دوره‌ها`,
      href: "/dashboard/courses",
      color: "text-foreground",
    },
    {
      icon: Users,
      label: "هنرجویان",
      value: faNumber(studentsCount),
      hint: "کاربران با نقش STUDENT",
      href: isAdmin ? "/dashboard/users" : undefined,
      color: "text-foreground",
    },
    {
      icon: Newspaper,
      label: "مقالات منتشر شده",
      value: faNumber(postsPublished),
      hint: `${faNumber(postsDraft)} پیش‌نویس`,
      href: "/dashboard/posts",
      color: "text-foreground",
    },
    {
      icon: FileText,
      label: "فایل‌ها",
      value: faNumber(filesCount),
      hint: "فایل‌های آپلودشده",
      href: "/dashboard/files",
      color: "text-foreground",
    },
  ];

  return (
    <div className="space-y-10">
      {/* Header */}
      <div>
        <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
          [ داشبورد ]
        </p>
        <h1 className="text-3xl sm:text-4xl font-medium tracking-[-0.03em]">
          {user?.name}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {faDate(new Date())} — خلاصه‌ای از وضعیت آکادمی نیله.
        </p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        {stats.map((s) => {
          const Icon = s.icon;
          const content = (
            <div className="group h-full rounded-lg border border-border bg-card p-4 sm:p-5 hover:border-foreground/30 transition-colors">
              <div className="flex items-start justify-between mb-3">
                <Icon className={`size-4 ${s.color}`} aria-hidden />
                <TrendingUp className="size-3 text-muted-foreground/60" aria-hidden />
              </div>
              <div className="text-2xl sm:text-3xl font-medium tracking-tight tabular-nums">
                {s.value}
              </div>
              <div className="mt-1 text-xs text-muted-foreground">{s.label}</div>
              <div className="mt-0.5 text-[10px] text-muted-foreground/70">
                {s.hint}
              </div>
            </div>
          );
          return s.href ? (
            <Link key={s.label} href={s.href} className="block">
              {content}
            </Link>
          ) : (
            <div key={s.label}>{content}</div>
          );
        })}
      </div>

      {/* Two-column recent activity */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Recent registrations */}
        <section>
          <div className="flex items-center justify-between border-b border-border pb-3 mb-4">
            <h2 className="text-sm font-medium uppercase tracking-[0.14em]">
              آخرین ثبت‌نام‌ها
            </h2>
            <Link
              href="/dashboard/registrations"
              className="group flex min-h-[44px] items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              همه
              <ArrowUpRight className="size-3 rtl:-scale-x-100 group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform" />
            </Link>
          </div>
          {recentRegs.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              هنوز ثبت‌نامی ثبت نشده است.
            </p>
          ) : (
            <ul className="divide-y divide-border">
              {recentRegs.map((r) => (
                <li
                  key={r.id}
                  className="flex items-center gap-3 py-3 text-sm"
                >
                  <div className="grid size-8 place-items-center rounded-full bg-secondary text-xs font-medium shrink-0">
                    {r.student.name.charAt(0)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="font-medium truncate">{r.student.name}</div>
                    <div className="text-xs text-muted-foreground truncate">
                      {r.course.title}
                    </div>
                  </div>
                  <div className="text-end shrink-0">
                    <div dir="ltr" className="text-xs text-muted-foreground">
                      {r.student.phone}
                    </div>
                    <div className="text-[10px] text-muted-foreground/70">
                      {faDateTime(r.createdAt)}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* Recent leads */}
        <section>
          <div className="flex items-center justify-between border-b border-border pb-3 mb-4">
            <h2 className="text-sm font-medium uppercase tracking-[0.14em]">
              آخرین لیدها
            </h2>
            <Link
              href="/dashboard/leads"
              className="group flex min-h-[44px] items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              همه
              <ArrowUpRight className="size-3 rtl:-scale-x-100 group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform" />
            </Link>
          </div>
          {recentLeads.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              هنوز لیدی ثبت نشده است.
            </p>
          ) : (
            <ul className="divide-y divide-border">
              {recentLeads.map((l) => (
                <li
                  key={l.id}
                  className="flex items-center gap-3 py-3 text-sm"
                >
                  <div className="grid size-8 place-items-center rounded-full bg-amber-100 text-amber-700 text-xs font-medium shrink-0">
                    {l.name.charAt(0)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="font-medium truncate">{l.name}</div>
                    <div className="text-xs text-muted-foreground truncate">
                      {l.message.slice(0, 60) || "—"}
                    </div>
                  </div>
                  <div className="text-end shrink-0">
                    <div dir="ltr" className="text-xs text-muted-foreground">
                      {l.phone}
                    </div>
                    <div className="text-[10px] text-muted-foreground/70">
                      {faDateTime(l.createdAt)}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* Quick actions */}
      <section>
        <h2 className="text-sm font-medium uppercase tracking-[0.14em] mb-4">
          میانبرها
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          <QuickAction
            href="/dashboard/courses"
            icon={BookOpen}
            label="مدیریت دوره‌ها"
          />
          <QuickAction
            href="/dashboard/registrations"
            icon={ClipboardList}
            label="بررسی ثبت‌نام‌ها"
          />
          <QuickAction
            href="/dashboard/posts"
            icon={Newspaper}
            label="نوشتن مقاله"
          />
          {isAdmin && (
            <QuickAction
              href="/dashboard/theme"
              icon={FileText}
              label="تنظیمات تم"
            />
          )}
        </div>
      </section>
    </div>
  );
}

function QuickAction({
  href,
  icon: Icon,
  label,
}: {
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
}) {
  return (
    <Link
      href={href}
      className="group flex min-h-[64px] items-center gap-3 rounded-lg border border-border bg-card px-4 hover:bg-secondary transition-colors"
    >
      <Icon className="size-4 text-muted-foreground group-hover:text-foreground transition-colors" />
      <span className="text-sm font-medium">{label}</span>
      <ArrowUpRight className="size-3.5 ms-auto text-muted-foreground rtl:-scale-x-100 group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform" />
    </Link>
  );
}
