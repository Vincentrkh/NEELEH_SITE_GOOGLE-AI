import Link from "next/link";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { faNumber, faDate, POST_STATUS_LABEL } from "@/lib/format";
import { Plus, ExternalLink, Newspaper } from "lucide-react";

export const dynamic = "force-dynamic";

const STATUS_BADGE: Record<string, string> = {
  DRAFT: "bg-amber-100 text-amber-800",
  PUBLISHED: "bg-emerald-100 text-emerald-800",
  ARCHIVED: "bg-zinc-200 text-zinc-600",
};

export default async function DashboardPostsPage() {
  const user = await getCurrentUser();
  const canCreate = user?.permissions.includes("post.create");

  const [posts, publishedCount, draftCount] = await Promise.all([
    db.post.findMany({
      orderBy: { createdAt: "desc" },
      include: {
        author: { select: { name: true } },
        _count: { select: { comments: true } },
      },
    }),
    db.post.count({ where: { status: "PUBLISHED" } }),
    db.post.count({ where: { status: "DRAFT" } }),
  ]);

  return (
    <div className="space-y-8">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
            [ محتوا ]
          </p>
          <h1 className="text-3xl sm:text-4xl font-medium tracking-[-0.03em]">
            مقالات
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {faNumber(posts.length)} مقاله — {faNumber(publishedCount)} منتشر شده، {faNumber(draftCount)} پیش‌نویس
          </p>
        </div>
        {canCreate && (
          <Link
            href="/dashboard/posts/new"
            className="flex min-h-[44px] items-center gap-2 bg-foreground text-background rounded-md px-5 text-sm font-medium hover:opacity-90 transition-opacity"
          >
            <Plus className="size-4" />
            مقاله جدید
          </Link>
        )}
      </div>

      {posts.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border p-12 text-center">
          <Newspaper className="size-8 mx-auto text-muted-foreground mb-3" />
          <p className="text-sm text-muted-foreground mb-4">
            هنوز مقاله‌ای نساخته‌اید.
          </p>
          {canCreate && (
            <Link
              href="/dashboard/posts/new"
              className="inline-flex min-h-[44px] items-center gap-2 bg-foreground text-background rounded-md px-5 text-sm font-medium hover:opacity-90 transition-opacity"
            >
              <Plus className="size-4" />
              نوشتن اولین مقاله
            </Link>
          )}
        </div>
      ) : (
        <div className="overflow-hidden rounded-lg border border-border bg-card">
          <div className="hidden md:grid grid-cols-12 gap-3 border-b border-border bg-secondary/40 px-4 py-3 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
            <div className="col-span-5">عنوان</div>
            <div className="col-span-2">نویسنده</div>
            <div className="col-span-2">تاریخ</div>
            <div className="col-span-1 text-center">نظرات</div>
            <div className="col-span-2 text-center">وضعیت</div>
          </div>
          <ul className="divide-y divide-border">
            {posts.map((p) => (
              <li
                key={p.id}
                className="grid grid-cols-12 gap-3 items-center px-4 py-4 hover:bg-secondary/20 transition-colors"
              >
                <div className="col-span-12 md:col-span-5 min-w-0">
                  <Link
                    href={`/dashboard/posts/${p.id}`}
                    className="flex min-h-[44px] items-center"
                  >
                    <span className="font-medium truncate hover:text-foreground transition-colors">
                      {p.title}
                    </span>
                  </Link>
                  {p.featured && (
                    <span className="text-[10px] text-amber-700 ms-2">★ برجسته</span>
                  )}
                </div>
                <div className="hidden md:block md:col-span-2 text-sm text-muted-foreground truncate">
                  {p.author.name}
                </div>
                <div className="hidden md:block md:col-span-2 text-xs text-muted-foreground">
                  {faDate(p.publishedAt ?? p.createdAt)}
                </div>
                <div className="hidden md:block md:col-span-1 text-center text-sm tabular-nums">
                  {faNumber(p._count.comments)}
                </div>
                <div className="col-span-12 md:col-span-2 flex items-center justify-end gap-2">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] ${STATUS_BADGE[p.status]}`}>
                    {POST_STATUS_LABEL[p.status]}
                  </span>
                  {p.status === "PUBLISHED" && (
                    <a
                      href={`/blog/${p.slug}`}
                      target="_blank"
                      className="flex min-h-[44px] min-w-[44px] items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
                      aria-label="مشاهده در سایت"
                    >
                      <ExternalLink className="size-3.5" />
                    </a>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
