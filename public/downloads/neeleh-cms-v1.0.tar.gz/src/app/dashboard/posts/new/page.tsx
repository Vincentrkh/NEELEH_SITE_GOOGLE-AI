import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import { PostEditor } from "@/components/post-editor";

export const dynamic = "force-dynamic";

export default async function NewPostPage() {
  const user = await getCurrentUser();
  if (!user?.permissions.includes("post.create")) {
    redirect("/dashboard/posts");
  }

  const [categories, tags] = await Promise.all([
    db.category.findMany({ select: { id: true, name: true, slug: true }, orderBy: { name: "asc" } }),
    db.tag.findMany({ select: { id: true, name: true, slug: true }, orderBy: { name: "asc" } }),
  ]);

  return (
    <div className="space-y-8">
      <div>
        <Link
          href="/dashboard/posts"
          className="inline-flex min-h-[44px] items-center gap-1 text-xs uppercase tracking-[0.14em] text-muted-foreground hover:text-foreground transition-colors mb-4"
        >
          <ArrowRight className="size-3.5 rtl:-scale-x-100" />
          بازگشت به مقالات
        </Link>
        <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
          [ مقاله جدید ]
        </p>
        <h1 className="text-3xl sm:text-4xl font-medium tracking-[-0.03em]">
          نوشتن مقاله
        </h1>
      </div>

      <PostEditor categories={categories} tags={tags} />
    </div>
  );
}
