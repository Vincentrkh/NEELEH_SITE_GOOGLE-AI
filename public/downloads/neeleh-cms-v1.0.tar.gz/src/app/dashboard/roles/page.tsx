import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { faNumber } from "@/lib/format";
import { RolesManager } from "@/components/roles-manager";

export const dynamic = "force-dynamic";

export default async function DashboardRolesPage() {
  const user = await getCurrentUser();
  if (!user?.permissions.includes("role.manage")) {
    return <div className="p-8 text-center text-muted-foreground">دسترسی مجاز نیست</div>;
  }

  const roles = await db.role.findMany({
    orderBy: { name: "asc" },
    include: {
      rolePermissions: {
        include: { permission: { select: { id: true, key: true, label: true } } },
      },
      _count: { select: { userRoles: true } },
    },
  });

  return (
    <div className="space-y-8">
      <div>
        <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
          [ سیستم ]
        </p>
        <h1 className="text-3xl sm:text-4xl font-medium tracking-[-0.03em]">
          نقش‌ها و دسترسی‌ها
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {faNumber(roles.length)} نقش — مجوزها به هر نقش قابل اختصاص است.
        </p>
      </div>

      <RolesManager
        initialRoles={roles.map((r) => ({
          ...r,
          permissionsArray: r.rolePermissions.map((rp) => rp.permission),
          userCount: r._count.userRoles,
          rolePermissions: undefined,
          _count: undefined,
        }))}
      />
    </div>
  );
}
