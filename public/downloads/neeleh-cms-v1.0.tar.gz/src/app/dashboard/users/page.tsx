import Link from "next/link";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { faNumber, faDate } from "@/lib/format";
import { UsersManager } from "@/components/users-manager";

export const dynamic = "force-dynamic";

export default async function DashboardUsersPage() {
  const user = await getCurrentUser();
  const canUpdate = user?.permissions.includes("user.update");
  const canDelete = user?.permissions.includes("user.delete");

  const [users, roles] = await Promise.all([
    db.user.findMany({
      orderBy: { createdAt: "desc" },
      include: {
        userRoles: { include: { role: { select: { id: true, name: true, label: true } } } },
        _count: {
          select: {
            registrations: { where: { status: { not: "CANCELLED" } } },
            posts: true,
            files: true,
          },
        },
      },
    }),
    db.role.findMany({
      orderBy: { name: "asc" },
      select: { id: true, name: true, label: true, isSystem: true },
    }),
  ]);

  return (
    <div className="space-y-8">
      <div>
        <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
          [ سیستم ]
        </p>
        <h1 className="text-3xl sm:text-4xl font-medium tracking-[-0.03em]">
          کاربران
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {faNumber(users.length)} کاربر ثبت‌نام‌شده
        </p>
      </div>

      <UsersManager
        initialUsers={users.map((u) => ({
          ...u,
          rolesArray: u.userRoles.map((ur) => ur.role),
          userRoles: undefined,
          registrationCount: u._count.registrations,
          postCount: u._count.posts,
          fileCount: u._count.files,
          _count: undefined,
          isSelf: u.id === user?.id,
        }))}
        roles={roles}
        canUpdate={canUpdate}
        canDelete={canDelete}
      />
    </div>
  );
}
