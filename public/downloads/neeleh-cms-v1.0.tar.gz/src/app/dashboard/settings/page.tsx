import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { SettingsEditor } from "@/components/settings-editor";

export const dynamic = "force-dynamic";

export default async function DashboardSettingsPage() {
  const user = await getCurrentUser();
  if (!user?.permissions.includes("setting.manage")) {
    return <div className="p-8 text-center text-muted-foreground">دسترسی مجاز نیست</div>;
  }

  const settings = await db.setting.findMany({ orderBy: { key: "asc" } });

  return (
    <div className="space-y-8">
      <div>
        <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
          [ سیستم ]
        </p>
        <h1 className="text-3xl sm:text-4xl font-medium tracking-[-0.03em]">
          تنظیمات محتوا
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          محتوای صفحه اصلی، اطلاعات تماس، آمار و شبکه‌های اجتماعی — بدون نیاز به کدنویسی.
        </p>
      </div>

      <SettingsEditor initialSettings={settings} />
    </div>
  );
}
