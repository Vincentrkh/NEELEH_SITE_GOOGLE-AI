import Link from "next/link";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { faNumber, faPrice, TIER_LABEL, REG_STATUS_LABEL } from "@/lib/format";
import { Plus, ExternalLink, Edit3, Trash2, Eye, EyeOff } from "lucide-react";

export const dynamic = "force-dynamic";

const TIER_BADGE: Record<string, string> = {
  BEGINNER: "border-emerald-500/40 text-emerald-700 bg-emerald-50",
  INTERMEDIATE: "border-amber-500/40 text-amber-700 bg-amber-50",
  PRO: "border-rose-500/40 text-rose-700 bg-rose-50",
};

const REG_STATUS_BADGE: Record<string, string> = {
  OPEN: "bg-emerald-100 text-emerald-800",
  FULL: "bg-amber-100 text-amber-800",
  CLOSED: "bg-zinc-200 text-zinc-700",
};

export default async function DashboardCoursesPage() {
  const user = await getCurrentUser();
  const canCreate = user?.permissions.includes("course.create");
  const canEdit = user?.permissions.includes("course.update");
  const canDelete = user?.permissions.includes("course.delete");

  const courses = await db.course.findMany({
    orderBy: [{ tier: "asc" }, { sortOrder: "asc" }],
    include: {
      sections: { select: { id: true } },
      _count: {
        select: {
          registrations: { where: { status: { not: "CANCELLED" } } },
        },
      },
    },
  });

  // گروه‌بندی بر اساس tier
  const byTier: Record<string, typeof courses> = {
    BEGINNER: courses.filter((c) => c.tier === "BEGINNER"),
    INTERMEDIATE: courses.filter((c) => c.tier === "INTERMEDIATE"),
    PRO: courses.filter((c) => c.tier === "PRO"),
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
            [ مدیریت محتوا ]
          </p>
          <h1 className="text-3xl sm:text-4xl font-medium tracking-[-0.03em]">
            دوره‌ها
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {faNumber(courses.length)} دوره در ۳ سطح —{" "}
            {faNumber(courses.filter((c) => c.published).length)} منتشر شده
          </p>
        </div>
        {canCreate && (
          <Link
            href="/dashboard/courses/new"
            className="flex min-h-[44px] items-center gap-2 bg-foreground text-background rounded-md px-5 text-sm font-medium hover:opacity-90 transition-opacity"
          >
            <Plus className="size-4" aria-hidden />
            دوره جدید
          </Link>
        )}
      </div>

      {/* Course table per tier */}
      {(["BEGINNER", "INTERMEDIATE", "PRO"] as const).map((tier) => {
        const list = byTier[tier];
        if (list.length === 0) return null;
        return (
          <section key={tier}>
            <div className="flex items-center gap-3 mb-4">
              <span
                className={`inline-flex items-center gap-1.5 border px-2.5 py-1 text-[10px] uppercase tracking-[0.14em] ${TIER_BADGE[tier]}`}
              >
                {TIER_LABEL[tier]}
              </span>
              <span className="text-xs text-muted-foreground">
                {faNumber(list.length)} دوره
              </span>
            </div>

            <div className="overflow-hidden rounded-lg border border-border bg-card">
              {/* Header row (desktop) */}
              <div className="hidden md:grid grid-cols-12 gap-4 border-b border-border bg-secondary/40 px-4 py-3 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                <div className="col-span-1">#</div>
                <div className="col-span-4">عنوان دوره</div>
                <div className="col-span-2">دسته</div>
                <div className="col-span-1 text-center">ظرفیت</div>
                <div className="col-span-1 text-center">ثبت‌نام</div>
                <div className="col-span-2">قیمت</div>
                <div className="col-span-1 text-center">وضعیت</div>
              </div>

              {/* Rows */}
              <ul className="divide-y divide-border">
                {list.map((c, i) => (
                  <li
                    key={c.id}
                    className="grid grid-cols-12 gap-4 items-center px-4 py-4 hover:bg-secondary/30 transition-colors"
                  >
                    {/* Index */}
                    <div className="col-span-2 md:col-span-1 text-sm font-mono text-muted-foreground tabular-nums">
                      {faNumber(String(i + 1).padStart(2, "0"))}
                    </div>

                    {/* Title */}
                    <div className="col-span-10 md:col-span-4 min-w-0">
                      <Link
                        href={`/dashboard/courses/${c.id}`}
                        className="flex min-h-[44px] items-center"
                      >
                        <span className="font-medium truncate hover:text-foreground transition-colors block">
                          {c.title}
                        </span>
                      </Link>
                      <div className="md:hidden text-xs text-muted-foreground mt-1">
                        {c.category} • {faPrice(c.price)}
                      </div>
                      {/* Action icons */}
                      <div className="flex items-center gap-1 mt-2 md:mt-0">
                        {canEdit && (
                          <Link
                            href={`/dashboard/courses/${c.id}`}
                            className="flex min-h-[40px] min-w-[40px] items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
                            aria-label="ویرایش"
                          >
                            <Edit3 className="size-3.5" />
                          </Link>
                        )}
                        <Link
                          href={`/courses/${c.slug}`}
                          target="_blank"
                          className="flex min-h-[40px] min-w-[40px] items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
                          aria-label="مشاهده در سایت"
                        >
                          <ExternalLink className="size-3.5" />
                        </Link>
                        {c.published ? (
                          <Eye className="size-3.5 text-emerald-600" />
                        ) : (
                          <EyeOff className="size-3.5 text-amber-600" />
                        )}
                      </div>
                    </div>

                    {/* Category */}
                    <div className="hidden md:block md:col-span-2 text-sm text-muted-foreground truncate">
                      {c.category}
                    </div>

                    {/* Capacity */}
                    <div className="hidden md:block md:col-span-1 text-sm text-center tabular-nums">
                      {faNumber(c.capacity)}
                    </div>

                    {/* Registrations */}
                    <div className="hidden md:block md:col-span-1 text-sm text-center tabular-nums">
                      <span className="font-medium">{faNumber(c._count.registrations)}</span>
                      <span className="text-muted-foreground">/{faNumber(c.capacity)}</span>
                    </div>

                    {/* Price */}
                    <div className="hidden md:block md:col-span-2 text-sm tabular-nums">
                      {faPrice(c.price)}
                    </div>

                    {/* Status */}
                    <div className="hidden md:flex md:col-span-1 justify-center">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] ${REG_STATUS_BADGE[c.regStatus]}`}
                      >
                        {REG_STATUS_LABEL[c.regStatus]}
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </section>
        );
      })}

      {courses.length === 0 && (
        <div className="rounded-lg border border-border bg-card p-12 text-center">
          <p className="text-sm text-muted-foreground">
            هنوز دوره‌ای ثبت نشده است.
          </p>
          {canCreate && (
            <Link
              href="/dashboard/courses/new"
              className="inline-flex mt-4 items-center gap-2 bg-foreground text-background rounded-md px-5 py-2.5 text-sm font-medium hover:opacity-90 transition-opacity"
            >
              <Plus className="size-4" />
              ساخت اولین دوره
            </Link>
          )}
        </div>
      )}
    </div>
  );
}
