import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { faPrice, faNumber, TIER_LABEL } from "@/lib/format";
import { RegisterForm } from "@/components/register-form";
import { ArrowRight, Clock, Users, CheckCircle2, MapPin } from "lucide-react";

export const dynamic = "force-dynamic";

const TIER_BADGE: Record<string, string> = {
  BEGINNER: "border-emerald-500/40 text-emerald-700 bg-emerald-50",
  INTERMEDIATE: "border-amber-500/40 text-amber-700 bg-amber-50",
  PRO: "border-rose-500/40 text-rose-700 bg-rose-50",
};

export default async function RegisterPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  const course = await db.course.findUnique({
    where: { slug },
    include: {
      _count: {
        select: {
          registrations: { where: { status: { not: "CANCELLED" } } },
        },
      },
    },
  });

  if (!course || !course.published) notFound();

  const user = await getCurrentUser();
  const remaining = Math.max(0, course.capacity - course._count.registrations);
  const isOpen = course.regStatus === "OPEN" && remaining > 0;

  return (
    <main className="min-h-[100svh]">
      <header className="border-b border-border sticky top-0 bg-background/80 backdrop-blur z-30">
        <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 min-h-[44px]">
            <span className="grid size-7 place-items-center rounded-md bg-foreground text-background font-bold text-sm">
              ن
            </span>
            <span className="text-sm font-medium">آکادمی نیله</span>
          </Link>
          <Link
            href={`/courses/${course.slug}`}
            className="flex min-h-[44px] items-center gap-1 text-xs uppercase tracking-[0.14em] text-muted-foreground hover:text-foreground transition-colors"
          >
            صفحه دوره
            <ArrowRight className="size-3.5 rtl:-scale-x-100" />
          </Link>
        </div>
      </header>

      <div className="mx-auto max-w-3xl px-5 sm:px-8 lg:px-12 py-10 sm:py-16">
        {/* Course mini-header */}
        <div className="mb-8">
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <span
              className={`inline-flex items-center gap-1.5 border px-2.5 py-1 text-[10px] uppercase tracking-[0.14em] ${TIER_BADGE[course.tier]}`}
            >
              {TIER_LABEL[course.tier]}
            </span>
            {course.tags &&
              course.tags
                .split(",")
                .filter(Boolean)
                .slice(0, 3)
                .map((t) => (
                  <span
                    key={t}
                    className="text-[10px] uppercase tracking-[0.1em] border border-border px-2 py-1 text-muted-foreground"
                  >
                    {t.trim()}
                  </span>
                ))}
          </div>
          <h1 className="text-2xl sm:text-3xl font-medium tracking-[-0.03em] leading-tight">
            ثبت‌نام در دوره
          </h1>
          <p className="mt-2 text-lg sm:text-xl text-muted-foreground leading-snug">
            {course.title}
          </p>
        </div>

        {/* Quick summary */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-10 p-4 rounded-lg border border-border bg-card">
          <SummaryItem
            icon={Clock}
            label="مدت"
            value={`${faNumber(course.durationHrs)} ساعت`}
          />
          <SummaryItem
            icon={Users}
            label="ظرفیت باقیمانده"
            value={`${faNumber(remaining)} نفر`}
            highlight={remaining > 0}
          />
          <SummaryItem
            icon={MapPin}
            label="محل برگزاری"
            value="حضوری — تهران"
          />
          <div className="text-end">
            <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground mb-1">
              شهریه
            </div>
            <div className="text-base font-medium tabular-nums">
              {course.price > 0 ? faPrice(course.price) : "تماس بگیرید"}
            </div>
          </div>
        </div>

        {/* Already registered check */}
        {user && (
          <AlreadyRegisteredCheck studentId={user.id} courseId={course.id} />
        )}

        {isOpen ? (
          <RegisterForm
            slug={course.slug}
            initialName={user?.name}
            initialPhone={user?.phone}
            isLoggedIn={!!user}
          />
        ) : (
          <div className="rounded-lg border border-amber-300 bg-amber-50 p-8 text-center">
            <CheckCircle2 className="size-8 mx-auto text-amber-600 mb-3" />
            <h2 className="text-lg font-medium mb-2">ظرفیت این دوره تکمیل شده است</h2>
            <p className="text-sm text-muted-foreground">
              برای اطلاع از تاریخ شروع دوره بعدی، با آکادمی در تماس باشید.
            </p>
            <Link
              href="/courses"
              className="inline-flex mt-5 min-h-[48px] items-center justify-center rounded-md border border-border px-6 text-sm font-medium hover:bg-secondary transition-colors"
            >
              مشاهده دوره‌های دیگر
            </Link>
          </div>
        )}
      </div>
    </main>
  );
}

function SummaryItem({
  icon: Icon,
  label,
  value,
  highlight,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div>
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.14em] text-muted-foreground mb-1">
        <Icon className="size-3" />
        {label}
      </div>
      <div
        className={`text-sm font-medium tabular-nums ${
          highlight ? "text-emerald-700" : ""
        }`}
      >
        {value}
      </div>
    </div>
  );
}

async function AlreadyRegisteredCheck({
  studentId,
  courseId,
}: {
  studentId: string;
  courseId: string;
}) {
  const existing = await db.registration.findUnique({
    where: { studentId_courseId: { studentId, courseId } },
  });
  if (!existing || existing.status === "CANCELLED") return null;

  const statusLabels: Record<string, string> = {
    PENDING: "در انتظار تایید",
    CONFIRMED: "تایید شده",
    CANCELLED: "لغو شده",
  };

  return (
    <div className="mb-6 rounded-lg border border-emerald-300 bg-emerald-50 p-5">
      <div className="flex items-center gap-2 mb-1">
        <CheckCircle2 className="size-4 text-emerald-600" />
        <span className="text-sm font-medium text-emerald-900">
          شما در این دوره ثبت‌نام کرده‌اید
        </span>
      </div>
      <p className="text-xs text-emerald-700">
        وضعیت ثبت‌نام: {statusLabels[existing.status]} — برای پیگیری به پنل هنرجویی مراجعه کنید.
      </p>
      <Link
        href="/panel"
        className="inline-flex mt-3 min-h-[44px] items-center rounded-md bg-emerald-700 text-white px-4 text-sm hover:opacity-90 transition-opacity"
      >
        ورود به پنل هنرجویی
      </Link>
    </div>
  );
}
