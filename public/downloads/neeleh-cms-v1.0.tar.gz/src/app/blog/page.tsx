import Link from "next/link";
import { db } from "@/lib/db";
import { faNumber, faDate, POST_STATUS_LABEL } from "@/lib/format";
import { Clock, ArrowUpRight, Newspaper } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function BlogPage() {
  const [posts, categories] = await Promise.all([
    db.post.findMany({
      where: { status: "PUBLISHED" },
      orderBy: { publishedAt: "desc" },
      include: {
        author: { select: { name: true } },
        categories: { include: { category: true } },
        _count: { select: { comments: { where: { status: "APPROVED" } } } },
      },
    }),
    db.category.findMany({
      include: { _count: { select: { posts: { where: { post: { status: "PUBLISHED" } } } } } },
      orderBy: { name: "asc" },
    }),
  ]);

  const featuredPosts = posts.filter((p) => p.featured);
  const regularPosts = posts.filter((p) => !p.featured);

  return (
    <main className="min-h-[100svh]">
      <header className="border-b border-border sticky top-0 bg-background/80 backdrop-blur z-30">
        <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 min-h-[44px]">
            <span className="grid size-7 place-items-center rounded-md bg-foreground text-background font-bold text-sm">
              ن
            </span>
            <span className="text-sm font-medium">آکادمی نیله</span>
          </Link>
          <nav className="flex items-center gap-1">
            <Link
              href="/courses"
              className="flex min-h-[44px] items-center px-3 text-xs uppercase tracking-[0.14em] text-muted-foreground hover:text-foreground transition-colors"
            >
              دوره‌ها
            </Link>
            <Link
              href="/blog"
              className="flex min-h-[44px] items-center px-3 text-xs uppercase tracking-[0.14em] text-foreground transition-colors"
            >
              بلاگ
            </Link>
          </nav>
        </div>
      </header>

      <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12 py-12 sm:py-16">
        <div className="mb-12">
          <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-3">
            [ بلاگ آکادمی نیله ]
          </p>
          <h1 className="text-4xl sm:text-6xl font-medium tracking-[-0.04em] leading-[0.95]">
            مقالات و
            <br />
            یادداشت‌های معماری
          </h1>
          <p className="mt-6 text-base sm:text-lg leading-relaxed text-muted-foreground max-w-xl">
            تحلیل، آموزش و تجربه‌های واقعی از دنیای معماری محاسباتی، BIM و
            هوش مصنوعی در طراحی.
          </p>
        </div>

        {/* Categories strip */}
        {categories.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-10">
            <Link
              href="/blog"
              className="flex min-h-[44px] items-center px-4 text-xs uppercase tracking-[0.12em] border border-foreground bg-foreground text-background rounded-md"
            >
              همه
            </Link>
            {categories.map((c) => (
              <Link
                key={c.id}
                href={`/blog?category=${c.slug}`}
                className="flex min-h-[44px] items-center px-4 text-xs uppercase tracking-[0.12em] border border-border rounded-md hover:bg-secondary transition-colors"
              >
                {c.name}
                <span className="ms-1.5 text-[10px] opacity-60">
                  {faNumber(c._count.posts)}
                </span>
              </Link>
            ))}
          </div>
        )}

        {/* Featured posts */}
        {featuredPosts.length > 0 && (
          <section className="mb-12">
            <h2 className="text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4">
              برجسته
            </h2>
            <div className="grid sm:grid-cols-2 gap-4">
              {featuredPosts.map((p) => (
                <Link
                  key={p.id}
                  href={`/blog/${p.slug}`}
                  className="group rounded-lg border border-border bg-card overflow-hidden hover:border-foreground/30 transition-colors"
                >
                  {p.coverUrl && (
                    <div className="h-48 overflow-hidden bg-secondary/40">
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={p.coverUrl}
                        alt={p.title}
                        className="size-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                  )}
                  <div className="p-5">
                    <h3 className="text-lg font-medium leading-snug mb-2 group-hover:text-foreground transition-colors line-clamp-2">
                      {p.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2 mb-3">
                      {p.excerpt}
                    </p>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span>{p.author.name}</span>
                      <span>•</span>
                      <span>{faDate(p.publishedAt)}</span>
                      {p.readingMins > 0 && (
                        <>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Clock className="size-3" />
                            {faNumber(p.readingMins)} دقیقه
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* All posts */}
        <section>
          <h2 className="text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4">
            همه مقالات
          </h2>
          {regularPosts.length === 0 && posts.length === 0 ? (
            <div className="rounded-lg border border-dashed border-border p-12 text-center">
              <Newspaper className="size-8 mx-auto text-muted-foreground mb-3" />
              <p className="text-sm text-muted-foreground">
                هنوز مقاله‌ای منتشر نشده است.
              </p>
            </div>
          ) : (
            <ul className="divide-y divide-border">
              {(regularPosts.length > 0 ? regularPosts : posts).map((p) => (
                <li key={p.id}>
                  <Link
                    href={`/blog/${p.slug}`}
                    className="group grid grid-cols-12 gap-4 items-center py-5 hover:bg-secondary/20 -mx-2 px-2 rounded-md transition-colors min-h-[88px]"
                  >
                    <div className="col-span-12 md:col-span-7 min-w-0">
                      <div className="text-lg font-medium leading-snug group-hover:text-foreground transition-colors line-clamp-2">
                        {p.title}
                      </div>
                      {p.excerpt && (
                        <p className="mt-1 text-sm text-muted-foreground line-clamp-1">
                          {p.excerpt}
                        </p>
                      )}
                    </div>
                    <div className="col-span-6 md:col-span-3 text-xs text-muted-foreground">
                      <div>{p.author.name}</div>
                      <div>{faDate(p.publishedAt)}</div>
                    </div>
                    <div className="col-span-6 md:col-span-2 flex items-center justify-end gap-2 text-xs text-muted-foreground">
                      {p.readingMins > 0 && (
                        <span className="flex items-center gap-1">
                          <Clock className="size-3" />
                          {faNumber(p.readingMins)} دقیقه
                        </span>
                      )}
                      <ArrowUpRight className="size-3.5 group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform" />
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </main>
  );
}
