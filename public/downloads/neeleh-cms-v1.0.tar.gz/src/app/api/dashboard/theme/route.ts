import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requirePermission } from "@/lib/auth";

/**
 * GET /api/dashboard/theme — تنظیمات تم فعلی
 * PUT /api/dashboard/theme — به‌روزرسانی تنظیمات تم
 */

const FIELDS = [
  "isActive",
  "backgroundColor",
  "foregroundColor",
  "primaryColor",
  "accentColor",
  "mutedColor",
  "fontHeading",
  "fontBody",
  "radius",
  "mode",
  "customCss",
] as const;

export async function GET() {
  const user = await requirePermission("theme.manage");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  const theme = await db.themeSetting.findFirst({
    where: { isActive: true },
  });
  if (!theme) {
    return NextResponse.json({ error: "تم فعال یافت نشد" }, { status: 404 });
  }
  return NextResponse.json({ theme });
}

type UpdateBody = Partial<Record<(typeof FIELDS)[number], string | boolean>>;

export async function PUT(req: NextRequest) {
  const user = await requirePermission("theme.manage");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  try {
    const body = (await req.json()) as UpdateBody;

    const theme = await db.themeSetting.findFirst({ where: { isActive: true } });
    if (!theme) return NextResponse.json({ error: "تم یافت نشد" }, { status: 404 });

    const data: Record<string, unknown> = {};
    for (const f of FIELDS) {
      if (body[f] !== undefined) {
        data[f] = body[f];
      }
    }

    // اعتبارسنجی mode
    if (data.mode && !["LIGHT", "DARK", "AUTO"].includes(String(data.mode))) {
      return NextResponse.json({ error: "حالت تم نامعتبر است" }, { status: 400 });
    }

    const updated = await db.themeSetting.update({
      where: { id: theme.id },
      data,
    });

    return NextResponse.json({ theme: updated });
  } catch (e) {
    console.error("theme update error", e);
    return NextResponse.json({ error: "خطا در به‌روزرسانی تم" }, { status: 500 });
  }
}
