import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requirePermission } from "@/lib/auth";
import { toFaDigits } from "@/lib/format";

/**
 * GET /api/dashboard/registrations/export — خروجی CSV همه ثبت‌نام‌ها
 * قابل باز کردن در Excel (با BOM UTF-8).
 */

export async function GET() {
  const user = await requirePermission("registration.export");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  const registrations = await db.registration.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      student: { select: { name: true, phone: true, email: true, field: true, education: true } },
      course: { select: { title: true, price: true } },
    },
  });

  const headers = [
    "ردیف",
    "نام و نام خانوادگی",
    "شماره موبایل",
    "ایمیل",
    "رشته تحصیلی",
    "سوابق تحصیلی",
    "دوره",
    "وضعیت ثبت‌نام",
    "وضعیت پرداخت",
    "شهریه (تومان)",
    "تاریخ ثبت",
    "یادداشت",
  ];

  const statusLabels: Record<string, string> = {
    PENDING: "در انتظار تایید",
    CONFIRMED: "تایید شده",
    CANCELLED: "لغو شده",
  };
  const paymentLabels: Record<string, string> = {
    UNPAID: "پرداخت نشده",
    PAID: "پرداخت شده",
  };

  const faDateShort = (d: Date) => {
    return new Intl.DateTimeFormat("fa-IR", {
      year: "numeric",
      month: "numeric",
      day: "numeric",
    }).format(d);
  };

  const escapeCSV = (s: string) => {
    const str = String(s ?? "");
    if (str.includes(",") || str.includes('"') || str.includes("\n")) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const rows = registrations.map((r, i) => [
    toFaDigits(String(i + 1)),
    escapeCSV(r.student.name),
    r.student.phone,
    escapeCSV(r.student.email ?? ""),
    escapeCSV(r.student.field ?? ""),
    escapeCSV(r.student.education ?? ""),
    escapeCSV(r.course.title),
    statusLabels[r.status] ?? r.status,
    paymentLabels[r.paymentStatus] ?? r.paymentStatus,
    toFaDigits(r.course.price.toLocaleString("en-US")),
    faDateShort(r.createdAt),
    escapeCSV(r.note ?? ""),
  ]);

  const csv = [headers.map(escapeCSV).join(","), ...rows.map((r) => r.join(","))].join("\r\n");

  // BOM برای نمایش صحیح فارسی در Excel
  const bom = "\uFEFF";
  const csvBytes = Buffer.from(bom + csv, "utf-8");

  const date = new Date().toISOString().slice(0, 10);
  return new NextResponse(csvBytes, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="neeleh-registrations-${date}.csv"`,
    },
  });
}
