import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requirePermission } from "@/lib/auth";

/**
 * PATCH /api/dashboard/registrations/[id] — تغییر وضعیت ثبت‌نام
 *   { status?: "PENDING"|"CONFIRMED"|"CANCELLED", paymentStatus?: "PAID"|"UNPAID", note?: string }
 * DELETE /api/dashboard/registrations/[id] — حذف ثبت‌نام
 */

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = (await req.json()) as {
    status?: string;
    paymentStatus?: string;
    note?: string;
  };

  // بررسی دسترسی
  const needsAdmin =
    body.status !== undefined || body.paymentStatus !== undefined;
  const user = await requirePermission(
    needsAdmin ? "registration.update" : "registration.view"
  );
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  // اعتبارسنجی
  if (
    body.status &&
    !["PENDING", "CONFIRMED", "CANCELLED"].includes(body.status)
  ) {
    return NextResponse.json({ error: "وضعیت نامعتبر است" }, { status: 400 });
  }
  if (
    body.paymentStatus &&
    !["PAID", "UNPAID"].includes(body.paymentStatus)
  ) {
    return NextResponse.json({ error: "وضعیت پرداخت نامعتبر است" }, { status: 400 });
  }

  const existing = await db.registration.findUnique({ where: { id } });
  if (!existing) {
    return NextResponse.json({ error: "ثبت‌نام یافت نشد" }, { status: 404 });
  }

  const data: { [k: string]: unknown } = {};
  if (body.status !== undefined) data.status = body.status;
  if (body.paymentStatus !== undefined) data.paymentStatus = body.paymentStatus;
  if (body.note !== undefined) data.note = body.note.slice(0, 1000);

  const updated = await db.registration.update({
    where: { id },
    data,
    include: {
      student: {
        select: { id: true, name: true, phone: true, email: true, field: true, education: true },
      },
      course: { select: { id: true, title: true, slug: true, price: true, tier: true } },
    },
  });

  return NextResponse.json({ registration: updated });
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const user = await requirePermission("registration.delete");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  try {
    await db.registration.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "ثبت‌نام یافت نشد" }, { status: 404 });
  }
}
