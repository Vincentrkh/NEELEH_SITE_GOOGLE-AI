import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requirePermission } from "@/lib/auth";

/**
 * GET /api/dashboard/settings — همه تنظیمات key-value
 * PUT /api/dashboard/settings — به‌روزرسانی چند کلید با هم
 *   body: { settings: [{ key, value, label? }] }
 */

export async function GET() {
  const user = await requirePermission("setting.manage");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  const settings = await db.setting.findMany({
    orderBy: { key: "asc" },
  });

  return NextResponse.json({ settings });
}

type UpdateItem = { key: string; value: string; label?: string; type?: string };

export async function PUT(req: NextRequest) {
  const user = await requirePermission("setting.manage");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  try {
    const body = (await req.json()) as { settings: UpdateItem[] };
    if (!Array.isArray(body.settings)) {
      return NextResponse.json({ error: "فرمت نامعتبر" }, { status: 400 });
    }

    // upsert همه کلیدها
    for (const s of body.settings) {
      if (!s.key) continue;
      await db.setting.upsert({
        where: { key: s.key },
        update: {
          value: String(s.value ?? ""),
          ...(s.label !== undefined ? { label: s.label } : {}),
          ...(s.type !== undefined ? { type: s.type } : {}),
        },
        create: {
          key: s.key,
          value: String(s.value ?? ""),
          label: s.label ?? null,
          type: s.type ?? "text",
        },
      });
    }

    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("settings update error", e);
    return NextResponse.json({ error: "خطا در به‌روزرسانی" }, { status: 500 });
  }
}
