import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requirePermission } from "@/lib/auth";

/**
 * PATCH /api/dashboard/roles/[id] — تغییر برچسب/توضیح/مجوزها
 * DELETE /api/dashboard/roles/[id] — حذف (فقط نقش‌های غیر سیستمی)
 */

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const user = await requirePermission("role.manage");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  const body = (await req.json()) as {
    label?: string;
    description?: string;
    permissionIds?: string[];
  };

  const existing = await db.role.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "یافت نشد" }, { status: 404 });

  const data: { [k: string]: unknown } = {};
  if (body.label !== undefined) data.label = body.label.trim();
  if (body.description !== undefined) data.description = body.description.trim();

  const updated = await db.role.update({ where: { id }, data });

  // بازنویسی مجوزها
  if (body.permissionIds !== undefined) {
    await db.rolePermission.deleteMany({ where: { roleId: id } });
    if (body.permissionIds.length > 0) {
      await db.rolePermission.createMany({
        data: body.permissionIds.map((pid) => ({ roleId: id, permissionId: pid })),
      });
    }
  }

  return NextResponse.json({ role: updated });
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const user = await requirePermission("role.manage");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  const existing = await db.role.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "یافت نشد" }, { status: 404 });
  if (existing.isSystem) {
    return NextResponse.json(
      { error: "نقش‌های سیستمی قابل حذف نیستند" },
      { status: 400 }
    );
  }

  try {
    await db.role.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "حذف نشد — ممکن است کاربری این نقش را داشته باشد" }, { status: 400 });
  }
}
