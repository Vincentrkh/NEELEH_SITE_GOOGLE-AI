import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requirePermission } from "@/lib/auth";
import { slugify } from "@/lib/format";

/**
 * GET /api/dashboard/courses — لیست همه دوره‌ها (با sections و آمار ثبت‌نام)
 * POST /api/dashboard/courses — ساخت دوره جدید
 */

export async function GET() {
  const user = await requirePermission("course.view");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  const courses = await db.course.findMany({
    orderBy: [{ tier: "asc" }, { sortOrder: "asc" }],
    include: {
      sections: { orderBy: { order: "asc" } },
      _count: {
        select: {
          registrations: { where: { status: { not: "CANCELLED" } } },
        },
      },
    },
  });

  return NextResponse.json({
    courses: courses.map((c) => ({
      ...c,
      tagsArray: c.tags ? c.tags.split(",").filter(Boolean) : [],
      outputsArray: c.outputs ? c.outputs.split("\n").filter(Boolean) : [],
      registrationCount: c._count.registrations,
      _count: undefined,
    })),
  });
}

type CreateBody = {
  title: string;
  tier: "BEGINNER" | "INTERMEDIATE" | "PRO";
  category: string;
  description?: string;
  about?: string;
  tags?: string[];
  outputs?: string[];
  prereqs?: string;
  durationHrs?: number;
  price?: number;
  capacity?: number;
  regStatus?: "OPEN" | "FULL" | "CLOSED";
  featured?: boolean;
  published?: boolean;
  bannerUrl?: string;
  sortOrder?: number;
  sections?: { title: string; items: string[] }[];
};

export async function POST(req: NextRequest) {
  const user = await requirePermission("course.create");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  try {
    const body = (await req.json()) as CreateBody;

    if (!body.title?.trim()) {
      return NextResponse.json({ error: "عنوان دوره الزامی است" }, { status: 400 });
    }
    if (!["BEGINNER", "INTERMEDIATE", "PRO"].includes(body.tier)) {
      return NextResponse.json({ error: "سطح دوره نامعتبر است" }, { status: 400 });
    }

    // ساخت slug یکتا
    let slug = slugify(body.title);
    if (!slug) slug = `course-${Date.now()}`;
    const existing = await db.course.findUnique({ where: { slug } });
    if (existing) slug = `${slug}-${Date.now().toString(36)}`;

    const course = await db.course.create({
      data: {
        slug,
        title: body.title.trim(),
        tier: body.tier,
        category: body.category?.trim() || "عمومی",
        description: body.description?.trim() || "",
        about: body.about?.trim() || "",
        tags: (body.tags || []).join(","),
        outputs: (body.outputs || []).join("\n"),
        prereqs: body.prereqs?.trim() || "",
        durationHrs: Number(body.durationHrs) || 0,
        price: Number(body.price) || 0,
        capacity: Number(body.capacity) || 12,
        regStatus: body.regStatus || "OPEN",
        featured: Boolean(body.featured),
        published: body.published !== false, // پیش‌فرض: منتشر شده
        bannerUrl: body.bannerUrl?.trim() || null,
        sortOrder: Number(body.sortOrder) || 0,
        sections: body.sections?.length
          ? {
              create: body.sections.map((s, i) => ({
                title: s.title,
                items: (s.items || []).join("\n"),
                order: i,
              })),
            }
          : undefined,
      },
      include: { sections: true },
    });

    return NextResponse.json({ course });
  } catch (e) {
    console.error("course create error", e);
    return NextResponse.json({ error: "خطا در ساخت دوره" }, { status: 500 });
  }
}
