import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requirePermission } from "@/lib/auth";
import { hashPassword } from "@/lib/auth";
import { normalizePhone, isValidPhone } from "@/lib/format";

/**
 * PATCH /api/dashboard/users/[id] — تغییر نقش‌ها / اطلاعات کاربر
 * DELETE /api/dashboard/users/[id] — حذف کاربر
 */

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const user = await requirePermission("user.update");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  const body = (await req.json()) as {
    name?: string;
    email?: string;
    field?: string;
    education?: string;
    bio?: string;
    roleIds?: string[];
    resetPassword?: string;
  };

  const existing = await db.user.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "یافت نشد" }, { status: 404 });

  const data: { [k: string]: unknown } = {};
  if (body.name !== undefined) data.name = body.name.trim();
  if (body.email !== undefined) data.email = body.email.trim() || null;
  if (body.field !== undefined) data.field = body.field.trim() || null;
  if (body.education !== undefined) data.education = body.education.trim() || null;
  if (body.bio !== undefined) data.bio = body.bio.trim().slice(0, 1000) || null;

  // تغییر رمز عبور
  if (body.resetPassword && body.resetPassword.length >= 6) {
    data.password = hashPassword(body.resetPassword);
  }

  const updated = await db.user.update({ where: { id }, data });

  // بازنویسی نقش‌ها
  if (body.roleIds !== undefined) {
    await db.userRole.deleteMany({ where: { userId: id } });
    if (body.roleIds.length > 0) {
      await db.userRole.createMany({
        data: body.roleIds.map((rid) => ({ userId: id, roleId: rid })),
      });
    }
  }

  return NextResponse.json({ user: updated });
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const user = await requirePermission("user.delete");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  // جلوگیری از حذف خود
  if (user.id === id) {
    return NextResponse.json({ error: "نمی‌توانید حساب خود را حذف کنید" }, { status: 400 });
  }

  try {
    await db.user.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "یافت نشد" }, { status: 404 });
  }
}
