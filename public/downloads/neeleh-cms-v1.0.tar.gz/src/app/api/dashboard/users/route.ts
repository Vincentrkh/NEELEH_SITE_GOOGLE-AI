import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requirePermission } from "@/lib/auth";

/**
 * GET /api/dashboard/users — لیست کاربران
 * POST /api/dashboard/users — ساخت کاربر جدید
 */

export async function GET(req: NextRequest) {
  const user = await requirePermission("user.view");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  const url = new URL(req.url);
  const q = url.searchParams.get("q");

  const where: { [k: string]: unknown } = {};
  if (q) {
    where.OR = [
      { name: { contains: q } },
      { phone: { contains: q } },
      { email: { contains: q } },
    ];
  }

  const users = await db.user.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: {
      userRoles: {
        include: { role: { select: { id: true, name: true, label: true } } },
      },
      _count: {
        select: {
          registrations: { where: { status: { not: "CANCELLED" } } },
          posts: true,
          files: true,
        },
      },
    },
  });

  return NextResponse.json({
    users: users.map((u) => ({
      ...u,
      rolesArray: u.userRoles.map((ur) => ur.role),
      userRoles: undefined,
      registrationCount: u._count.registrations,
      postCount: u._count.posts,
      fileCount: u._count.files,
      _count: undefined,
    })),
  });
}
