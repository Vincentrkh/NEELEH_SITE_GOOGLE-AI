import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requirePermission } from "@/lib/auth";
import { unlink } from "fs/promises";
import path from "path";

/** DELETE /api/dashboard/files/[id] — حذف فایل (از دیسک و دیتابیس) */
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const user = await requirePermission("file.delete");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  const file = await db.fileAsset.findUnique({
    where: { id },
    include: { _count: { select: { resources: true } } },
  });
  if (!file) return NextResponse.json({ error: "فایل یافت نشد" }, { status: 404 });

  // اگر فایل در حال استفاده در منابع دوره است، مانع حذف می‌شویم
  if (file._count.resources > 0) {
    return NextResponse.json(
      { error: `این فایل در ${file._count.resources} منبع دوره در حال استفاده است. ابتدا منابع را حذف کنید.` },
      { status: 409 }
    );
  }

  // حذف از دیسک
  try {
    const filePath = path.join(process.cwd(), "public", file.path);
    await unlink(filePath);
  } catch {
    // اگر فایل فیزیکی وجود نداشت، فقط از دیتابیس حذف می‌کنیم
  }

  await db.fileAsset.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
