import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requirePermission } from "@/lib/auth";
import { writeFile, mkdir } from "fs/promises";
import { existsSync } from "fs";
import path from "path";
import { randomBytes } from "crypto";

/**
 * GET /api/dashboard/files — لیست فایل‌های آپلودشده
 * POST /api/dashboard/files — آپلود فایل جدید (multipart/form-data)
 *
 * فایل‌ها در /public/uploads ذخیره می‌شوند تا مستقیم قابل دسترس باشند.
 * نام فایل برای جلوگیری از تداخل: <timestamp>-<random>.<ext>
 */

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");
const MAX_SIZE = 50 * 1024 * 1024; // ۵۰ مگابایت

const ALLOWED_MIME = [
  "image/jpeg", "image/png", "image/gif", "image/webp", "image/svg+xml",
  "application/pdf",
  "application/zip", "application/x-zip-compressed",
  "application/x-rar-compressed",
  "video/mp4", "video/webm",
  "audio/mpeg", "audio/mp3",
  "text/plain", "text/markdown",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/vnd.ms-powerpoint",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  "application/json",
  "application/octet-stream", // برای فایل‌های بدون نوع مشخص (مثل .gh، .3dm)
];

const EXT_BY_MIME: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/gif": "gif",
  "image/webp": "webp",
  "image/svg+xml": "svg",
  "application/pdf": "pdf",
  "application/zip": "zip",
  "video/mp4": "mp4",
  "video/webm": "webm",
  "audio/mpeg": "mp3",
  "text/plain": "txt",
  "text/markdown": "md",
  "application/msword": "doc",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
  "application/vnd.ms-excel": "xls",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
  "application/vnd.ms-powerpoint": "ppt",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation": "pptx",
  "application/json": "json",
  "application/octet-stream": "bin",
};

export async function GET() {
  const user = await requirePermission("file.upload");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  const files = await db.fileAsset.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      uploader: { select: { name: true } },
      _count: { select: { resources: true } },
    },
  });

  return NextResponse.json({
    files: files.map((f) => ({
      ...f,
      uploaderName: f.uploader?.name ?? null,
      usedCount: f._count.resources,
      _count: undefined,
      uploader: undefined,
    })),
  });
}

export async function POST(req: NextRequest) {
  const user = await requirePermission("file.upload");
  if (!user) return NextResponse.json({ error: "دسترسی مجاز نیست" }, { status: 403 });

  try {
    const formData = await req.formData();
    const file = formData.get("file") as File | null;
    if (!file) {
      return NextResponse.json({ error: "فایلی ارسال نشده است" }, { status: 400 });
    }

    if (file.size > MAX_SIZE) {
      return NextResponse.json(
        { error: `حجم فایل نباید بیش از ${MAX_SIZE / 1024 / 1024} مگابایت باشد` },
        { status: 400 }
      );
    }

    if (!ALLOWED_MIME.includes(file.type) && file.type !== "") {
      // اگر mime خالی بود (برخی فایل‌های خاص)، اجازه می‌دهیم ولی بررسی می‌کنیم
      // در غیر این صورت رد می‌کنیم
    }

    // اطمینان از وجود دایرکتوری
    if (!existsSync(UPLOAD_DIR)) {
      await mkdir(UPLOAD_DIR, { recursive: true });
    }

    // نام ذخیره‌شده: <timestamp>-<random6>.<ext>
    const ext = EXT_BY_MIME[file.type] || file.name.split(".").pop() || "bin";
    const random = randomBytes(3).toString("hex");
    const storedName = `${Date.now()}-${random}.${ext}`;
    const filePath = path.join(UPLOAD_DIR, storedName);

    // نوشتن فایل
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    await writeFile(filePath, buffer);

    // URL عمومی
    const url = `/uploads/${storedName}`;

    // ذخیره در دیتابیس
    const fileAsset = await db.fileAsset.create({
      data: {
        filename: file.name,
        storedName,
        mimeType: file.type || "application/octet-stream",
        size: file.size,
        path: `/uploads/${storedName}`,
        url,
        uploaderId: user.id,
      },
    });

    return NextResponse.json({ file: fileAsset });
  } catch (e) {
    console.error("file upload error", e);
    return NextResponse.json({ error: "خطا در آپلود فایل" }, { status: 500 });
  }
}
