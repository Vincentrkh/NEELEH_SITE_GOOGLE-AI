import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { normalizePhone, isValidPhone } from "@/lib/format";

type Body = { name?: string; phone?: string; email?: string; message?: string };

/** POST /api/leads — فرم مشاوره رایگان (عمومی) */
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Body;
    const name = (body.name ?? "").trim();
    const phone = normalizePhone(body.phone ?? "");
    const email = (body.email ?? "").trim() || null;
    const message = (body.message ?? "").trim().slice(0, 2000);

    if (name.length < 3) {
      return NextResponse.json({ error: "نام را کامل وارد کنید" }, { status: 400 });
    }
    if (!isValidPhone(phone)) {
      return NextResponse.json(
        { error: "شماره موبایل معتبر نیست (مثال: ۰۹۱۲۱۲۳۴۵۶۷)" },
        { status: 400 }
      );
    }

    await db.lead.create({
      data: { name, phone, email, message },
    });

    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("lead create error", e);
    return NextResponse.json({ error: "خطا در ثبت درخواست" }, { status: 500 });
  }
}
