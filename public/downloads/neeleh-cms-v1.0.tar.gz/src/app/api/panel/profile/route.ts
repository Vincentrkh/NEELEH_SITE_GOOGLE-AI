import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";

/**
 * GET /api/panel/profile — پروفایل کاربر فعلی
 * PUT /api/panel/profile — به‌روزرسانی پروفایل (نام، ایمیل، رشته، سوابق، بیو)
 */

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "لاگین نیستید" }, { status: 401 });

  return NextResponse.json({ user });
}

type UpdateBody = {
  name?: string;
  email?: string;
  field?: string;
  education?: string;
  bio?: string;
};

export async function PUT(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "لاگین نیستید" }, { status: 401 });

  try {
    const body = (await req.json()) as UpdateBody;

    const data: Record<string, string | null> = {};
    if (body.name !== undefined) {
      if (body.name.trim().length < 3) {
        return NextResponse.json({ error: "نام کوتاه است" }, { status: 400 });
      }
      data.name = body.name.trim();
    }
    if (body.email !== undefined) data.email = body.email.trim() || null;
    if (body.field !== undefined) data.field = body.field.trim() || null;
    if (body.education !== undefined) data.education = body.education.trim() || null;
    if (body.bio !== undefined) data.bio = body.bio.trim().slice(0, 1000) || null;

    const updated = await db.user.update({
      where: { id: user.id },
      data,
      select: {
        id: true,
        name: true,
        phone: true,
        email: true,
        field: true,
        education: true,
        bio: true,
      },
    });

    return NextResponse.json({ user: updated });
  } catch (e) {
    console.error("profile update error", e);
    return NextResponse.json({ error: "خطا در به‌روزرسانی" }, { status: 500 });
  }
}
