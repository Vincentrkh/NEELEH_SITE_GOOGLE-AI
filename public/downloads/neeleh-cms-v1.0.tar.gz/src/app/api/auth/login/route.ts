import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { setSessionCookie, verifyPassword } from "@/lib/auth";
import { normalizePhone, isValidPhone } from "@/lib/format";

type Body = { phone?: string; password?: string };

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Body;
    const phone = normalizePhone(body.phone ?? "");
    const password = body.password ?? "";

    if (!isValidPhone(phone)) {
      return NextResponse.json(
        { error: "شماره موبایل معتبر نیست (مثال: ۰۹۱۲۱۲۳۴۵۶۷)" },
        { status: 400 }
      );
    }
    if (!password || password.length < 1) {
      return NextResponse.json(
        { error: "رمز عبور را وارد کنید" },
        { status: 400 }
      );
    }

    const user = await db.user.findUnique({
      where: { phone },
      include: {
        userRoles: {
          select: {
            role: { select: { name: true } },
          },
        },
      },
    });
    if (!user || !verifyPassword(password, user.password)) {
      return NextResponse.json(
        { error: "شماره یا رمز عبور اشتباه است" },
        { status: 401 }
      );
    }

    await setSessionCookie(user.id);

    const roles = user.userRoles.map((ur) => ur.role.name);
    const redirect =
      roles.includes("ADMIN") || roles.includes("EDITOR")
        ? "/dashboard"
        : "/panel";

    return NextResponse.json({
      user: { id: user.id, name: user.name, phone: user.phone, roles },
      redirect,
    });
  } catch (e) {
    console.error("login error", e);
    return NextResponse.json(
      { error: "خطای غیرمنتظره در ورود" },
      { status: 500 }
    );
  }
}
