import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

/**
 * GET /api/courses/[slug] — جزئیات یک دوره منتشر شده
 */
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const course = await db.course.findUnique({
    where: { slug },
    include: {
      sections: { orderBy: { order: "asc" } },
      resources: {
        where: { OR: [{ fileId: null }, { fileId: { not: null } }] },
        orderBy: { createdAt: "desc" },
      },
      _count: {
        select: {
          registrations: { where: { status: { not: "CANCELLED" } } },
        },
      },
    },
  });

  if (!course || !course.published) {
    return NextResponse.json({ error: "دوره یافت نشد" }, { status: 404 });
  }

  return NextResponse.json({
    course: {
      ...course,
      tagsArray: course.tags ? course.tags.split(",").filter(Boolean) : [],
      outputsArray: course.outputs ? course.outputs.split("\n").filter(Boolean) : [],
      sections: course.sections.map((s) => ({
        ...s,
        itemsArray: s.items ? s.items.split("\n").filter(Boolean) : [],
      })),
      remainingSeats: Math.max(0, course.capacity - course._count.registrations),
      _count: undefined,
    },
  });
}
