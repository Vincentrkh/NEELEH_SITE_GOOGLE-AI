import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { slugify } from "@/lib/format";

/** POST /api/comments — نظر بازدیدکننده روی مقاله */
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      postId?: string;
      slug?: string;
      name?: string;
      email?: string;
      content?: string;
      parentId?: string;
    };

    const content = (body.content ?? "").trim().slice(0, 2000);
    const name = (body.name ?? "").trim();

    if (name.length < 3) {
      return NextResponse.json({ error: "نام را کامل وارد کنید" }, { status: 400 });
    }
    if (content.length < 5) {
      return NextResponse.json({ error: "متن نظر کوتاه است" }, { status: 400 });
    }

    let post;
    if (body.postId) {
      post = await db.post.findUnique({ where: { id: body.postId } });
    } else if (body.slug) {
      post = await db.post.findUnique({ where: { slug: body.slug } });
    }
    if (!post) return NextResponse.json({ error: "مقاله یافت نشد" }, { status: 404 });

    const user = await getCurrentUser();

    const comment = await db.comment.create({
      data: {
        postId: post.id,
        name,
        email: body.email?.trim() || null,
        content,
        status: "PENDING",
        authorId: user?.id ?? null,
        parentId: body.parentId || null,
      },
    });

    return NextResponse.json({ ok: true, comment });
  } catch (e) {
    console.error("comment error", e);
    return NextResponse.json({ error: "خطا در ثبت نظر" }, { status: 500 });
  }
}
