import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPassword, setSessionCookie, verifyPassword } from "@/lib/auth";
import { isValidPhone, normalizePhone } from "@/lib/format";

type Body = {
  slug?: string;
  name?: string;
  phone?: string;
  password?: string;
  email?: string;
  field?: string;
  education?: string;
  note?: string;
};

/**
 * POST /api/register
 * ساخت حساب کاربری (در صورت نبودن) + ثبت‌نام در دوره در یک مرحله.
 * اگر حساب موجود باشد، رمز باید درست باشد؛ وگرنه حساب جدید ساخته می‌شود.
 */
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Body;
    const name = (body.name ?? "").trim();
    const phone = normalizePhone(body.phone ?? "");
    const password = body.password ?? "";
    const note = (body.note ?? "").trim().slice(0, 1000);

    if (name.length < 3) {
      return NextResponse.json(
        { error: "نام و نام خانوادگی را کامل وارد کنید" },
        { status: 400 }
      );
    }
    if (!isValidPhone(phone)) {
      return NextResponse.json(
        { error: "شماره موبایل معتبر نیست (مثال: ۰۹۱۲۱۲۳۴۵۶۷)" },
        { status: 400 }
      );
    }
    if (password.length < 6) {
      return NextResponse.json(
        { error: "رمز عبور باید حداقل ۶ کاراکتر باشد" },
        { status: 400 }
      );
    }

    const course = await db.course.findUnique({
      where: { slug: body.slug ?? "" },
    });
    if (!course) {
      return NextResponse.json({ error: "دوره موردنظر یافت نشد" }, { status: 404 });
    }
    if (!course.published) {
      return NextResponse.json(
        { error: "این دوره در حال حاضر قابل ثبت‌نام نیست" },
        { status: 400 }
      );
    }
    if (course.regStatus !== "OPEN") {
      return NextResponse.json(
        { error: "ظرفیت ثبت‌نام این دوره باز نیست" },
        { status: 400 }
      );
    }

    // ظرفیت باقیمانده
    const taken = await db.registration.count({
      where: { courseId: course.id, status: { not: "CANCELLED" } },
    });
    if (taken >= course.capacity) {
      return NextResponse.json(
        { error: "ظرفیت این دوره تکمیل شده است" },
        { status: 400 }
      );
    }

    // حساب کاربری: ایجاد یا استفاده از حساب موجود
    let user = await db.user.findUnique({ where: { phone } });
    let isNewUser = false;
    if (user) {
      // اگر از قبل حساب دارد، رمز واردشده باید درست باشد
      if (!verifyPassword(password, user.password)) {
        return NextResponse.json(
          {
            error:
              "این شماره قبلاً ثبت شده و رمز واردشده با رمز فعلی هم‌خوانی ندارد. از صفحه ورود استفاده کنید.",
          },
          { status: 409 }
        );
      }
      // اگر نام جدید داده شد، نام را به‌روزرسانی کن
      if (name && name !== user.name) {
        await db.user.update({
          where: { id: user.id },
          data: { name, email: body.email?.trim() || user.email, field: body.field?.trim() || user.field, education: body.education?.trim() || user.education },
        });
      }
    } else {
      // ساخت کاربر جدید + اختصاص نقش STUDENT
      const studentRole = await db.role.findUnique({ where: { name: "STUDENT" } });
      user = await db.user.create({
        data: {
          phone,
          name,
          password: hashPassword(password),
          email: body.email?.trim() || null,
          field: body.field?.trim() || null,
          education: body.education?.trim() || null,
          userRoles: studentRole
            ? { create: [{ roleId: studentRole.id }] }
            : undefined,
        },
      });
      isNewUser = true;
    }

    // ثبت‌نام (اگر تکراری نباشد)
    const existing = await db.registration.findUnique({
      where: {
        studentId_courseId: { studentId: user.id, courseId: course.id },
      },
    });
    if (existing && existing.status !== "CANCELLED") {
      return NextResponse.json(
        { error: "شما قبلاً در این دوره ثبت‌نام کرده‌اید" },
        { status: 409 }
      );
    }

    const registration = existing
      ? await db.registration.update({
          where: { id: existing.id },
          data: { status: "PENDING", note },
        })
      : await db.registration.create({
          data: { studentId: user.id, courseId: course.id, note },
        });

    await setSessionCookie(user.id);

    return NextResponse.json({
      ok: true,
      registrationId: registration.id,
      studentName: user.name,
      courseTitle: course.title,
      isNewUser,
    });
  } catch (e) {
    console.error("register error", e);
    return NextResponse.json(
      { error: "خطای غیرمنتظره در ثبت‌نام" },
      { status: 500 }
    );
  }
}
