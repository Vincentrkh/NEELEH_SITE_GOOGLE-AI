import type { Metadata } from "next";
import { Geist, Geist_Mono, Instrument_Serif } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";
import { LanguageProvider } from "@/components/language-provider";
import { ThemeStyleInjector } from "@/components/theme-style-injector";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const instrumentSerif = Instrument_Serif({
  variable: "--font-serif-display",
  subsets: ["latin"],
  weight: ["400"],
  style: ["normal", "italic"],
});

export const metadata: Metadata = {
  title: "Neeleh Academy | Smart Architectural Systems & AI-era Education",
  description:
    "Neeleh Academy — architecture education beyond tools: from Phase-2 drafting and BIM workflows to computational design with Grasshopper and AI-augmented architecture. 28 years of practice, based in Tehran.",
  keywords: [
    "آکادمی نیله",
    "Neeleh Academy",
    "architecture education",
    "AutoCAD Phase 2",
    "Revit BIM",
    "Grasshopper",
    "parametric design",
    "AI in architecture",
    "computational design",
    "Tehran architecture",
  ],
  authors: [{ name: "Neeleh Academy" }],
  openGraph: {
    title: "Neeleh Academy | Smart Architectural Systems & AI-era Education",
    description:
      "Architecture education beyond tools — from Phase-2 drafting to AI-augmented BIM and computational design.",
    type: "website",
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <ThemeStyleInjector />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${instrumentSerif.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem={false}
          disableTransitionOnChange
        >
          <LanguageProvider>
            {children}
            <Toaster />
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
