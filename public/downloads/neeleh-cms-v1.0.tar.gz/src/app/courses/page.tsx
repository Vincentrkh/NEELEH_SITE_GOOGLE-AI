import Link from "next/link";
import { db } from "@/lib/db";
import { faNumber, faPrice, TIER_LABEL, REG_STATUS_LABEL } from "@/lib/format";
import { ArrowUpRight, Clock, Users, CheckCircle2 } from "lucide-react";

export const dynamic = "force-dynamic";

const TIER_BADGE: Record<string, string> = {
  BEGINNER: "border-emerald-500/40 text-emerald-700 bg-emerald-50",
  INTERMEDIATE: "border-amber-500/40 text-amber-700 bg-amber-50",
  PRO: "border-rose-500/40 text-rose-700 bg-rose-50",
};

const TIER_STRIP: Record<string, string> = {
  BEGINNER: "from-emerald-500/20 to-emerald-700/5",
  INTERMEDIATE: "from-amber-500/20 to-amber-700/5",
  PRO: "from-rose-500/20 to-rose-700/5",
};

export default async function CoursesPage({
  searchParams,
}: {
  searchParams: Promise<{ tier?: string }>;
}) {
  const sp = await searchParams;
  const tierFilter = sp.tier;

  const where: { [k: string]: unknown } = { published: true };
  if (tierFilter && ["BEGINNER", "INTERMEDIATE", "PRO"].includes(tierFilter)) {
    where.tier = tierFilter;
  }

  const [courses, allCourses] = await Promise.all([
    db.course.findMany({
      where,
      orderBy: [{ tier: "asc" }, { sortOrder: "asc" }],
      include: {
        _count: {
          select: {
            registrations: { where: { status: { not: "CANCELLED" } } },
          },
        },
      },
    }),
    db.course.findMany({
      where: { published: true },
      select: { tier: true },
    }),
  ]);

  const tierCounts = {
    BEGINNER: allCourses.filter((c) => c.tier === "BEGINNER").length,
    INTERMEDIATE: allCourses.filter((c) => c.tier === "INTERMEDIATE").length,
    PRO: allCourses.filter((c) => c.tier === "PRO").length,
  };

  const tiers = [
    { key: "BEGINNER", label: "لایه ۱ · پایه", count: tierCounts.BEGINNER },
    { key: "INTERMEDIATE", label: "لایه ۲ · متوسط", count: tierCounts.INTERMEDIATE },
    { key: "PRO", label: "لایه ۳ · پیشرفته", count: tierCounts.PRO },
  ] as const;

  return (
    <main className="min-h-[100svh]">
      {/* Top bar */}
      <header className="border-b border-border">
        <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12 py-6 flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center gap-2.5 min-h-[44px]"
          >
            <span className="grid size-7 place-items-center rounded-md bg-foreground text-background font-bold text-sm">
              ن
            </span>
            <span className="text-sm font-medium">آکادمی نیله</span>
          </Link>
          <nav className="flex items-center gap-1">
            <Link
              href="/"
              className="flex min-h-[44px] items-center px-3 text-xs uppercase tracking-[0.14em] text-muted-foreground hover:text-foreground transition-colors"
            >
              خانه
            </Link>
            <Link
              href="/login"
              className="flex min-h-[44px] items-center px-3 text-xs uppercase tracking-[0.14em] text-muted-foreground hover:text-foreground transition-colors"
            >
              ورود
            </Link>
          </nav>
        </div>
      </header>

      <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12 py-12 sm:py-16">
        {/* Page header */}
        <div className="mb-12 sm:mb-16">
          <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-3">
            [ کاتالوگ دوره‌ها ]
          </p>
          <h1 className="text-4xl sm:text-6xl md:text-7xl font-medium tracking-[-0.04em] leading-[0.95]">
            نُه دوره
            <br />
            در سه سطح
          </h1>
          <p className="mt-6 text-base sm:text-lg leading-relaxed text-muted-foreground max-w-xl">
            از نقشه‌کشی فاز ۲ برای ورود به بازار کار، تا طراحی پارامتریک و تلفیق
            هوش مصنوعی در معماری — مسیر شما در نیله روشن است.
          </p>
        </div>

        {/* Tier filter strip */}
        <div className="grid sm:grid-cols-3 gap-3 mb-12">
          {tiers.map((t) => {
            const active = tierFilter === t.key;
            return (
              <Link
                key={t.key}
                href={active ? "/courses" : `/courses?tier=${t.key}`}
                className={`group rounded-lg border p-5 transition-colors ${
                  active
                    ? "border-foreground bg-secondary"
                    : "border-border hover:bg-secondary/50"
                } ${TIER_BADGE[t.key]}`}
              >
                <div className="flex items-start justify-between mb-2">
                  <span className="text-[10px] uppercase tracking-[0.14em] opacity-80">
                    {t.label}
                  </span>
                  <span className="text-2xl font-medium tabular-nums">
                    {faNumber(t.count)}
                  </span>
                </div>
                <div className="text-sm opacity-70">
                  {t.key === "BEGINNER" && "ورود به بازار کار"}
                  {t.key === "INTERMEDIATE" && "توسعه مهارت"}
                  {t.key === "PRO" && "طراحی محاسباتی و AI"}
                </div>
              </Link>
            );
          })}
        </div>

        {/* Course list grouped by tier */}
        {(["BEGINNER", "INTERMEDIATE", "PRO"] as const).map((tier) => {
          const list = courses.filter((c) => c.tier === tier);
          if (list.length === 0) return null;
          return (
            <section key={tier} className="mb-16">
              <div className="flex items-center gap-3 mb-6">
                <span
                  className={`inline-flex items-center gap-1.5 border px-2.5 py-1 text-[10px] uppercase tracking-[0.14em] ${TIER_BADGE[tier]}`}
                >
                  {TIER_LABEL[tier]}
                </span>
                <div className="flex-1 h-px bg-border" />
                <span className="text-xs text-muted-foreground tabular-nums">
                  {faNumber(list.length)} دوره
                </span>
              </div>

              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {list.map((c) => {
                  const remaining = Math.max(
                    0,
                    c.capacity - c._count.registrations
                  );
                  const full = remaining === 0;
                  return (
                    <Link
                      key={c.id}
                      href={`/courses/${c.slug}`}
                      className={`group relative rounded-lg border border-border bg-card overflow-hidden hover:border-foreground/30 transition-colors`}
                    >
                      {/* Banner strip with gradient */}
                      <div
                        className={`h-32 bg-gradient-to-br ${TIER_STRIP[tier]} relative`}
                      >
                        {c.bannerUrl && (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={c.bannerUrl}
                            alt=""
                            className="absolute inset-0 size-full object-cover opacity-60"
                          />
                        )}
                        <div className="absolute top-3 start-3">
                          <span
                            className={`inline-flex items-center gap-1.5 border px-2 py-0.5 text-[10px] uppercase tracking-[0.14em] bg-background/80 backdrop-blur ${TIER_BADGE[tier]}`}
                          >
                            {TIER_LABEL[tier]}
                          </span>
                        </div>
                        <div className="absolute bottom-3 end-3">
                          <span
                            className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] ${
                              full
                                ? "bg-amber-100 text-amber-800"
                                : "bg-emerald-100 text-emerald-800"
                            }`}
                          >
                            {REG_STATUS_LABEL[c.regStatus]}
                          </span>
                        </div>
                      </div>

                      {/* Card content */}
                      <div className="p-5">
                        <h2 className="text-base font-medium leading-snug mb-2 group-hover:text-foreground transition-colors line-clamp-2">
                          {c.title}
                        </h2>
                        <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2 mb-4">
                          {c.description}
                        </p>

                        {/* Tags */}
                        {c.tags && (
                          <div className="flex flex-wrap gap-1 mb-4">
                            {c.tags
                              .split(",")
                              .filter(Boolean)
                              .slice(0, 3)
                              .map((t) => (
                                <span
                                  key={t}
                                  className="text-[10px] uppercase tracking-[0.1em] border border-border px-1.5 py-0.5 text-muted-foreground"
                                >
                                  {t.trim()}
                                </span>
                              ))}
                          </div>
                        )}

                        {/* Meta */}
                        <div className="flex items-center justify-between pt-4 border-t border-border">
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            {c.durationHrs > 0 && (
                              <span className="flex items-center gap-1">
                                <Clock className="size-3" />
                                {faNumber(c.durationHrs)} ساعت
                              </span>
                            )}
                            <span className="flex items-center gap-1">
                              <Users className="size-3" />
                              {faNumber(remaining)}/{faNumber(c.capacity)}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            {c.price > 0 ? (
                              <span className="text-sm font-medium tabular-nums">
                                {faPrice(c.price)}
                              </span>
                            ) : (
                              <span className="text-xs text-muted-foreground">تماس بگیرید</span>
                            )}
                            <ArrowUpRight className="size-3.5 text-muted-foreground group-hover:text-foreground group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-all" />
                          </div>
                        </div>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </section>
          );
        })}

        {courses.length === 0 && (
          <div className="text-center py-20">
            <CheckCircle2 className="size-8 mx-auto text-muted-foreground mb-4" />
            <p className="text-sm text-muted-foreground">
              دوره‌ای در این سطح یافت نشد.
            </p>
          </div>
        )}
      </div>
    </main>
  );
}
