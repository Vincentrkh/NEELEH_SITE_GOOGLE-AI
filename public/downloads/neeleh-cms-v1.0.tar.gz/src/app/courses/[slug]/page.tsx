import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import {
  faNumber,
  faPrice,
  TIER_LABEL,
  REG_STATUS_LABEL,
} from "@/lib/format";
import {
  Clock,
  Users,
  CheckCircle2,
  ArrowLeft,
  ArrowUpRight,
  Calendar,
  MapPin,
  BookOpen,
  GraduationCap,
} from "lucide-react";

export const dynamic = "force-dynamic";

const TIER_BADGE: Record<string, string> = {
  BEGINNER: "border-emerald-500/40 text-emerald-700 bg-emerald-50",
  INTERMEDIATE: "border-amber-500/40 text-amber-700 bg-amber-50",
  PRO: "border-rose-500/40 text-rose-700 bg-rose-50",
};

const TIER_GRADIENT: Record<string, string> = {
  BEGINNER: "from-emerald-500/20 to-emerald-700/5",
  INTERMEDIATE: "from-amber-500/20 to-amber-700/5",
  PRO: "from-rose-500/20 to-rose-700/5",
};

export default async function CoursePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  const course = await db.course.findUnique({
    where: { slug },
    include: {
      sections: { orderBy: { order: "asc" } },
      _count: {
        select: {
          registrations: { where: { status: { not: "CANCELLED" } } },
        },
      },
    },
  });

  if (!course || !course.published) notFound();

  const remaining = Math.max(0, course.capacity - course._count.registrations);
  const isOpen = course.regStatus === "OPEN" && remaining > 0;
  const tags = course.tags ? course.tags.split(",").filter(Boolean) : [];
  const outputs = course.outputs ? course.outputs.split("\n").filter(Boolean) : [];

  return (
    <main className="min-h-[100svh]">
      {/* Top bar */}
      <header className="border-b border-border sticky top-0 bg-background/80 backdrop-blur z-30">
        <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12 py-4 flex items-center justify-between">
          <Link
            href="/courses"
            className="flex items-center gap-2 min-h-[44px]"
          >
            <span className="grid size-7 place-items-center rounded-md bg-foreground text-background font-bold text-sm">
              ن
            </span>
            <span className="text-sm font-medium">آکادمی نیله</span>
          </Link>
          <Link
            href="/courses"
            className="flex min-h-[44px] items-center gap-1 text-xs uppercase tracking-[0.14em] text-muted-foreground hover:text-foreground transition-colors"
          >
            همه دوره‌ها
            <ArrowLeft className="size-3.5 rtl:-scale-x-100" />
          </Link>
        </div>
      </header>

      {/* Hero banner */}
      <section className="relative overflow-hidden border-b border-border">
        <div
          className={`absolute inset-0 bg-gradient-to-br ${TIER_GRADIENT[course.tier]}`}
        />
        {course.bannerUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={course.bannerUrl}
            alt=""
            className="absolute inset-0 size-full object-cover opacity-30"
          />
        )}
        <div className="relative mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12 py-12 sm:py-16">
          <div className="flex flex-wrap items-center gap-3 mb-6">
            <span
              className={`inline-flex items-center gap-1.5 border px-2.5 py-1 text-[10px] uppercase tracking-[0.14em] ${TIER_BADGE[course.tier]}`}
            >
              {TIER_LABEL[course.tier]}
            </span>
            {tags.slice(0, 4).map((t) => (
              <span
                key={t}
                className="text-[10px] uppercase tracking-[0.1em] border border-border px-2 py-1 text-muted-foreground"
              >
                {t.trim()}
              </span>
            ))}
          </div>

          <h1 className="text-3xl sm:text-5xl md:text-6xl font-medium tracking-[-0.03em] leading-[1.05] max-w-4xl">
            {course.title}
          </h1>

          {course.description && (
            <p className="mt-6 text-base sm:text-lg leading-relaxed text-muted-foreground max-w-2xl">
              {course.description}
            </p>
          )}
        </div>
      </section>

      <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12 py-12 sm:py-16">
        <div className="grid lg:grid-cols-[1fr_360px] gap-12">
          {/* Main column */}
          <div className="space-y-12 min-w-0">
            {/* About */}
            {course.about && (
              <section>
                <h2 className="text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4">
                  درباره دوره
                </h2>
                <div className="prose prose-sm sm:prose-base max-w-none">
                  {course.about.split("\n").map((p, i) => (
                    <p key={i} className="text-base leading-9 text-foreground/90 mb-4">
                      {p}
                    </p>
                  ))}
                </div>
              </section>
            )}

            {/* Outputs */}
            {outputs.length > 0 && (
              <section>
                <h2 className="text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4">
                  خروجی‌های دوره
                </h2>
                <ul className="grid sm:grid-cols-2 gap-3">
                  {outputs.map((o, i) => (
                    <li
                      key={i}
                      className="flex items-start gap-3 p-4 rounded-md border border-border bg-card"
                    >
                      <CheckCircle2 className="size-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span className="text-sm leading-relaxed">{o}</span>
                    </li>
                  ))}
                </ul>
              </section>
            )}

            {/* Sections / syllabus */}
            {course.sections.length > 0 && (
              <section>
                <h2 className="text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4">
                  سرفصل‌های دوره
                </h2>
                <ol className="space-y-3">
                  {course.sections.map((s, i) => {
                    const items = s.items
                      ? s.items.split("\n").filter(Boolean)
                      : [];
                    return (
                      <li
                        key={s.id}
                        className="rounded-md border border-border bg-card overflow-hidden"
                      >
                        <div className="flex items-center gap-3 p-4 border-b border-border bg-secondary/30">
                          <span className="grid size-7 place-items-center rounded-full bg-foreground text-background text-xs font-mono tabular-nums shrink-0">
                            {faNumber(i + 1)}
                          </span>
                          <h3 className="text-sm sm:text-base font-medium">{s.title}</h3>
                        </div>
                        {items.length > 0 && (
                          <ul className="p-4 space-y-2">
                            {items.map((it, j) => (
                              <li
                                key={j}
                                className="flex items-start gap-3 text-sm text-muted-foreground"
                              >
                                <span className="text-foreground/40 mt-1">—</span>
                                <span className="leading-relaxed">{it}</span>
                              </li>
                            ))}
                          </ul>
                        )}
                      </li>
                    );
                  })}
                </ol>
              </section>
            )}

            {/* Prerequisites */}
            {course.prereqs && (
              <section>
                <h2 className="text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4">
                  پیش‌نیازها
                </h2>
                <p className="text-sm leading-relaxed text-foreground/80 p-4 rounded-md border border-border bg-card">
                  {course.prereqs}
                </p>
              </section>
            )}
          </div>

          {/* Sidebar */}
          <aside className="lg:sticky lg:top-24 lg:self-start space-y-4">
            {/* Registration card */}
            <div className="rounded-lg border border-border bg-card p-6 space-y-5">
              {/* Status */}
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                  وضعیت ثبت‌نام
                </span>
                <span
                  className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs ${
                    isOpen
                      ? "bg-emerald-100 text-emerald-800"
                      : "bg-amber-100 text-amber-800"
                  }`}
                >
                  {isOpen ? REG_STATUS_LABEL.OPEN : REG_STATUS_LABEL.FULL}
                </span>
              </div>

              {/* Price */}
              <div>
                <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground mb-1">
                  شهریه دوره
                </div>
                <div className="text-2xl font-medium tabular-nums">
                  {course.price > 0 ? faPrice(course.price) : "تماس بگیرید"}
                </div>
              </div>

              {/* Capacity */}
              <div className="grid grid-cols-2 gap-3 pt-4 border-t border-border">
                <div>
                  <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground mb-1">
                    ظرفیت کلاس
                  </div>
                  <div className="text-lg font-medium tabular-nums">
                    {faNumber(course.capacity)} نفر
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground mb-1">
                    ظرفیت باقیمانده
                  </div>
                  <div className="text-lg font-medium tabular-nums text-emerald-700">
                    {faNumber(remaining)} نفر
                  </div>
                </div>
              </div>

              {/* Duration */}
              {course.durationHrs > 0 && (
                <div className="flex items-center gap-3 text-sm text-muted-foreground pt-4 border-t border-border">
                  <Clock className="size-4" />
                  <span>مدت دوره: {faNumber(course.durationHrs)} ساعت</span>
                </div>
              )}

              {/* CTA */}
              {isOpen ? (
                <Link
                  href={`/register/${course.slug}`}
                  className="flex min-h-[52px] items-center justify-center gap-2 bg-foreground text-background rounded-md px-6 text-sm font-medium uppercase tracking-[0.12em] hover:opacity-90 transition-opacity"
                >
                  ثبت‌نام دوره
                  <ArrowUpRight className="size-4 rtl:-scale-x-100" />
                </Link>
              ) : (
                <div className="text-center text-xs text-muted-foreground p-4 border border-dashed border-border rounded-md">
                  ظرفیت این دوره تکمیل شده است.
                  <br />
                  برای دوره بعدی با ما در تماس باشید.
                </div>
              )}

              <p className="text-[10px] leading-relaxed text-muted-foreground/70 text-center">
                پرداخت شهریه پس از تماس کارشناسان انجام می‌شود.
              </p>
            </div>

            {/* Logistics card */}
            <div className="rounded-lg border border-border bg-card p-6 space-y-3 text-sm">
              <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground mb-2">
                جزئیات برگزاری
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="size-4 text-muted-foreground shrink-0 mt-0.5" />
                <div>
                  <div>حضوری — در محل آکادمی نیله</div>
                  <div className="text-xs text-muted-foreground mt-0.5">تهران</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Calendar className="size-4 text-muted-foreground shrink-0 mt-0.5" />
                <div>
                  <div>شنبه تا چهارشنبه</div>
                  <div className="text-xs text-muted-foreground mt-0.5">ساعات کاری: ۹ تا ۱۸</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <BookOpen className="size-4 text-muted-foreground shrink-0 mt-0.5" />
                <div>
                  <div>دسته: {course.category}</div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <GraduationCap className="size-4 text-muted-foreground shrink-0 mt-0.5" />
                <div>
                  <div>سطح: {TIER_LABEL[course.tier]}</div>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </main>
  );
}
