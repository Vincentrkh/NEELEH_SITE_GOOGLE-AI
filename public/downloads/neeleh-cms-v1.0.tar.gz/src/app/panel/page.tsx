import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import {
  faNumber,
  faDate,
  TIER_LABEL,
  REG_LABEL,
  PAYMENT_LABEL,
  RESOURCE_KIND_LABEL,
} from "@/lib/format";
import {
  ArrowRight,
  BookOpen,
  Download,
  CheckCircle2,
  Clock,
  FileText,
} from "lucide-react";
import { ProfileEditor } from "@/components/profile-editor";

export const dynamic = "force-dynamic";

const TIER_BADGE: Record<string, string> = {
  BEGINNER: "border-emerald-500/40 text-emerald-700 bg-emerald-50",
  INTERMEDIATE: "border-amber-500/40 text-amber-700 bg-amber-50",
  PRO: "border-rose-500/40 text-rose-700 bg-rose-50",
};

export default async function PanelPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/panel");

  const [registrations, totalCount] = await Promise.all([
    db.registration.findMany({
      where: { studentId: user.id, status: { not: "CANCELLED" } },
      orderBy: { createdAt: "desc" },
      include: {
        course: {
          select: {
            id: true,
            slug: true,
            title: true,
            tier: true,
            category: true,
            durationHrs: true,
            bannerUrl: true,
            sections: { select: { id: true, title: true, items: true, order: true }, orderBy: { order: "asc" } },
            resources: {
              select: {
                id: true,
                title: true,
                kind: true,
                url: true,
                file: { select: { url: true, filename: true, mimeType: true, size: true } },
                createdAt: true,
              },
              orderBy: { createdAt: "desc" },
            },
            sessions: { select: { id: true, title: true, date: true, order: true }, orderBy: { order: "asc" } },
          },
        },
        attendance: { select: { sessionId: true, present: true } },
      },
    }),
    db.registration.count({
      where: { studentId: user.id, status: { not: "CANCELLED" } },
    }),
  ]);

  const confirmedCount = registrations.filter((r) => r.status === "CONFIRMED").length;
  const pendingCount = registrations.filter((r) => r.status === "PENDING").length;

  return (
    <main className="min-h-[100svh]">
      <header className="border-b border-border sticky top-0 bg-background/80 backdrop-blur z-30">
        <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 min-h-[44px]">
            <span className="grid size-7 place-items-center rounded-md bg-foreground text-background font-bold text-sm">
              ن
            </span>
            <span className="text-sm font-medium">آکادمی نیله</span>
          </Link>
          <nav className="flex items-center gap-1">
            <Link
              href="/courses"
              className="flex min-h-[44px] items-center px-3 text-xs uppercase tracking-[0.14em] text-muted-foreground hover:text-foreground transition-colors"
            >
              دوره‌ها
            </Link>
            {(user.roles.includes("ADMIN") || user.roles.includes("EDITOR")) && (
              <Link
                href="/dashboard"
                className="flex min-h-[44px] items-center px-3 text-xs uppercase tracking-[0.14em] text-muted-foreground hover:text-foreground transition-colors"
              >
                پنل ادمین
              </Link>
            )}
          </nav>
        </div>
      </header>

      <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12 py-10 sm:py-14">
        <div className="mb-10">
          <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
            [ پنل هنرجو ]
          </p>
          <h1 className="text-3xl sm:text-4xl font-medium tracking-[-0.03em]">
            سلام، {user.name}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {faDate(new Date())} — خلاصه‌ای از فعالیت شما در آکادمی نیله.
          </p>
        </div>

        <div className="grid grid-cols-3 gap-3 mb-10">
          <StatCard icon={BookOpen} label="دوره‌های ثبت‌نام‌شده" value={faNumber(totalCount)} />
          <StatCard icon={CheckCircle2} label="تایید شده" value={faNumber(confirmedCount)} highlight />
          <StatCard icon={Clock} label="در انتظار تایید" value={faNumber(pendingCount)} />
        </div>

        <div className="grid lg:grid-cols-[1fr_360px] gap-8">
          <section className="min-w-0">
            <div className="flex items-center justify-between border-b border-border pb-3 mb-6">
              <h2 className="text-sm font-medium uppercase tracking-[0.14em]">
                دوره‌های من
              </h2>
              <Link
                href="/courses"
                className="flex min-h-[44px] items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                دوره جدید
                <ArrowRight className="size-3 rtl:-scale-x-100" />
              </Link>
            </div>

            {registrations.length === 0 ? (
              <div className="rounded-lg border border-dashed border-border p-10 text-center">
                <BookOpen className="size-8 mx-auto text-muted-foreground mb-3" />
                <p className="text-sm text-muted-foreground mb-4">
                  هنوز در دوره‌ای ثبت‌نام نکرده‌اید.
                </p>
                <Link
                  href="/courses"
                  className="inline-flex min-h-[44px] items-center rounded-md bg-foreground text-background px-5 text-sm font-medium hover:opacity-90 transition-opacity"
                >
                  مشاهده دوره‌ها
                </Link>
              </div>
            ) : (
              <ul className="space-y-4">
                {registrations.map((r) => {
                  const attendancePresent = r.attendance.filter((a) => a.present).length;
                  const attendanceTotal = r.course.sessions.length;
                  const attendanceRate =
                    attendanceTotal > 0
                      ? Math.round((attendancePresent / attendanceTotal) * 100)
                      : null;
                  const resources =
                    r.status === "CONFIRMED" ? r.course.resources : [];
                  return (
                    <li
                      key={r.id}
                      className="rounded-lg border border-border bg-card overflow-hidden"
                    >
                      <div className="p-5 border-b border-border">
                        <div className="flex items-start gap-3">
                          <span
                            className={`inline-flex shrink-0 items-center gap-1.5 border px-2 py-0.5 text-[10px] uppercase tracking-[0.14em] ${TIER_BADGE[r.course.tier]}`}
                          >
                            {TIER_LABEL[r.course.tier]}
                          </span>
                          <div className="flex-1 min-w-0">
                            <Link
                              href={`/courses/${r.course.slug}`}
                              className="block font-medium hover:text-foreground transition-colors line-clamp-2"
                            >
                              {r.course.title}
                            </Link>
                            <div className="text-xs text-muted-foreground mt-1">
                              {r.course.category} • {faNumber(r.course.durationHrs)} ساعت
                            </div>
                          </div>
                          <div className="flex flex-col gap-1 items-end shrink-0">
                            <span
                              className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] ${
                                r.status === "CONFIRMED"
                                  ? "bg-emerald-100 text-emerald-800"
                                  : "bg-amber-100 text-amber-800"
                              }`}
                            >
                              {REG_LABEL[r.status]}
                            </span>
                            <span
                              className={`text-[10px] ${
                                r.paymentStatus === "PAID"
                                  ? "text-emerald-700"
                                  : "text-muted-foreground"
                              }`}
                            >
                              {PAYMENT_LABEL[r.paymentStatus]}
                            </span>
                          </div>
                        </div>
                        <div className="mt-3 flex items-center gap-4 text-xs text-muted-foreground">
                          <span>ثبت‌نام: {faDate(r.createdAt)}</span>
                          {attendanceRate !== null && (
                            <span>
                              حضور: {faNumber(attendanceRate)}٪
                              <span className="text-muted-foreground/60">
                                {" "}
                                ({faNumber(attendancePresent)}/{faNumber(attendanceTotal)})
                              </span>
                            </span>
                          )}
                        </div>
                      </div>

                      {r.status === "CONFIRMED" && resources.length > 0 && (
                        <div className="p-5 bg-secondary/20">
                          <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground mb-3">
                            فایل‌ها و جزوات دوره
                          </div>
                          <ul className="grid sm:grid-cols-2 gap-2">
                            {resources.map((res) => {
                              const url = res.file?.url ?? res.url;
                              if (!url) return null;
                              return (
                                <li key={res.id}>
                                  <a
                                    href={url}
                                    target={url.startsWith("http") ? "_blank" : undefined}
                                    rel="noopener noreferrer"
                                    className="flex min-h-[44px] items-center gap-3 rounded-md border border-border bg-background px-3 py-2 hover:border-foreground/30 transition-colors"
                                  >
                                    <FileText className="size-4 text-muted-foreground shrink-0" />
                                    <div className="min-w-0 flex-1">
                                      <div className="text-sm truncate">{res.title}</div>
                                      <div className="text-[10px] text-muted-foreground">
                                        {RESOURCE_KIND_LABEL[res.kind] ?? res.kind}
                                      </div>
                                    </div>
                                    <Download className="size-3.5 text-muted-foreground shrink-0" />
                                  </a>
                                </li>
                              );
                            })}
                          </ul>
                        </div>
                      )}

                      {r.status === "PENDING" && (
                        <div className="p-4 bg-amber-50 border-t border-amber-200">
                          <p className="text-xs text-amber-800 leading-relaxed">
                            ثبت‌نام شما در انتظار تایید است. پس از تایید، فایل‌ها و جزوات دوره قابل دانلود خواهد بود.
                          </p>
                        </div>
                      )}
                    </li>
                  );
                })}
              </ul>
            )}
          </section>

          <aside className="lg:sticky lg:top-24 lg:self-start">
            <ProfileEditor
              initial={{
                name: user.name,
                phone: user.phone,
                email: user.email,
                field: user.field,
                education: user.education,
                bio: user.bio,
              }}
            />
          </aside>
        </div>
      </div>
    </main>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  highlight,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div className="rounded-lg border border-border bg-card p-4 sm:p-5">
      <div className="flex items-start justify-between mb-2">
        <Icon className={`size-4 ${highlight ? "text-emerald-600" : "text-muted-foreground"}`} />
      </div>
      <div className="text-xl sm:text-2xl font-medium tabular-nums">{value}</div>
      <div className="mt-0.5 text-xs text-muted-foreground">{label}</div>
    </div>
  );
}
