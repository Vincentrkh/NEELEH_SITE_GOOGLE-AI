import { db } from "@/lib/db";

/**
 * تنظیمات سایت — key-value از دیتابیس.
 * در صورتی که دیتابیس در دسترس نباشد، fallback خالی برمی‌گردد.
 */

export type SiteSettings = Record<string, string>;

const FALLBACK_SETTINGS: SiteSettings = {
  "hero.title": "آکادمی نیله",
  "hero.subtitle": "سیستم‌های هوشمند معماری و آموزش عصر AI",
  "hero.tagline": "معماری را فراتر از ابزارها یاد بگیرید",
  "hero.intro":
    "استودیوی تخصصی نیله، با تکیه بر تجربه حرفه‌ای و تسلط بر ابزارهای نوین طراحی محاسباتی، مدلسازی اطلاعات ساختمان (BIM) و هوش مصنوعی، مسیر نوین یادگیری و ارتقای مهندسی معماری را ترسیم می‌کند.",
  "contact.phone": "۰۲۱ - ۸۸ ۰۰ ۰۰ ۰۰",
  "contact.email": "hello@neeleh.academy",
  "contact.address": "تهران — محل برگزاری کلاس‌ها در آکادمی نیله",
  "contact.hours": "شنبه تا چهارشنبه، ۹ تا ۱۸",
  "stats.years": "۲۸+",
  "stats.courses": "۹",
  "stats.graduates": "۳۰۰+",
  "stats.instructors": "۱",
  "social.instagram": "https://instagram.com",
  "social.telegram": "https://telegram.org",
  "social.linkedin": "https://linkedin.com",
  "social.youtube": "https://youtube.com",
  "social.behance": "https://behance.net",
};

/** همه تنظیمات را به‌صورت یک map برمی‌گرداند. */
export async function getSiteSettings(): Promise<SiteSettings> {
  try {
    const rows = await db.setting.findMany();
    const map: SiteSettings = {};
    for (const r of rows) {
      map[r.key] = r.value;
    }
    // merge با fallback — اگر کلیدی در دیتابیس نبود، از fallback استفاده کن
    return { ...FALLBACK_SETTINGS, ...map };
  } catch {
    return { ...FALLBACK_SETTINGS };
  }
}

/** یک تنظیم خاص را برمی‌گرداند. */
export async function getSetting(key: string): Promise<string> {
  const all = await getSiteSettings();
  return all[key] ?? "";
}

/**
 * لیست کلیدهای تنظیمات برای نمایش در پنل ادمین.
 * به‌صورت گروه‌بندی‌شده برای UX بهتر.
 */
export const SETTINGS_GROUPS: {
  label: string;
  key: string;
  items: { key: string; label: string; type?: "text" | "textarea" }[];
}[] = [
  {
    label: "بخش هیرو (صفحه اصلی)",
    key: "hero",
    items: [
      { key: "hero.title", label: "عنوان اصلی" },
      { key: "hero.subtitle", label: "زیرعنوان" },
      { key: "hero.tagline", label: "شعار (تأکیدی)" },
      { key: "hero.intro", label: "معرفی کوتاه", type: "textarea" },
    ],
  },
  {
    label: "اطلاعات تماس",
    key: "contact",
    items: [
      { key: "contact.phone", label: "شماره تلفن" },
      { key: "contact.email", label: "ایمیل" },
      { key: "contact.address", label: "آدرس", type: "textarea" },
      { key: "contact.hours", label: "ساعات کاری" },
    ],
  },
  {
    label: "آمار صفحه اصلی",
    key: "stats",
    items: [
      { key: "stats.years", label: "سال تجربه" },
      { key: "stats.courses", label: "تعداد دوره" },
      { key: "stats.graduates", label: "فارغ‌التحصیلان" },
      { key: "stats.instructors", label: "تعداد مدرس" },
    ],
  },
  {
    label: "شبکه‌های اجتماعی",
    key: "social",
    items: [
      { key: "social.instagram", label: "اینستاگرام (URL)" },
      { key: "social.telegram", label: "تلگرام (URL)" },
      { key: "social.linkedin", label: "لینکدین (URL)" },
      { key: "social.youtube", label: "یوتیوب (URL)" },
      { key: "social.behance", label: "بیهانس (URL)" },
    ],
  },
];
