/**
 * لیست ثابت مجوزهای قابل اختصاص به نقش‌ها.
 * هر مجوز یک عملیات مشخص در سیستم را کنترل می‌کند.
 *
 * ادمین (نقش ADMIN) همیشه همه مجوزها را دارد — لازم نیست دستی اختصاص دهیم.
 */

export const PERMISSIONS = {
  // ── دوره‌ها ──
  COURSE_VIEW: "course.view",
  COURSE_CREATE: "course.create",
  COURSE_UPDATE: "course.update",
  COURSE_DELETE: "course.delete",
  COURSE_PUBLISH: "course.publish",

  // ── ثبت‌نام ──
  REGISTRATION_VIEW: "registration.view",
  REGISTRATION_UPDATE: "registration.update",
  REGISTRATION_DELETE: "registration.delete",
  REGISTRATION_EXPORT: "registration.export",

  // ── لیدها ──
  LEAD_VIEW: "lead.view",
  LEAD_UPDATE: "lead.update",
  LEAD_DELETE: "lead.delete",

  // ── فایل‌ها ──
  FILE_UPLOAD: "file.upload",
  FILE_DELETE: "file.delete",

  // ── کاربران و نقش‌ها ──
  USER_VIEW: "user.view",
  USER_CREATE: "user.create",
  USER_UPDATE: "user.update",
  USER_DELETE: "user.delete",
  ROLE_MANAGE: "role.manage",

  // ── تنظیمات و تم ──
  SETTING_MANAGE: "setting.manage",
  THEME_MANAGE: "theme.manage",

  // ── وبلاگ ──
  POST_VIEW: "post.view",
  POST_CREATE: "post.create",
  POST_UPDATE: "post.update",
  POST_DELETE: "post.delete",
  POST_PUBLISH: "post.publish",
  COMMENT_MODERATE: "comment.moderate",

  // ── صفحات ساکن ──
  PAGE_MANAGE: "page.manage",

  // ── پنل هنرجو (برای کاربر STUDENT) ──
  PANEL_VIEW: "panel.view",
} as const;

export type PermissionKey = keyof typeof PERMISSIONS;
export type PermissionValue = (typeof PERMISSIONS)[PermissionKey];

/**
 * همه مجوزها به‌صورت یک لیست، برای seed اولیه دیتابیس.
 */
export const ALL_PERMISSIONS: { key: string; label: string }[] = [
  { key: PERMISSIONS.COURSE_VIEW, label: "مشاهده دوره‌ها" },
  { key: PERMISSIONS.COURSE_CREATE, label: "ساخت دوره" },
  { key: PERMISSIONS.COURSE_UPDATE, label: "ویرایش دوره" },
  { key: PERMISSIONS.COURSE_DELETE, label: "حذف دوره" },
  { key: PERMISSIONS.COURSE_PUBLISH, label: "انتشار/عدم انتشار دوره" },
  { key: PERMISSIONS.REGISTRATION_VIEW, label: "مشاهده ثبت‌نام‌ها" },
  { key: PERMISSIONS.REGISTRATION_UPDATE, label: "تغییر وضعیت ثبت‌نام" },
  { key: PERMISSIONS.REGISTRATION_DELETE, label: "حذف ثبت‌نام" },
  { key: PERMISSIONS.REGISTRATION_EXPORT, label: "خروجی اکسل ثبت‌نام‌ها" },
  { key: PERMISSIONS.LEAD_VIEW, label: "مشاهده لیدها" },
  { key: PERMISSIONS.LEAD_UPDATE, label: "تغییر وضعیت لید" },
  { key: PERMISSIONS.LEAD_DELETE, label: "حذف لید" },
  { key: PERMISSIONS.FILE_UPLOAD, label: "آپلود فایل" },
  { key: PERMISSIONS.FILE_DELETE, label: "حذف فایل" },
  { key: PERMISSIONS.USER_VIEW, label: "مشاهده کاربران" },
  { key: PERMISSIONS.USER_CREATE, label: "ساخت کاربر" },
  { key: PERMISSIONS.USER_UPDATE, label: "ویرایش کاربر" },
  { key: PERMISSIONS.USER_DELETE, label: "حذف کاربر" },
  { key: PERMISSIONS.ROLE_MANAGE, label: "مدیریت نقش‌ها" },
  { key: PERMISSIONS.SETTING_MANAGE, label: "مدیریت تنظیمات" },
  { key: PERMISSIONS.THEME_MANAGE, label: "مدیریت تم" },
  { key: PERMISSIONS.POST_VIEW, label: "مشاهده مقالات" },
  { key: PERMISSIONS.POST_CREATE, label: "ساخت مقاله" },
  { key: PERMISSIONS.POST_UPDATE, label: "ویرایش مقاله" },
  { key: PERMISSIONS.POST_DELETE, label: "حذف مقاله" },
  { key: PERMISSIONS.POST_PUBLISH, label: "انتشار مقاله" },
  { key: PERMISSIONS.COMMENT_MODERATE, label: "مدیریت نظرات" },
  { key: PERMISSIONS.PAGE_MANAGE, label: "مدیریت صفحات ساکن" },
  { key: PERMISSIONS.PANEL_VIEW, label: "دسترسی به پنل هنرجو" },
];

/**
 * دسته‌بندی مجوزها — برای نمایش در پنل ادمین به‌صورت گروهی.
 */
export const PERMISSION_GROUPS: {
  label: string;
  permissions: { key: string; label: string }[];
}[] = [
  {
    label: "دوره‌ها",
    permissions: ALL_PERMISSIONS.filter((p) => p.key.startsWith("course.")),
  },
  {
    label: "ثبت‌نام",
    permissions: ALL_PERMISSIONS.filter((p) => p.key.startsWith("registration.")),
  },
  {
    label: "لیدها",
    permissions: ALL_PERMISSIONS.filter((p) => p.key.startsWith("lead.")),
  },
  {
    label: "فایل‌ها",
    permissions: ALL_PERMISSIONS.filter((p) => p.key.startsWith("file.")),
  },
  {
    label: "کاربران و نقش‌ها",
    permissions: ALL_PERMISSIONS.filter((p) =>
      ["user.", "role."].some((prefix) => p.key.startsWith(prefix))
    ),
  },
  {
    label: "تنظیمات و تم",
    permissions: ALL_PERMISSIONS.filter((p) =>
      ["setting.", "theme."].some((prefix) => p.key.startsWith(prefix))
    ),
  },
  {
    label: "وبلاگ",
    permissions: ALL_PERMISSIONS.filter((p) =>
      ["post.", "comment."].some((prefix) => p.key.startsWith(prefix))
    ),
  },
  {
    label: "صفحات ساکن",
    permissions: ALL_PERMISSIONS.filter((p) => p.key.startsWith("page.")),
  },
  {
    label: "پنل هنرجو",
    permissions: ALL_PERMISSIONS.filter((p) => p.key.startsWith("panel.")),
  },
];

/** بررسی اینکه آیا مجوز داده‌شده در لیست موجود است. */
export function hasPermission(
  userPermissions: string[],
  permission: string
): boolean {
  return userPermissions.includes(permission);
}

/**
 * بررسی دسترسی به یک مسیر پنل ادمین بر اساس pattern.
 * مثلاً /dashboard/courses → COURSE_VIEW
 */
export function permissionForPath(path: string): string | null {
  const segments = path.replace(/^\/dashboard\/?/, "").split("/").filter(Boolean);
  if (segments.length === 0) return null; // داشبورد اصلی — همه کاربران احراز هویت‌شده
  const section = segments[0];
  const map: Record<string, string> = {
    courses: PERMISSIONS.COURSE_VIEW,
    registrations: PERMISSIONS.REGISTRATION_VIEW,
    leads: PERMISSIONS.LEAD_VIEW,
    files: PERMISSIONS.FILE_UPLOAD,
    users: PERMISSIONS.USER_VIEW,
    roles: PERMISSIONS.ROLE_MANAGE,
    settings: PERMISSIONS.SETTING_MANAGE,
    theme: PERMISSIONS.THEME_MANAGE,
    posts: PERMISSIONS.POST_VIEW,
    comments: PERMISSIONS.COMMENT_MODERATE,
    pages: PERMISSIONS.PAGE_MANAGE,
  };
  return map[section] ?? null;
}
