// قالب‌بندی اعداد و قیمت — فارسی

const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export function toFaDigits(input: string | number): string {
  return String(input).replace(/\d/g, (d) => FA_DIGITS[Number(d)]);
}

export function faPrice(toman: number): string {
  if (!toman) return "تماس بگیرید";
  return `${toFaDigits(toman.toLocaleString("en-US"))} تومان`;
}

export function faNumber(n: number): string {
  return toFaDigits(n.toLocaleString("en-US"));
}

export function faDate(d: Date | string | null | undefined): string {
  if (!d) return "—";
  const date = typeof d === "string" ? new Date(d) : d;
  return new Intl.DateTimeFormat("fa-IR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(date);
}

export function faDateTime(d: Date | string | null | undefined): string {
  if (!d) return "—";
  const date = typeof d === "string" ? new Date(d) : d;
  return new Intl.DateTimeFormat("fa-IR", {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export const TIER_LABEL: Record<string, string> = {
  BEGINNER: "مبتدی",
  INTERMEDIATE: "متوسط",
  PRO: "حرفه‌ای",
};

export const TIER_COLOR: Record<string, string> = {
  BEGINNER: "bg-emerald-100 text-emerald-900 border-emerald-200",
  INTERMEDIATE: "bg-amber-100 text-amber-900 border-amber-200",
  PRO: "bg-rose-100 text-rose-900 border-rose-200",
};

export const REG_STATUS_LABEL: Record<string, string> = {
  OPEN: "ثبت‌نام فعال",
  FULL: "تکمیل ظرفیت",
  CLOSED: "ثبت‌نام بسته",
};

export const PAYMENT_LABEL: Record<string, string> = {
  UNPAID: "پرداخت نشده",
  PAID: "پرداخت شده",
};

export const REG_LABEL: Record<string, string> = {
  PENDING: "در انتظار تایید",
  CONFIRMED: "تایید شده",
  CANCELLED: "لغو شده",
};

export const LEAD_STATUS_LABEL: Record<string, string> = {
  NEW: "جدید",
  CONTACTED: "تماس گرفته شد",
  CONVERTED: "تبدیل به هنرجو شد",
};

export const POST_STATUS_LABEL: Record<string, string> = {
  DRAFT: "پیش‌نویس",
  PUBLISHED: "منتشر شده",
  ARCHIVED: "بایگانی",
};

export const COMMENT_STATUS_LABEL: Record<string, string> = {
  PENDING: "در انتظار بررسی",
  APPROVED: "تایید شده",
  SPAM: "اسپم",
  REJECTED: "رد شده",
};

export const RESOURCE_KIND_LABEL: Record<string, string> = {
  EXERCISE: "تمرین",
  PROJECT: "پروژه اولیه",
  HANDOUT: "جزوه",
};

export const PAGE_STATUS_LABEL: Record<string, string> = {
  DRAFT: "پیش‌نویس",
  PUBLISHED: "منتشر شده",
};

export const THEME_MODE_LABEL: Record<string, string> = {
  LIGHT: "روشن",
  DARK: "تیره",
  AUTO: "خودکار (سیستم)",
};

export function normalizePhone(raw: string): string {
  // تبدیل ارقام فارسی/عربی به لاتین + حذف کاراکترهای اضافه
  const fa = "۰۱۲۳۴۵۶۷۸۹";
  const ar = "٠١٢٣٤٥٦٧٨٩";
  let s = String(raw).trim();
  s = s.replace(/[۰-۹]/g, (d) => String(fa.indexOf(d)));
  s = s.replace(/[٠-٩]/g, (d) => String(ar.indexOf(d)));
  s = s.replace(/[^\d+]/g, "").replace(/^\+98/, "0");
  if (/^9\d{9}$/.test(s)) s = "0" + s;
  return s;
}

export function isValidPhone(p: string): boolean {
  return /^09\d{9}$/.test(p);
}

/** تبدیل حجم بایت به نمایش خوانا */
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(1)} GB`;
}

/** ساخت slug از یک متن فارسی/انگلیسی */
export function slugify(text: string): string {
  return text
    .toString()
    .trim()
    .toLowerCase()
    .replace(/[^\w\u0600-\u06FF\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}
