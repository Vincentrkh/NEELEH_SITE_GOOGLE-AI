import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies, headers } from "next/headers";
import { db } from "./db";
import { PERMISSIONS, hasPermission as checkHasPermission } from "./permissions";

/**
 * احراز هویت سبک بدون وابستگی خارجی:
 * - رمزها با scrypt هش می‌شوند (salt تصادفی).
 * - نشست = رکورد در جدول Session با توکن تصادفی؛ کوکی httpOnly حاوی توکن.
 * - توکن منقضی شونده (۳۰ روز).
 *
 * مزیت نشست‌های دیتابیس-محور نسبت به JWT:
 * - امکان ابطال فوری (logout واقعی، نه فقط پاک کردن کوکی)
 * - ردیابی دستگاه‌ها و IP
 * - در صورت لو رفتن کلید HMAC، آسیب محدود به دوره‌ی اعتبار توکن است.
 */

const COOKIE_NAME = "neeleh_session";
const SESSION_TTL_MS = 60 * 60 * 24 * 30 * 1000; // ۳۰ روز
const TOKEN_BYTES = 32; // ۲۵۶ بیت

function secret(): string {
  return (
    process.env.SESSION_SECRET ||
    // fallback فقط برای محیط توسعه — در .env مقدار واقعی تنظیم می‌شود
    "neeleh-dev-secret-do-not-use-in-production-change-me"
  );
}

// ── رمز عبور ──

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return (
    candidate.length === expected.length && timingSafeEqual(candidate, expected)
  );
}

// ── نشست ──

function sign(payload: string): string {
  return createHmac("sha256", secret()).update(payload).digest("base64url");
}

export function createSessionToken(userId: string): string {
  const payload = Buffer.from(
    JSON.stringify({ uid: userId, iat: Date.now() })
  ).toString("base64url");
  return `${payload}.${sign(payload)}`;
}

function parseSessionToken(token: string): { uid: string; iat: number } | null {
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return null;
  const expected = sign(payload);
  if (
    sig.length !== expected.length ||
    !timingSafeEqual(Buffer.from(sig), Buffer.from(expected))
  ) {
    return null;
  }
  try {
    const data = JSON.parse(Buffer.from(payload, "base64url").toString()) as {
      uid?: string;
      iat?: number;
    };
    if (!data.uid || !data.iat) return null;
    if (Date.now() - data.iat > SESSION_TTL_MS) return null;
    return { uid: data.uid, iat: data.iat };
  } catch {
    return null;
  }
}

// ── کوکی ──

export async function setSessionCookie(userId: string) {
  const token = createSessionToken(userId);
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);

  // ذخیره رکورد نشست در دیتابیس برای ابطال‌پذیری
  const h = await headers();
  const ip = h.get("x-forwarded-for")?.split(",")[0]?.trim() || null;
  const userAgent = h.get("user-agent") || null;

  await db.session.create({
    data: { userId, token, expiresAt, ip, userAgent },
  });

  const jar = await cookies();
  jar.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_TTL_MS / 1000,
    secure: process.env.NODE_ENV === "production",
  });
}

export async function clearSessionCookie() {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (token) {
    // ابطال در دیتابیس
    await db.session.deleteMany({ where: { token } }).catch(() => {});
  }
  jar.delete(COOKIE_NAME);
}

// ── کاربر جاری ──

export type SessionUser = {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  avatarUrl: string | null;
  field: string | null;
  education: string | null;
  bio: string | null;
  roles: string[]; // نام نقش‌ها (مثلاً ["ADMIN"])
  permissions: string[]; // لیست کلیدهای مجوز
};

/** کاربر جاری از کوکی — null اگر لاگین نیست. */
export async function getCurrentUser(): Promise<SessionUser | null> {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (!token) return null;

  const parsed = parseSessionToken(token);
  if (!parsed) {
    // توکن نامعتبر است — پاک کردن کوکی فقط در Route Handler ممکن است،
    // اینجا فقط null برمی‌گردانیم. کوکی در درخواست بعدی Route Handler پاک می‌شود.
    return null;
  }

  // بررسی وجود رکورد نشست در دیتابیس (ابطال‌پذیری)
  const session = await db.session.findUnique({
    where: { token },
    select: { id: true, userId: true, expiresAt: true },
  });
  if (!session || session.expiresAt.getTime() < Date.now()) {
    if (session) {
      // رکورد منقضی‌شده را پاک می‌کنیم
      await db.session.delete({ where: { id: session.id } }).catch(() => {});
    }
    // کوکی نمی‌تواند در Server Component پاک شود؛ Route Handler بعدی این کار را می‌کند.
    return null;
  }

  const user = await db.user.findUnique({
    where: { id: parsed.uid },
    select: {
      id: true,
      name: true,
      phone: true,
      email: true,
      avatarUrl: true,
      field: true,
      education: true,
      bio: true,
      userRoles: {
        select: {
          role: {
            select: {
              name: true,
              rolePermissions: {
                select: { permission: { select: { key: true } } },
              },
            },
          },
        },
      },
    },
  });
  if (!user) return null;

  const roles = user.userRoles.map((ur) => ur.role.name);
  const permissions = Array.from(
    new Set(
      user.userRoles.flatMap((ur) =>
        ur.role.rolePermissions.map((rp) => rp.permission.key)
      )
    )
  );

  return {
    id: user.id,
    name: user.name,
    phone: user.phone,
    email: user.email,
    avatarUrl: user.avatarUrl,
    field: user.field,
    education: user.education,
    bio: user.bio,
    roles,
    permissions,
  };
}

/** گارد مسیرهای ادمین — کاربر یا null. */
export async function requireUser(): Promise<SessionUser | null> {
  return await getCurrentUser();
}

/** گارد با چک دسترسی — کاربر یا null اگر دسترسی نداشت. */
export async function requirePermission(
  permission: string
): Promise<SessionUser | null> {
  const user = await getCurrentUser();
  if (!user) return null;
  if (user.roles.includes("ADMIN")) return user; // ادمین همیشه دسترسی دارد
  return checkHasPermission(user.permissions, permission) ? user : null;
}

/** گارد فقط ادمین. */
export async function requireAdmin(): Promise<SessionUser | null> {
  const user = await getCurrentUser();
  return user && user.roles.includes("ADMIN") ? user : null;
}

export { PERMISSIONS };
