import { PrismaClient } from "@prisma/client";

/**
 * Client singleton برای Prisma. در محیط توسعه از متغیر گلوبال استفاده می‌کنیم
 * تا از ساخته‌شدن چندین کانکشن در HMR جلوگیری شود.
 */
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["error", "warn"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = db;
}
