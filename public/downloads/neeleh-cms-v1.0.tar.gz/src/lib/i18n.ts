/**
 * i18n — bilingual dictionary (EN / FA) for the whole site.
 *
 * The site defaults to English (matches the reference design). Persian is
 * fully right-to-left: the LanguageProvider sets <html lang dir>, swaps the
 * font stack (Estedad for display / Vazirmatn for body) and converts digits.
 *
 * CONTENT THEME: آکادمی نیله — Neeleh Academy of Architecture (Tehran).
 * Architecture education in the AI era: from AutoCAD Phase 2 to Computational
 * Design with Grasshopper and AI-augmented BIM workflows.
 */

export type Lang = "en" | "fa";

const en = {
  brand: {
    /** Two-line hero brand wordmark ("Neeleh" / "Academy") */
    heroLine1: "Neeleh",
    heroLine2: "Academy",
    /** Lowercase watermark used in hero + contact bottom corners */
    watermark1: "neeleh",
    watermark2: "academy",
    /** Sticky-name big wordmark (uppercase, latin) */
    stickyA: "NEELEH",
    stickyB: "ACADEMY",
  },
  menu: {
    button: "Menu",
    close: "Close",
    home: "Home",
    work: "Courses",
    contact: "Contact",
    experiments: "Tools",
  },
  langSwitch: {
    to: "فارسی",
    aria: "Switch language / تغییر زبان",
  },
  hero: {
    basedIn: "Based in Tehran",
    workingWith: "28 yrs in practice",
    roleA: "Architecture",
    roleB: "& Education",
    /** 7 slots matching the big descriptor grid (last row shares the tagline cell) */
    descriptors: ["Architecture", "Computational", "BIM", "Parametric", "& AI-", "driven", "studio"],
    tagline:
      "Studio Neeleh — architecture education that takes you beyond tools: from Phase-2 drafting to AI-augmented BIM and computational design.",
    taglineAccent: "learn architecture beyond tools.",
  },
  preloader: { percent: "%" },
  work: {
    years: ["09", "AI"],
    word: "Courses",
    selectedWork: "Course Catalog · 9 courses in 3 tiers",
    allWorks: "All courses →",
    disciplines: {
      "Phase 2": "Phase 2",
      "3D Modeling": "3D Modeling",
      "BIM": "BIM",
      "Advanced Modeling": "Advanced Modeling",
      "Rendering": "Rendering",
      "Project Mgmt": "Project Mgmt",
      "Computational": "Computational",
      "Automation": "Automation",
      "AI in Arch": "AI in Arch",
    } as Record<string, string>,
  },
  awards: {
    index: "[ 02 ]",
    label: "Curriculum",
    /** Heading words rendered side by side */
    heading: ["Three", "tiers,", "three", "paths"],
    sub: "Nine courses arranged in three levels — from market-entry drafting to AI-augmented architecture. Pick your tier; the next one is always mapped.",
    titles: {
      tier1: "Tier 1 · Foundation",
      tier2: "Tier 2 · Intermediate",
      tier3: "Tier 3 · Advanced",
    } as Record<string, string>,
    categories: {
      "Foundation": "Foundation",
      "Intermediate": "Intermediate",
      "Advanced": "Advanced",
    } as Record<string, string>,
    marquee: [
      "Architecture beyond tools",
      "From drafting to AI",
      "Computational is the future",
      "BIM is the workflow",
      "Practice over theory",
      "Designed with care",
    ],
    /** "Syllabus" column header inside the curriculum table */
    syllabusLabel: "Syllabus",
    /** Tier badge short label */
    tierShort: { t1: "T1", t2: "T2", t3: "T3" } as Record<string, string>,
  },
  /**
   * The full course catalog — 9 courses in 3 tiers.
   * Used by WorkSection (compact rows) and AwardsSection (full syllabus).
   * `tier` is 1 | 2 | 3 → maps to t.awards.titles.tier1/2/3 + tier color.
   * `discipline` is the EN key into t.work.disciplines (translated per-locale).
   */
  courses: [
    {
      id: "01",
      tier: 1,
      title: "AutoCAD / GstarCAD — Master Phase-2 Drafting",
      discipline: "Phase 2",
      description:
        "Master municipal and engineering-council regulations, principled layering, and complete drafting of a residential Phase-2 package ready for the market.",
      syllabus: [
        "Precision, units & the layer system",
        "Plans, sections & elevations — Phase 1 and 2",
        "Hatching, smart blocks (Blocks & Attributes) & dimensioning",
        "Capstone: full Phase-2 package of a residential building",
      ],
    },
    {
      id: "02",
      tier: 1,
      title: "SketchUp — Volume, Interior & Massing Modeling",
      discipline: "3D Modeling",
      description:
        "Rapid volume modeling, precise component management, and prepping geometry for rendering and presentation.",
      syllabus: [
        "Push/Pull and Group/Component management",
        "Urban massing, façades & interior detailing",
        "Materials, layers & essential extensions",
        "Capstone: a complete villa or interior, start to finish",
      ],
    },
    {
      id: "03",
      tier: 1,
      title: "Revit Architecture — BIM Modeling",
      discipline: "BIM",
      description:
        "Enter the world of intelligent BIM modeling; extract standard drawings and material schedules ready for engineering practice.",
      syllabus: [
        "BIM concepts, initial setup, Levels & Grids",
        "Smart walls, doors, windows, floors & stairs",
        "Roofs, drop ceilings & interior architectural detailing",
        "Documentation, tagging & material schedules",
      ],
    },
    {
      id: "04",
      tier: 2,
      title: "Rhino — Advanced NURBS & Complex Surfaces",
      discipline: "Advanced Modeling",
      description:
        "Master free-form geometry, complex surfaces and precise architectural volumes without error.",
      syllabus: [
        "Curves, Surfaces & Polysurfaces in depth",
        "Advanced form-finding, shells & complex organic volumes",
        "Flawless data exchange with AutoCAD, Revit & presentation tools",
        "Capstone: modeling a signature architectural shell",
      ],
    },
    {
      id: "05",
      tier: 2,
      title: "Enscape / Lumion / V-Ray — Real-time & Cinematic",
      discipline: "Rendering",
      description:
        "Pro sun, sky and artificial lighting, physical materials, and real virtual tours for client presentations.",
      syllabus: [
        "Sun, shadows, sky & artificial lighting",
        "Physical materials — Roughness, Bump & Displacement",
        "Framing, architectural photography & depth of field",
        "Animation & virtual tours",
      ],
    },
    {
      id: "06",
      tier: 2,
      title: "Excel — Smart Takeoff & Architectural Project Management",
      discipline: "Project Mgmt",
      description:
        "Advanced formulas for material takeoff, construction cost estimation, and office financial proposals.",
      syllabus: [
        "Foundational formulas & key data-management functions",
        "Smart material takeoff linked to drawing data",
        "Design-fee calculation & standard architecture contracts",
      ],
    },
    {
      id: "07",
      tier: 3,
      title: "Grasshopper — Parametric & Algorithmic Design",
      discipline: "Computational",
      description:
        "Learn data logic and build intelligent geometric systems for variable façades and shells.",
      syllabus: [
        "Data Trees & lists in Grasshopper",
        "Computational geometry & complex-form control via visual code",
        "Capstone: Facade Generator — a mesh or kinetic-panel system",
      ],
    },
    {
      id: "08",
      tier: 3,
      title: "Office Automation & Documentation Optimization",
      discipline: "Automation",
      description:
        "Identify repetitive bottlenecks in architecture offices and build helper tools to speed up documentation and reduce error.",
      syllabus: [
        "Analyzing repetitive Phase-2 documentation tasks",
        "Scripts for naming & alignment-line automation",
        "Office workflow integration",
      ],
    },
    {
      id: "09",
      tier: 3,
      title: "Architecture in the AI Era — AI + Rhino + BIM",
      discipline: "AI in Arch",
      description:
        "Leverage AI for Phase-0 ideation and rapid conversion of concepts into precise, buildable models.",
      syllabus: [
        "Form & strategy ideation with AI tools",
        "Converting AI outputs into Rhino/Grasshopper geometry",
        "Structuring AI agents for preliminary design analysis",
      ],
    },
  ],
  sticky: {
    copyright: "'26 © All Right Reserved",
    version: "v4.0 · Tehran",
    madeWith: "made w/",
    madeWithAccent: "care",
  },
  philosophy: {
    index: "[ 03 ]",
    label: "Philosophy",
    /** 4 lines before the ( HH : image : MM ) block, 4 lines after */
    linesA: ["Everything", "you will design", "had first", "existed as"],
    linesB: ["nothing", "more", "than a", "concept."],
  },
  contact: {
    availability: "Now enrolling — winter cohort",
    cta: "Let's design the next sentence.",
    blurb:
      "Open for admissions across all three tiers. Tell us your background and goal; we'll map your path from Phase-2 drafting to AI-augmented architecture.",
    writeTo: "Write directly to",
    openMail: "Open mail",
    madeWith: "made w/",
    madeWithAccent: "care",
  },
  cursor: { placeholder: "Ask about a course…" },
  settings: {
    trail: "TRAIL",
    bg: "BG",
    solid: "SOLID",
    image: "IMAGE",
    grad: "GRAD",
  },
  a11y: {
    openMenu: "Open menu",
    closeMenu: "Close menu",
    stickyName: "Sticky name",
  },
};

const fa: typeof en = {
  brand: {
    heroLine1: "نیله",
    heroLine2: "آکادمی",
    watermark1: "نیله",
    watermark2: "آکادمی",
    stickyA: "نیله",
    stickyB: "آکادمی",
  },
  menu: {
    button: "منو",
    close: "بستن",
    home: "خانه",
    work: "دوره‌ها",
    contact: "تماس",
    experiments: "ابزارها",
  },
  langSwitch: {
    to: "EN",
    aria: "تغییر زبان / Switch language",
  },
  hero: {
    basedIn: "مستقر در تهران",
    workingWith: "۲۸ سال تجربه حرفه‌ای",
    roleA: "آکادمی",
    roleB: "و آموزش",
    descriptors: ["معماری", "محاسباتی", "BIM", "پارامتریک", "هوش", "مصنوعی", "عصر AI"],
    tagline:
      "استودیوی تخصصی نیله با تکیه بر تجربه‌ی حرفه‌ای و تسلط بر ابزارهای نوین طراحی محاسباتی، مدلسازی اطلاعات ساختمان (BIM) و هوش مصنوعی، مسیر نوین یادگیری و ارتقای مهندسی معماری را ترسیم می‌کند.",
    taglineAccent: "معماری را فراتر از ابزارها یاد بگیرید.",
  },
  preloader: { percent: "٪" },
  work: {
    years: ["۰۹", "AI"],
    word: "دوره‌ها",
    selectedWork: "کاتالوگ دوره‌ها · ۹ دوره در ۳ سطح",
    allWorks: "همه دوره‌ها ←",
    disciplines: {
      "Phase 2": "فاز ۲",
      "3D Modeling": "مدلسازی ۳بعدی",
      "BIM": "BIM",
      "Advanced Modeling": "مدلسازی پیشرفته",
      "Rendering": "رندرینگ",
      "Project Mgmt": "مدیریت پروژه",
      "Computational": "محاسباتی",
      "Automation": "اتوماسیون",
      "AI in Arch": "هوش مصنوعی",
    },
  },
  awards: {
    index: "[ ۰۲ ]",
    label: "سرفصل‌ها",
    heading: ["سه", "لایه،", "سه", "مسیر"],
    sub: "نُه دوره در سه سطح — از نقشه‌کشی فاز ۲ برای ورود به بازار کار تا معماری در عصر هوش مصنوعی. سطح خود را انتخاب کنید؛ مسیر بعدی همیشه روشن است.",
    titles: {
      tier1: "لایه ۱ · پایه",
      tier2: "لایه ۲ · متوسط",
      tier3: "لایه ۳ · پیشرفته",
    },
    categories: {
      "Foundation": "پایه",
      "Intermediate": "متوسط",
      "Advanced": "پیشرفته",
    },
    marquee: [
      "معماری فراتر از ابزارها",
      "از نقشه‌کشی تا هوش مصنوعی",
      "طراحی محاسباتی، آینده است",
      "BIM، خودِ گردش کار است",
      "تمرین بر تئوری اولویت دارد",
      "ساخته‌شده با دقت",
    ],
    syllabusLabel: "سرفصل‌ها",
    tierShort: { t1: "ل۱", t2: "ل۲", t3: "ل۳" },
  },
  courses: [
    {
      id: "01",
      tier: 1,
      title: "مسترفصل نقشه‌کشی اجرایی و فاز دو با AutoCAD / GstarCAD",
      discipline: "Phase 2",
      description:
        "تسلط بر ضوابط شهرداری و نظام مهندسی، لایه‌بندی اصولی و ترسیم پکیج کامل فاز دو ساختمان مسکونی رایج در بازار کار.",
      syllabus: [
        "مبانی و دقت، تنظیمات واحدها و سیستم لایه‌بندی (Layers)",
        "ترسیم تخصصی پلان، مقاطع و نماهای فاز ۱ و ۲",
        "هاشورزنی، بلاک‌های هوشمند (Blocks & Attributes) و اندازه‌گذاری",
        "پروژه نهایی: ترسیم کامل مدارک فاز دو یک ساختمان مسکونی",
      ],
    },
    {
      id: "02",
      tier: 1,
      title: "مدلسازی سریع حجم، دکوراسیون و حجم‌پردازی با SketchUp",
      discipline: "3D Modeling",
      description:
        "یادگیری سریع ابزارهای مدلسازی حجمی، مدیریت دقیق کامپوننت‌ها و آماده‌سازی احجام برای رندرینگ و ارائه.",
      syllabus: [
        "ابزارهای Push/Pull و مدیریت اجزا (Group & Component)",
        "مدلسازی بدنه‌ی شهری، نمای ساختمان و جزئیات دکوراسیون داخلی",
        "مدیریت متریال، لایه‌ها و استفاده از افزونه‌های کاربردی",
        "پروژه نهایی: مدلسازی کامل یک ویلا یا فضای داخلی از صفر تا صد",
      ],
    },
    {
      id: "03",
      tier: 1,
      title: "مدلسازی اطلاعات ساختمان (BIM) با Revit Architecture",
      discipline: "BIM",
      description:
        "ورود به دنیای مدلسازی هوشمند BIM، استخراج نقشه‌ها و جداول متریال استانداردهای مهندسی.",
      syllabus: [
        "مفاهیم BIM، تنظیمات اولیه، سطوح (Levels) و محورها (Grids)",
        "ترسیم هوشمند دیوارها، درها، پنجره‌ها، کف‌ها و پله‌ها",
        "ساخت بام، سقف‌های کاذب و جزئیات معماری داخلی",
        "مستندسازی، تگ‌گذاری و استخراج جدول متریال (Schedules)",
      ],
    },
    {
      id: "04",
      tier: 2,
      title: "مدلسازی پیشرفته، هندسه‌های پیچیده و سطوح NURBS با Rhino",
      discipline: "Advanced Modeling",
      description:
        "تسلط بر هندسه‌های آزاد، سطوح پیچیده و ساخت احجام دقیق معماری بدون خطا.",
      syllabus: [
        "شناخت دقیق خطوط Curve، سطوح Surface و Polysurface",
        "فرم‌پردازی پیشرفته، ساخت پوسته‌ها و احجام ارگانیک پیچیده",
        "تبادل بی‌نقص داده‌ها با اتوکد، رویت و نرم‌افزارهای ارائه",
        "پروژه نهایی: مدل‌سازی یک پوسته معماری خاص",
      ],
    },
    {
      id: "05",
      tier: 2,
      title: "رندرینگ رئال، نورپردازی و انیمیشن با Enscape / Lumion / V-Ray",
      discipline: "Rendering",
      description:
        "تنظیمات حرفه‌ای نور و اقلیم، متریال‌سازی فیزیکی و ساخت تورهای مجازی رئال برای ارائه به کارفرما.",
      syllabus: [
        "تنظیمات تخصصی خورشید، سایه، آسمان و نورهای مصنوعی",
        "متریال‌سازی فیزیکی و تنظیمات Roughness، Bump و Displacement",
        "قاب‌بندی، اصول عکاسی معماری، Depth of Field و انیمیشن‌سازی",
      ],
    },
    {
      id: "06",
      tier: 2,
      title: "اکسل کاربردی، متره هوشمند و مدیریت پروژه‌های معماری",
      discipline: "Project Mgmt",
      description:
        "فرمول‌نویسی پیشرفته برای متره مصالح، محاسبه هزینه ساخت و تنظیم پروپوزال‌های مالی دفاتر.",
      syllabus: [
        "فرمول‌نویسی پایه و توابع کلیدی مدیریت داده‌های عددی",
        "متره و برآورد هوشمند مصالح ساختمانی و اتصال به داده‌های نقشه",
        "محاسبه حق‌الزحمه طراحی و تنظیم قراردادهای تیپ معماری",
      ],
    },
    {
      id: "07",
      tier: 3,
      title: "طراحی پارامتریک و الگوریتمیک با Grasshopper (از پایه تا Facade Generator)",
      discipline: "Computational",
      description:
        "یادگیری منطق داده‌ها و ساخت سیستم‌های هوشمند هندسی برای تولید نماها و پوسته‌های متغیر.",
      syllabus: [
        "شناخت ساختار داده‌ها (Data Trees) و لیست‌ها در گرس‌هاپر",
        "هندسه محاسباتی و کنترل فرم‌های پیچیده با کدهای بصری",
        "پروژه محور: ساخت Facade Generator (سیستم هوشمند طراحی نمای مشبک یا پنل متحرک)",
      ],
    },
    {
      id: "08",
      tier: 3,
      title: "اتوماسیون فرآیندهای دفتر و بهینه‌سازی مستندات دفاتر معماری",
      discipline: "Automation",
      description:
        "شناسایی گلوگاه‌های تکراری در دفاتر و ساخت ابزارهای کمکی برای افزایش سرعت و کاهش خطای مستندات.",
      syllabus: [
        "تحلیل کارهای تکراری در مستندسازی و نقشه‌کشی فاز دو",
        "ساخت اسکریپت‌ها و ابزارهای کوچک اتوماسیون نام‌گذاری و خطوط تراز",
        "یکپارچه‌سازی گردش کار دفتری",
      ],
    },
    {
      id: "09",
      tier: 3,
      title: "معماری در عصر هوش مصنوعی (تلفیق AI + Rhino + BIM)",
      discipline: "AI in Arch",
      description:
        "بهره‌گیری از هوش مصنوعی در ایده‌پردازی فاز صفر و تبدیل سریع کانسپت‌ها به مدل‌های دقیق قابل ساخت.",
      syllabus: [
        "ایده‌پردازی فرمی و استراتژیک با ابزارهای هوش مصنوعی",
        "تبدیل داده‌های خروجی AI به هندسه قابل پردازش در راینو و گرس‌هاپر",
        "ساختاردهی دستیاران هوشمند (AI Agents) برای تحلیل اولیه طرح‌ها",
      ],
    },
  ],
  sticky: {
    copyright: "۲۶ © تمامی حقوق محفوظ است",
    version: "v4.0 · تهران",
    madeWith: "ساخته‌شده با",
    madeWithAccent: "دقت",
  },
  philosophy: {
    index: "[ ۰۳ ]",
    label: "فلسفه",
    linesA: ["هرچه", "خواهی طراحی کرد", "روزی", "بوده است"],
    linesB: ["چیزی جز", "یک", "کانسپت", "بیشتر نبوده."],
  },
  contact: {
    availability: "ثبت‌نام باز است — دوره زمستانی",
    cta: "بیا جمله‌ی بعدی را بسازیم.",
    blurb:
      "برای ثبت‌نام در هر سه لایه آماده‌ایم. سوابق و هدفت را بگو؛ مسیرت را از نقشه‌کشی فاز ۲ تا معماری در عصر هوش مصنوعی با هم می‌چینیم.",
    writeTo: "مستقیم بنویسید به",
    openMail: "باز کردن ایمیل",
    madeWith: "ساخته‌شده با",
    madeWithAccent: "دقت",
  },
  cursor: { placeholder: "درباره دوره بپرس…" },
  settings: {
    trail: "رد اثر",
    bg: "پس‌زمینه",
    solid: "رنگ",
    image: "تصویر",
    grad: "گرادیان",
  },
  a11y: {
    openMenu: "باز کردن منو",
    closeMenu: "بستن منو",
    stickyName: "نام چسبان",
  },
};

export const dict: Record<Lang, typeof en> = { en, fa };
export type Dict = typeof en;

/** Convert Latin digits to Persian digits (used in the fa locale). */
const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
export function toFaDigits(value: string | number): string {
  return String(value).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]);
}

/**
 * Label for a "'26"-style year string in the current locale.
 * English keeps the apostrophe style; Persian uses Persian digits.
 */
export function yearLabel(year: string, lang: Lang): string {
  if (lang !== "fa") return year;
  return toFaDigits(year.replace(/['’]/g, ""));
}

/** True when the string contains RTL (Arabic/Persian) script. */
export function hasRtlScript(text: string): boolean {
  return /[\u0590-\u08FF]/.test(text);
}
