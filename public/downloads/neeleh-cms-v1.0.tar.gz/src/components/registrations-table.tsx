"use client";

import { useState, useEffect, useMemo } from "react";
import { useToast } from "@/hooks/use-toast";
import {
  faNumber,
  faDate,
  faPrice,
  faDateTime,
  REG_LABEL,
  PAYMENT_LABEL,
  TIER_LABEL,
} from "@/lib/format";
import {
  Search,
  Download,
  CheckCircle2,
  XCircle,
  Trash2,
  Loader2,
  Filter,
  Phone,
  Mail,
  FileText,
} from "lucide-react";
import Link from "next/link";

type Registration = {
  id: string;
  status: "PENDING" | "CONFIRMED" | "CANCELLED";
  paymentStatus: "PAID" | "UNPAID";
  note: string | null;
  createdAt: string;
  student: {
    id: string;
    name: string;
    phone: string;
    email: string | null;
    field: string | null;
    education: string | null;
  };
  course: {
    id: string;
    title: string;
    slug: string;
    price: number;
    tier: string;
  };
};

const STATUS_BADGE: Record<string, string> = {
  PENDING: "bg-amber-100 text-amber-800",
  CONFIRMED: "bg-emerald-100 text-emerald-800",
  CANCELLED: "bg-zinc-200 text-zinc-600",
};

const TIER_BADGE: Record<string, string> = {
  BEGINNER: "border-emerald-500/40 text-emerald-700 bg-emerald-50",
  INTERMEDIATE: "border-amber-500/40 text-amber-700 bg-amber-50",
  PRO: "border-rose-500/40 text-rose-700 bg-rose-50",
};

export function RegistrationsTable({
  initialRegistrations,
  canUpdate,
  canDelete,
  canExport,
}: {
  initialRegistrations: Registration[];
  canUpdate: boolean;
  canDelete: boolean;
  canExport: boolean;
}) {
  const { toast } = useToast();
  const [registrations, setRegistrations] = useState<Registration[]>(initialRegistrations);
  const [busy, setBusy] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [paymentFilter, setPaymentFilter] = useState<string>("");
  const [expanded, setExpanded] = useState<string | null>(null);

  // فیلتر سمت کلاینت
  const filtered = useMemo(() => {
    return registrations.filter((r) => {
      if (statusFilter && r.status !== statusFilter) return false;
      if (paymentFilter && r.paymentStatus !== paymentFilter) return false;
      if (search) {
        const q = search.toLowerCase();
        return (
          r.student.name.toLowerCase().includes(q) ||
          r.student.phone.includes(q) ||
          r.course.title.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [registrations, search, statusFilter, paymentFilter]);

  async function updateReg(id: string, patch: Partial<Registration>) {
    setBusy(id);
    try {
      const res = await fetch(`/api/dashboard/registrations/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) {
        toast({ title: "خطا", description: data.error, variant: "destructive" });
        return;
      }
      setRegistrations((list) =>
        list.map((r) => (r.id === id ? { ...r, ...patch } : r))
      );
      toast({ title: "به‌روزرسانی شد" });
    } catch {
      toast({ title: "خطا", description: "ارتباط برقرار نشد", variant: "destructive" });
    } finally {
      setBusy(null);
    }
  }

  async function deleteReg(id: string) {
    if (!confirm("این ثبت‌نام حذف شود؟ این عمل قابل بازگشت نیست.")) return;
    setBusy(id);
    try {
      const res = await fetch(`/api/dashboard/registrations/${id}`, { method: "DELETE" });
      if (!res.ok) {
        const data = (await res.json()) as { error?: string };
        toast({ title: "خطا", description: data.error, variant: "destructive" });
        return;
      }
      setRegistrations((list) => list.filter((r) => r.id !== id));
      toast({ title: "ثبت‌نام حذف شد" });
    } finally {
      setBusy(null);
    }
  }

  function exportCSV() {
    window.location.href = "/api/dashboard/registrations/export";
  }

  const stats = useMemo(() => {
    return {
      total: registrations.length,
      pending: registrations.filter((r) => r.status === "PENDING").length,
      confirmed: registrations.filter((r) => r.status === "CONFIRMED").length,
      paid: registrations.filter((r) => r.paymentStatus === "PAID").length,
      revenue: registrations
        .filter((r) => r.paymentStatus === "PAID")
        .reduce((sum, r) => sum + r.course.price, 0),
    };
  }, [registrations]);

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <StatBox label="کل" value={faNumber(stats.total)} />
        <StatBox label="در انتظار" value={faNumber(stats.pending)} color="amber" />
        <StatBox label="تایید شده" value={faNumber(stats.confirmed)} color="emerald" />
        <StatBox label="پرداخت شده" value={faNumber(stats.paid)} color="emerald" />
        <StatBox label="درآمد (تومان)" value={faNumber(stats.revenue.toLocaleString("en-US"))} color="foreground" />
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="size-4 absolute top-1/2 -translate-y-1/2 start-3 text-muted-foreground pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="جستجو در نام، موبایل یا دوره..."
            className="w-full bg-card border border-border rounded-md py-2.5 ps-10 pe-3 text-sm outline-none focus:border-foreground transition-colors min-h-[44px]"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="bg-card border border-border rounded-md px-3 py-2 text-sm outline-none focus:border-foreground transition-colors min-h-[44px]"
        >
          <option value="">همه وضعیت‌ها</option>
          <option value="PENDING">در انتظار تایید</option>
          <option value="CONFIRMED">تایید شده</option>
          <option value="CANCELLED">لغو شده</option>
        </select>

        <select
          value={paymentFilter}
          onChange={(e) => setPaymentFilter(e.target.value)}
          className="bg-card border border-border rounded-md px-3 py-2 text-sm outline-none focus:border-foreground transition-colors min-h-[44px]"
        >
          <option value="">همه پرداخت‌ها</option>
          <option value="UNPAID">پرداخت نشده</option>
          <option value="PAID">پرداخت شده</option>
        </select>

        {canExport && (
          <button
            type="button"
            onClick={exportCSV}
            className="flex min-h-[44px] items-center gap-2 border border-border rounded-md px-4 text-sm hover:bg-secondary transition-colors"
          >
            <Download className="size-4" />
            <span className="hidden sm:inline">خروجی اکسل</span>
          </button>
        )}
      </div>

      {/* Results count */}
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>
          {faNumber(filtered.length)} از {faNumber(registrations.length)} ثبت‌نام
        </span>
        {(search || statusFilter || paymentFilter) && (
          <button
            type="button"
            onClick={() => {
              setSearch("");
              setStatusFilter("");
              setPaymentFilter("");
            }}
            className="flex min-h-[36px] items-center gap-1 hover:text-foreground transition-colors"
          >
            <Filter className="size-3" />
            پاک کردن فیلترها
          </button>
        )}
      </div>

      {/* Table */}
      {filtered.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border p-12 text-center">
          <FileText className="size-8 mx-auto text-muted-foreground mb-3" />
          <p className="text-sm text-muted-foreground">
            {registrations.length === 0
              ? "هنوز ثبت‌نامی ثبت نشده است."
              : "موردی با این فیلترها یافت نشد."}
          </p>
        </div>
      ) : (
        <div className="overflow-hidden rounded-lg border border-border bg-card">
          {/* Header */}
          <div className="hidden md:grid grid-cols-12 gap-3 border-b border-border bg-secondary/40 px-4 py-3 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
            <div className="col-span-3">هنرجو</div>
            <div className="col-span-3">دوره</div>
            <div className="col-span-2">تاریخ</div>
            <div className="col-span-1 text-center">وضعیت</div>
            <div className="col-span-1 text-center">پرداخت</div>
            <div className="col-span-2 text-center">عملیات</div>
          </div>

          <ul className="divide-y divide-border">
            {filtered.map((r) => {
              const isExpanded = expanded === r.id;
              return (
                <li key={r.id} className="px-4 py-4 hover:bg-secondary/20 transition-colors">
                  {/* Main row */}
                  <div className="grid grid-cols-12 gap-3 items-center">
                    {/* Student */}
                    <div className="col-span-12 md:col-span-3 min-w-0">
                      <button
                        type="button"
                        onClick={() => setExpanded(isExpanded ? null : r.id)}
                        className="flex items-center gap-3 min-h-[44px] w-full text-start"
                      >
                        <div className="grid size-8 place-items-center rounded-full bg-secondary text-xs font-medium shrink-0">
                          {r.student.name.charAt(0)}
                        </div>
                        <div className="min-w-0">
                          <div className="text-sm font-medium truncate">{r.student.name}</div>
                          <div dir="ltr" className="text-xs text-muted-foreground text-start truncate">
                            {r.student.phone}
                          </div>
                        </div>
                      </button>
                    </div>

                    {/* Course */}
                    <div className="col-span-6 md:col-span-3 min-w-0">
                      <Link
                        href={`/courses/${r.course.slug}`}
                        className="block min-h-[44px] py-1.5"
                      >
                        <div className="text-sm truncate hover:text-foreground transition-colors">
                          {r.course.title}
                        </div>
                        <span className={`inline-flex items-center mt-1 border px-1.5 py-0.5 text-[9px] uppercase tracking-[0.1em] ${TIER_BADGE[r.course.tier]}`}>
                          {TIER_LABEL[r.course.tier]}
                        </span>
                      </Link>
                    </div>

                    {/* Date */}
                    <div className="col-span-6 md:col-span-2 text-xs text-muted-foreground">
                      <div>{faDate(r.createdAt)}</div>
                      <div className="text-[10px] opacity-70">{faDateTime(r.createdAt).split("،")[1]?.trim()}</div>
                    </div>

                    {/* Status */}
                    <div className="col-span-3 md:col-span-1 flex justify-center">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] ${STATUS_BADGE[r.status]}`}>
                        {REG_LABEL[r.status]}
                      </span>
                    </div>

                    {/* Payment */}
                    <div className="col-span-3 md:col-span-1 flex justify-center">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] ${
                        r.paymentStatus === "PAID"
                          ? "bg-emerald-100 text-emerald-800"
                          : "bg-amber-100 text-amber-800"
                      }`}>
                        {PAYMENT_LABEL[r.paymentStatus]}
                      </span>
                    </div>

                    {/* Actions */}
                    <div className="col-span-12 md:col-span-2 flex items-center justify-end gap-1">
                      {busy === r.id && <Loader2 className="size-4 animate-spin text-muted-foreground" />}
                      {canUpdate && r.status !== "CONFIRMED" && (
                        <button
                          type="button"
                          onClick={() => updateReg(r.id, { status: "CONFIRMED" })}
                          className="flex min-h-[44px] min-w-[44px] items-center justify-center text-emerald-600 hover:bg-emerald-50 rounded-md transition-colors"
                          aria-label="تایید ثبت‌نام"
                          title="تایید ثبت‌نام"
                        >
                          <CheckCircle2 className="size-4" />
                        </button>
                      )}
                      {canUpdate && r.status !== "CANCELLED" && (
                        <button
                          type="button"
                          onClick={() => updateReg(r.id, { status: "CANCELLED" })}
                          className="flex min-h-[44px] min-w-[44px] items-center justify-center text-amber-600 hover:bg-amber-50 rounded-md transition-colors"
                          aria-label="لغو ثبت‌نام"
                          title="لغو ثبت‌نام"
                        >
                          <XCircle className="size-4" />
                        </button>
                      )}
                      {canUpdate && (
                        <button
                          type="button"
                          onClick={() =>
                            updateReg(r.id, {
                              paymentStatus: r.paymentStatus === "PAID" ? "UNPAID" : "PAID",
                            })
                          }
                          className={`flex min-h-[44px] min-w-[44px] items-center justify-center rounded-md transition-colors ${
                            r.paymentStatus === "PAID"
                              ? "text-emerald-700 bg-emerald-50"
                              : "text-muted-foreground hover:bg-secondary"
                          }`}
                          aria-label="تغییر وضعیت پرداخت"
                          title="تغییر وضعیت پرداخت"
                        >
                          <FileText className="size-4" />
                        </button>
                      )}
                      {canDelete && (
                        <button
                          type="button"
                          onClick={() => deleteReg(r.id)}
                          className="flex min-h-[44px] min-w-[44px] items-center justify-center text-destructive hover:bg-destructive/5 rounded-md transition-colors"
                          aria-label="حذف"
                          title="حذف ثبت‌نام"
                        >
                          <Trash2 className="size-4" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Expanded details */}
                  {isExpanded && (
                    <div className="mt-4 pt-4 border-t border-border grid sm:grid-cols-2 gap-4 text-sm">
                      {/* Student details */}
                      <div className="space-y-2">
                        <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground mb-2">
                          اطلاعات هنرجو
                        </div>
                        {r.student.email && (
                          <div className="flex items-center gap-2">
                            <Mail className="size-3 text-muted-foreground" />
                            <span dir="ltr" className="text-start">{r.student.email}</span>
                          </div>
                        )}
                        <div className="flex items-center gap-2">
                          <Phone className="size-3 text-muted-foreground" />
                          <span dir="ltr" className="text-start">{r.student.phone}</span>
                        </div>
                        {r.student.field && (
                          <div className="text-muted-foreground">
                            رشته: {r.student.field}
                          </div>
                        )}
                        {r.student.education && (
                          <div className="text-muted-foreground">
                            سوابق: {r.student.education}
                          </div>
                        )}
                      </div>

                      {/* Course details + note */}
                      <div className="space-y-2">
                        <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground mb-2">
                          جزئیات ثبت‌نام
                        </div>
                        <div>
                          دوره:{" "}
                          <Link href={`/courses/${r.course.slug}`} className="text-clay hover:underline">
                            {r.course.title}
                          </Link>
                        </div>
                        <div>شهریه: {faPrice(r.course.price)}</div>
                        {r.note && (
                          <div className="mt-3 p-3 rounded-md bg-secondary/40">
                            <div className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground mb-1">
                              یادداشت هنرجو
                            </div>
                            <p className="text-sm leading-relaxed">{r.note}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
}

function StatBox({
  label,
  value,
  color,
}: {
  label: string;
  value: string;
  color?: "amber" | "emerald" | "foreground";
}) {
  const colorClass =
    color === "amber"
      ? "text-amber-700"
      : color === "emerald"
      ? "text-emerald-700"
      : color === "foreground"
      ? "text-foreground"
      : "text-foreground";
  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className={`text-2xl font-medium tabular-nums ${colorClass}`}>{value}</div>
      <div className="mt-0.5 text-xs text-muted-foreground">{label}</div>
    </div>
  );
}
