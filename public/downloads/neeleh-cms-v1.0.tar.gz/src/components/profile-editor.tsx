"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Save, User, Phone, Mail, GraduationCap, BookOpen, FileText } from "lucide-react";

type Profile = {
  name: string;
  phone: string;
  email: string | null;
  field: string | null;
  education: string | null;
  bio: string | null;
};

export function ProfileEditor({ initial }: { initial: Profile }) {
  const router = useRouter();
  const { toast } = useToast();
  const [data, setData] = useState<Profile>(initial);
  const [busy, setBusy] = useState(false);

  function update<K extends keyof Profile>(key: K, value: Profile[K]) {
    setData((d) => ({ ...d, [key]: value }));
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const res = await fetch("/api/panel/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = (await res.json()) as { error?: string };
      if (!res.ok) {
        toast({ title: "خطا", description: result.error, variant: "destructive" });
        return;
      }
      toast({ title: "پروفایل به‌روزرسانی شد" });
      router.refresh();
    } catch {
      toast({ title: "خطا", description: "ارتباط برقرار نشد", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="rounded-lg border border-border bg-card p-5 sm:p-6 space-y-5">
      <div>
        <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
          پروفایل من
        </div>
        <div className="flex items-center gap-3">
          <div className="grid size-12 place-items-center rounded-full bg-foreground text-background text-lg font-bold uppercase">
            {data.name.charAt(0)}
          </div>
          <div className="min-w-0">
            <div className="font-medium truncate">{data.name}</div>
            <div dir="ltr" className="text-xs text-muted-foreground text-start truncate">
              {data.phone}
            </div>
          </div>
        </div>
      </div>

      <FieldRow icon={User} label="نام و نام خانوادگی">
        <input
          type="text"
          value={data.name}
          onChange={(e) => update("name", e.target.value)}
          required
          minLength={3}
          className="w-full bg-transparent border-b border-border py-2 text-sm outline-none focus:border-foreground transition-colors min-h-[44px]"
        />
      </FieldRow>

      <FieldRow icon={Phone} label="شماره موبایل">
        <input
          type="tel"
          value={data.phone}
          disabled
          dir="ltr"
          className="w-full bg-transparent border-b border-border py-2 text-sm outline-none text-start min-h-[44px] disabled:opacity-60"
        />
        <p className="text-[10px] text-muted-foreground mt-1">شماره موبایل قابل تغییر نیست</p>
      </FieldRow>

      <FieldRow icon={Mail} label="ایمیل">
        <input
          type="email"
          value={data.email ?? ""}
          onChange={(e) => update("email", e.target.value)}
          dir="ltr"
          placeholder="you@example.com"
          className="w-full bg-transparent border-b border-border py-2 text-sm outline-none focus:border-foreground transition-colors text-start min-h-[44px]"
        />
      </FieldRow>

      <FieldRow icon={GraduationCap} label="رشته تحصیلی">
        <input
          type="text"
          value={data.field ?? ""}
          onChange={(e) => update("field", e.target.value)}
          placeholder="مثلاً معماری"
          className="w-full bg-transparent border-b border-border py-2 text-sm outline-none focus:border-foreground transition-colors min-h-[44px]"
        />
      </FieldRow>

      <FieldRow icon={BookOpen} label="سوابق تحصیلی">
        <input
          type="text"
          value={data.education ?? ""}
          onChange={(e) => update("education", e.target.value)}
          placeholder="مثلاً کارشناسی معماری"
          className="w-full bg-transparent border-b border-border py-2 text-sm outline-none focus:border-foreground transition-colors min-h-[44px]"
        />
      </FieldRow>

      <FieldRow icon={FileText} label="معرفی کوتاه">
        <textarea
          value={data.bio ?? ""}
          onChange={(e) => update("bio", e.target.value)}
          rows={3}
          placeholder="چند خط درباره خودتان..."
          className="w-full bg-transparent border border-border rounded-md p-3 text-sm outline-none focus:border-foreground transition-colors resize-y min-h-[44px]"
        />
      </FieldRow>

      <button
        type="submit"
        disabled={busy}
        className="w-full flex min-h-[48px] items-center justify-center gap-2 bg-foreground text-background rounded-md px-6 text-sm font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
      >
        {busy ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
        ذخیره پروفایل
      </button>
    </form>
  );
}

function FieldRow({
  icon: Icon,
  label,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="flex items-center gap-2 text-xs uppercase tracking-[0.14em] text-muted-foreground mb-2">
        <Icon className="size-3" />
        {label}
      </label>
      {children}
    </div>
  );
}
