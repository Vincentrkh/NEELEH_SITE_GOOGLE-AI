"use client";

import { AnimatePresence, motion, useScroll, useSpring } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { useLang } from "@/components/language-provider";
import { hasRtlScript, toFaDigits } from "@/lib/i18n";

/**
 * SiteHeader — Menu button + the signature menu overlay of bleibtgleich.dev.
 *
 * === EXACT BEHAVIOUR (reverse-engineered from the live site) ===
 *
 * LAYOUT (open state, viewport ≥ 1024px):
 *   The menu is NOT a single panel. It is FOUR separate blocks arranged
 *   horizontally on the right half of the viewport, each 240px wide:
 *
 *     ┌─────────┬─────────┬─────────┐
 *     │  Home    │  Work   │ Contact │   ← heights staircase DOWN
 *     │  360h    │  280h   │  216h   │
 *     │  ① dark  │  ②      │  ③      │
 *     └─────────┴─────────┴─────────┘
 *                  ┌─────────┐
 *                  │ Experim. │   ← fixed bottom-left of right-half
 *                  │  39h     │   ← no number indicator
 *                  └─────────┘
 *
 *   Backgrounds:  Home #cbcccd · Work #d8d9da · Contact #e6e6e6 · Exp #d8d9da
 *   Each block has a small (23×23) number indicator top-left at (16,16).
 *   Only the CURRENT page's indicator is filled black; others are transparent.
 *   Total width: 3 × 240 = 720px = 50vw on a 1440px viewport.
 *
 * OPEN ANIMATION (~1.1s total, top-to-bottom clip-path wipe per block):
 *   Each block independently animates clip-path: inset(0% 0% 100%) → inset(0% 0% 0%).
 *   This reveals each block from its TOP edge downward.
 *   Stagger order is REVERSE to block size:
 *     Experiments (smallest) → fully visible first   (~725ms)
 *     Contact                 → fully visible second (~865ms)
 *     Work                    → fully visible third  (~1003ms)
 *     Home (largest)          → fully visible last   (~1123ms)
 *   Opacity stays at 1 throughout — no fade.
 *
 * CLOSE ANIMATION (~0.6s, reverse order, top-to-bottom wipe closing):
 *   clip-path: inset(0% 0% 0%) → inset(0% 0% 100%) (bottom edge retreats upward).
 *   Order: Home → Work → Contact → Experiments.
 *
 * HOVER on a block:
 *   The label text uses SplitText (per-character). On hover:
 *     - Visible label chars: translateY(0) → translateY(-32px)  [slide up out]
 *     - Shadow copy chars:   translateY(32px) → translateY(0)  [slide up in]
 *   The indicator's number does NOT change.
 *
 * MENU BUTTON (top-right):
 *   Small pill/text "Menu" — toggles to "Close" when open.
 */

type MenuItem = {
  num?: string;        // "1" / "2" / "3" — Experiments has none
  labelKey: "home" | "work" | "contact" | "experiments";
  href: string;
  bgColor: string;
  indicatorFill: boolean; // true = black filled (current page), false = transparent
  isArchive?: boolean;    // Experiments block is fixed at bottom
  // Block geometry comes from CSS vars (--menu-h-*) defined in globals.css
  // so the staircase scales responsively (desktop keeps exact 360/280/216px).
};

const ITEMS: MenuItem[] = [
  { num: "1", labelKey: "home",       href: "#top",        bgColor: "#cbcccd", indicatorFill: true  },
  { num: "2", labelKey: "work",       href: "#work",       bgColor: "#d8d9da", indicatorFill: false },
  { num: "3", labelKey: "contact",    href: "#contact",    bgColor: "#e6e6e6", indicatorFill: false },
  { num: undefined, labelKey: "experiments", href: "#experiments", bgColor: "#d8d9da", indicatorFill: false, isArchive: true },
];

// Height var per non-archive block, in item order (home, work, contact).
const HEIGHT_VARS = ["var(--menu-h-1)", "var(--menu-h-2)", "var(--menu-h-3)"];

// Per-block animation timing (measured from live site, in seconds).
// OPEN: stagger from smallest to largest block (reverse index order).
//   Experiments (i=3) starts first; Home (i=0) starts last.
//   Reference: Experiments done ~725ms, Contact ~865ms, Work ~1003ms, Home ~1123ms.
const OPEN_BASE_DELAY = 0.0;
const OPEN_STAGGER = 0.09;       // gap between block starts (reverse direction)
const OPEN_DURATION = 0.78;      // each block's clip-path animation length

// CLOSE: stagger from largest to smallest (Home first, Experiments last).
//   Reference: Home hidden ~260ms, Work ~376ms, Contact ~493ms, Experiments ~609ms.
const CLOSE_BASE_DELAY = 0.0;
const CLOSE_STAGGER = 0.10;
const CLOSE_DURATION = 0.32;

const EASE = [0.76, 0, 0.24, 1] as const; // expo.inOut

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const { t } = useLang();

  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, {
    stiffness: 120,
    damping: 30,
    mass: 0.3,
  });

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    // Broadcast menu state so the brush-settings panel can hide itself
    // while the overlay is open (it would otherwise show through the
    // translucent overlay and collide with the fixed Experiments block).
    if (open) {
      document.body.dataset.menuOpen = "true";
    } else {
      delete document.body.dataset.menuOpen;
    }
    return () => {
      document.body.style.overflow = "";
      delete document.body.dataset.menuOpen;
    };
  }, [open]);

  return (
    <>
      {/* Top progress bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 z-[60] h-[2px] origin-left rtl:origin-right bg-foreground"
        style={{ scaleX: progress }}
      />

      {/* Top-right row: language toggle + Menu/Close */}
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
        className="fixed top-3 end-5 sm:end-8 lg:end-12 z-[90] flex items-center"
      >
        <LangToggle />
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? t.a11y.closeMenu : t.a11y.openMenu}
          className="flex min-h-[44px] items-center gap-2 px-2 text-xs uppercase text-foreground hover:opacity-70 transition-opacity"
        >
          <span>{open ? t.menu.close : t.menu.button}</span>
        </button>
      </motion.div>

      <AnimatePresence>
        {open && <MenuOverlay items={ITEMS} onClose={() => setOpen(false)} />}
      </AnimatePresence>
    </>
  );
}

/**
 * Language toggle — sits next to the Menu button, always reachable.
 * Shows the OTHER language's name (فارسی in EN mode, EN in FA mode).
 * 44px minimum touch target (mobile rule).
 */
function LangToggle() {
  const { lang, t, setLang } = useLang();
  return (
    <button
      type="button"
      onClick={() => setLang(lang === "en" ? "fa" : "en")}
      aria-label={t.langSwitch.aria}
      className="flex min-h-[44px] min-w-[44px] items-center justify-center px-1 text-xs uppercase text-foreground hover:opacity-70 transition-opacity"
    >
      {t.langSwitch.to}
    </button>
  );
}

function MenuOverlay({
  items,
  onClose,
}: {
  items: MenuItem[];
  onClose: () => void;
}) {
  return (
    <motion.div
      className="fixed inset-0 z-[85]"
      initial="hidden"
      animate="show"
      exit="exit"
    >
      {/* Click-catcher on left half (transparent — homepage stays visible) */}
      <button
        aria-label="Close menu"
        onClick={onClose}
        className="absolute inset-0 cursor-default"
        tabIndex={-1}
      />

      {/* The 4 blocks live inside an end-half container (right half in LTR,
          mirrored to the left half in RTL). Full-width on <1024px so the three
          staircase columns span the whole viewport; each block is positioned
          with CSS vars from .menu-blocks (globals.css). */}
      <div className="menu-blocks absolute top-0 end-0 h-full w-full lg:w-1/2">
        {items.map((item, i) => (
          <MenuBlock
            key={item.href}
            item={item}
            index={i}
            total={items.length}
            onClose={onClose}
          />
        ))}
      </div>
    </motion.div>
  );
}

function MenuBlock({
  item,
  index,
  total,
  onClose,
}: {
  item: MenuItem;
  index: number;
  total: number;
  onClose: () => void;
}) {
  const [hovered, setHovered] = useState(false);
  const { lang, t } = useLang();

  // Reverse-index for open stagger (smallest block first → largest last).
  // index 0 = Home (largest), index 3 = Experiments (smallest).
  // Open order: Experiments first → Home last.
  const openOrder = total - 1 - index; // 0→3, 1→2, 2→1, 3→0
  const openDelay = OPEN_BASE_DELAY + openOrder * OPEN_STAGGER;

  // Close order: Home first → Experiments last.
  const closeDelay = CLOSE_BASE_DELAY + index * CLOSE_STAGGER;

  return (
    <motion.a
      href={item.href}
      onClick={onClose}
      onHoverStart={() => setHovered(true)}
      onHoverEnd={() => setHovered(false)}
      // Position each block (logical properties so the layout mirrors in RTL):
      //   Non-archive: stacked horizontally from the inline-start edge of the
      //                container. Block 0 at 0, 1 at 1×W, 2 at 2×W (—menu-w).
      //   Archive (Experiments): position:fixed at bottom, column index 1
      //                (--menu-archive-x: 50vw + W on desktop, W on mobile).
      style={{
        position: item.isArchive ? "fixed" : "absolute",
        top: item.isArchive ? "auto" : "var(--menu-top)",
        insetInlineStart: item.isArchive
          ? "var(--menu-archive-x)"
          : `calc(${index} * var(--menu-w))`,
        bottom: item.isArchive ? 0 : "auto",
        width: "var(--menu-w)",
        height: item.isArchive ? "var(--menu-h-arch)" : HEIGHT_VARS[index],
        backgroundColor: item.bgColor,
      }}
      className="group block overflow-hidden"
      variants={{
        hidden: { clipPath: "inset(0% 0% 100%)" },
        show: {
          clipPath: "inset(0% 0% 0%)",
          transition: { duration: OPEN_DURATION, delay: openDelay, ease: EASE },
        },
        exit: {
          clipPath: "inset(0% 0% 100%)",
          transition: { duration: CLOSE_DURATION, delay: closeDelay, ease: EASE },
        },
      }}
    >
      {/* Number indicator (inline-start corner, 23×23, only Home is filled black) */}
      {item.num && (
        <div
          className="absolute z-10 flex items-center justify-center text-[14px] font-medium tabular-nums"
          style={{
            top: 16,
            insetInlineStart: 16,
            width: 23,
            height: 23,
            backgroundColor: item.indicatorFill ? "#000000" : "transparent",
            color: item.indicatorFill ? "#ffffff" : "#000000",
          }}
        >
          {lang === "fa" ? toFaDigits(item.num!) : item.num}
        </div>
      )}

      {/* Label with mask-reveal hover (per-char slide; whole-word for Persian) */}
      <div
        className="absolute"
        style={{
          insetInlineStart: 16,
          bottom: item.isArchive ? 8 : 24,
          insetInlineEnd: 16,
        }}
      >
        <MenuLabel text={t.menu[item.labelKey]} hovered={hovered} />
      </div>
    </motion.a>
  );
}

/**
 * MenuLabel — SplitText-style mask reveal on hover.
 *   Each character is wrapped in an overflow:hidden container.
 *   Visible char: translateY(0) → translateY(-100%) on hover
 *   Shadow char:  translateY(100%) → translateY(0) on hover
 *   (Real site uses -32px/+0 — but 100% is visually equivalent at this scale.)
 *
 * RTL note: Persian/Arabic letters are JOINED — splitting per character
 * destroys the letterforms. For RTL labels the whole word animates as a
 * single unit instead.
 */
function MenuLabel({ text, hovered }: { text: string; hovered: boolean }) {
  // Font size scales via .menu-label (globals.css): mobile-first clamp,
  // desktop restores the reference clamp(1.75rem, 2.6vw, 2.5rem).
  const isRTL = hasRtlScript(text);
  const units = isRTL ? [text] : text.split("");
  return (
    <div
      className="menu-label relative font-medium leading-[1]"
    >
      {/* Visible row */}
      <div className="flex">
        {units.map((c, i) => (
          <span
            key={`v-${i}`}
            className="inline-block overflow-hidden"
            style={{ width: c === " " ? "0.3em" : "auto" }}
          >
            <span
              className="inline-block transition-transform duration-500 ease-[cubic-bezier(0.76,0,0.24,1)]"
              style={{
                transform: hovered ? "translateY(-110%)" : "translateY(0%)",
                transitionDelay: `${i * (isRTL ? 0 : 0.02)}s`,
              }}
            >
              {c === " " ? "\u00A0" : c}
            </span>
          </span>
        ))}
      </div>
      {/* Shadow row — sits on top, slides up from below */}
      <div className="absolute inset-0 flex">
        {units.map((c, i) => (
          <span
            key={`s-${i}`}
            className="inline-block overflow-hidden"
            style={{ width: c === " " ? "0.3em" : "auto" }}
          >
            <span
              className="inline-block transition-transform duration-500 ease-[cubic-bezier(0.76,0,0.24,1)]"
              style={{
                transform: hovered ? "translateY(0%)" : "translateY(110%)",
                transitionDelay: `${i * (isRTL ? 0 : 0.02)}s`,
              }}
            >
              {c === " " ? "\u00A0" : c}
            </span>
          </span>
        ))}
      </div>
    </div>
  );
}
