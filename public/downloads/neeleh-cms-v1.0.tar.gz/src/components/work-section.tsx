"use client";

import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { useState } from "react";
import { SplitText } from "./split-text";
import { useLang } from "@/components/language-provider";
import { toFaDigits } from "@/lib/i18n";

type Project = {
  id: string;
  /** Tier 1 | 2 | 3 — drives the "tier badge" badge in the client column */
  tier: 1 | 2 | 3;
  title: string;
  /** One-line description shown under the title (kept muted + smaller) */
  description: string;
  /** EN key into t.work.disciplines */
  discipline: string;
};

/**
 * ۹ دوره در ۳ سطح — مشتری (client column) حالا به‌جای عبارت تکراری
 * "Tier 1 · Foundation"، badge سطح را نشان می‌دهد تا جدول فشرده‌تر بماند.
 * توضیح کوتاه هر دوره زیر عنوان می‌نشیند — بدون تغییر ساختار grid فعلی.
 */
function useProjects(): Project[] {
  const { t } = useLang();
  return t.courses.map((c) => ({
    id: c.id,
    tier: c.tier as 1 | 2 | 3,
    title: c.title,
    description: c.description,
    discipline: c.discipline,
  }));
}

const TIER_BADGE_CLASSES: Record<1 | 2 | 3, string> = {
  1: "border-emerald-500/40 text-emerald-700 bg-emerald-50",
  2: "border-amber-500/40 text-amber-700 bg-amber-50",
  3: "border-rose-500/40 text-rose-700 bg-rose-50",
};

export function WorkSection() {
  const { lang, t } = useLang();
  const projects = useProjects();
  return (
    <section id="work" className="relative py-24 sm:py-32 border-t border-border">
      <div className="mx-auto max-w-[1800px] px-5 sm:px-8 lg:px-12">
        {/* Big "24 Work 26" header — matches real site */}
        <div className="flex items-baseline justify-center gap-4 sm:gap-8 mb-16 sm:mb-24">
          <div className="mask-reveal">
            <SplitText
              as="h2"
              text={t.work.years[0]}
              mode="chars"
              stagger={0.05}
              duration={0.8}
              className="text-5xl sm:text-7xl md:text-8xl font-medium tracking-[-0.04em] text-muted-foreground"
            />
          </div>
          <div className="mask-reveal">
            <SplitText
              as="h2"
              text={t.work.word}
              mode="chars"
              stagger={0.05}
              duration={0.8}
              delay={0.15}
              className="text-5xl sm:text-7xl md:text-8xl font-medium tracking-[-0.04em]"
            />
          </div>
          <div className="mask-reveal">
            <SplitText
              as="h2"
              text={t.work.years[1]}
              mode="chars"
              stagger={0.05}
              duration={0.8}
              delay={0.3}
              className="text-5xl sm:text-7xl md:text-8xl font-medium tracking-[-0.04em] text-muted-foreground"
            />
          </div>
        </div>

        {/* Index header row */}
        <div className="flex items-baseline justify-between border-b border-border pb-4 mb-2">
          <span className="text-xs uppercase text-muted-foreground">
            {t.work.selectedWork}
          </span>
          <a
            href="#awards"
            className="link-underline flex min-h-[40px] items-center text-xs uppercase text-muted-foreground hover:text-foreground"
          >
            {t.work.allWorks}
          </a>
        </div>

        {/* Project list */}
        <ul>
          {projects.map((p, idx) => (
            <ProjectRow key={p.id} project={p} index={idx} lang={lang} t={t} />
          ))}
        </ul>
      </div>
    </section>
  );
}

function ProjectRow({
  project,
  index,
  lang,
  t,
}: {
  project: Project;
  index: number;
  lang: "en" | "fa";
  t: ReturnType<typeof useLang>["t"];
}) {
  const [hovered, setHovered] = useState(false);

  return (
    <motion.li
      initial={{ opacity: 0, y: 24, filter: "blur(8px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{
        duration: 0.7,
        delay: Math.min(index * 0.05, 0.3),
        ease: [0.22, 1, 0.36, 1],
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="border-b border-border"
    >
      <a href="#awards" className="group grid grid-cols-12 gap-4 items-center py-6 sm:py-9">
        {/* Index */}
        <div className="col-span-2 sm:col-span-1 text-xs font-mono text-muted-foreground tabular-nums">
          {lang === "fa" ? toFaDigits(project.id) : project.id}
        </div>

        {/* Title with mask reveal + slide on hover, plus description below */}
        <div className="col-span-10 sm:col-span-6 overflow-hidden">
          <motion.div
            animate={{ y: hovered ? "-100%" : "0%" }}
            transition={{ duration: 0.5, ease: [0.76, 0, 0.24, 1] }}
            className="text-2xl sm:text-4xl md:text-5xl font-medium tracking-[-0.03em] leading-[1.05]"
          >
            {project.title}
          </motion.div>
          <motion.div
            aria-hidden
            animate={{ y: hovered ? "-100%" : "0%" }}
            transition={{ duration: 0.5, ease: [0.76, 0, 0.24, 1] }}
            className="text-2xl sm:text-4xl md:text-5xl font-medium tracking-[-0.03em] leading-[1.05] text-muted-foreground"
          >
            {project.title}
          </motion.div>
          {/* Description — sits below the slide-stack, muted and smaller */}
          <p className="mt-2 sm:mt-3 text-xs sm:text-sm leading-relaxed text-muted-foreground line-clamp-2 sm:line-clamp-none max-w-xl">
            {project.description}
          </p>
        </div>

        {/* Tier badge — replaces the old "client" column */}
        <div className="hidden md:block md:col-span-2">
          <span
            className={`inline-flex items-center gap-1.5 border px-2 py-1 text-[10px] uppercase tracking-[0.12em] ${TIER_BADGE_CLASSES[project.tier]}`}
          >
            {t.awards.titles[`tier${project.tier}`]}
          </span>
        </div>

        {/* Discipline */}
        <div className="col-span-7 sm:col-span-3 md:col-span-2 flex flex-wrap gap-1.5">
          <span className="text-[10px] uppercase border border-border px-2 py-1 text-muted-foreground">
            {t.work.disciplines[project.discipline] ?? project.discipline}
          </span>
        </div>

        {/* Year + arrow */}
        <div className="col-span-5 sm:col-span-2 md:col-span-1 flex items-center justify-end gap-3 text-sm text-muted-foreground">
          <span className="tabular-nums">{lang === "fa" ? toFaDigits(String(project.tier)) : String(project.tier)}</span>
          <motion.span
            animate={{
              rotate: hovered ? 0 : -45,
              opacity: hovered ? 1 : 0.5,
            }}
            transition={{ duration: 0.3 }}
            className="inline-flex text-foreground"
          >
            <ArrowUpRight className="h-4 w-4" />
          </motion.span>
        </div>
      </a>
    </motion.li>
  );
}
