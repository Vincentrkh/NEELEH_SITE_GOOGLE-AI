"use client";

import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { SplitText } from "./split-text";
import { useLang } from "./language-provider";
import { toFaDigits } from "@/lib/i18n";

export function PhilosophySection() {
  const { lang, t, isRTL } = useLang();
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], [60, -60]);
  const opacity = useTransform(
    scrollYProgress,
    [0, 0.25, 0.75, 1],
    [0.3, 1, 1, 0.3]
  );

  return (
    <section
      id="philosophy"
      ref={ref}
      className="relative py-32 sm:py-48 overflow-hidden"
    >
      <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12 relative z-10">
        {/* Section label */}
        <div className="grid grid-cols-12 gap-6 mb-16 sm:mb-24">
          <div className="col-span-6 md:col-span-3">
            <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
              {t.philosophy.index}
            </div>
            <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              {t.philosophy.label}
            </div>
          </div>
        </div>

        {/* The quote with embedded image-texture inside parens */}
        <motion.div
          style={{ y, opacity }}
          className="max-w-5xl mx-auto text-center"
        >
          {t.philosophy.linesA.map((line, i) => (
            <QuoteLine key={`a-${i}`} text={line} />
          ))}

          {/* The parenthesized "( HH : [image] : MM )" — image texture in middle */}
          <div className="my-6 sm:my-10 flex items-center justify-center gap-3 sm:gap-6">
            <ParenPart text="(" />
            <div className="flex items-center gap-3 sm:gap-5">
              <LiveHour fa={lang === "fa"} />
              <div className="text-4xl sm:text-6xl md:text-7xl font-medium tracking-[-0.04em] text-muted-foreground">
                :
              </div>
              {/* The middle image — a vertical black rectangle with white texture */}
              <div className="relative w-12 sm:w-20 md:w-24 h-20 sm:h-32 md:h-40 bg-black overflow-hidden">
                <svg
                  viewBox="0 0 60 100"
                  className="w-full h-full"
                  preserveAspectRatio="none"
                >
                  {/* Lace-like organic texture in white */}
                  <g stroke="white" fill="none" strokeWidth="0.5" opacity="0.85">
                    {Array.from({ length: 18 }).map((_, i) => {
                      const x = 4 + (i % 6) * 10;
                      const y = 8 + Math.floor(i / 6) * 28;
                      return (
                        <path
                          key={i}
                          d={`M ${x} ${y} q 3 -4 6 0 q 3 4 6 0`}
                        />
                      );
                    })}
                  </g>
                  <g fill="white" opacity="0.6">
                    {Array.from({ length: 12 }).map((_, i) => {
                      const x = 6 + (i % 4) * 14;
                      const y = 14 + Math.floor(i / 4) * 28;
                      return <circle key={i} cx={x} cy={y} r="1.2" />;
                    })}
                  </g>
                </svg>
              </div>
              <div className="text-4xl sm:text-6xl md:text-7xl font-medium tracking-[-0.04em] text-muted-foreground">
                :
              </div>
              <LiveMinute fa={lang === "fa"} />
            </div>
            <ParenPart text=")" />
          </div>

          {t.philosophy.linesB.map((line, i) => (
            <QuoteLine
              key={`b-${i}`}
              text={line}
              muted={i < t.philosophy.linesB.length - 1}
            />
          ))}
        </motion.div>
      </div>

      {/* Faint background numeral */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.04] select-none"
      >
        <span
          className={`${isRTL ? "fa-serif" : "font-serif-display"} text-[40vw] leading-none`}
        >
          {lang === "fa" ? toFaDigits(24) : "24"}
        </span>
      </div>
    </section>
  );
}

function QuoteLine({
  text,
  muted,
}: {
  text: string;
  muted?: boolean;
}) {
  const { isRTL } = useLang();

  return (
    <div className="mask-reveal py-1">
      <SplitText
        as="h2"
        text={text}
        mode="chars"
        stagger={0.035}
        duration={0.7}
        className={`${isRTL ? "fa-serif" : "font-serif-display"} text-3xl sm:text-5xl md:text-6xl leading-[1.05] tracking-tight text-balance ${
          muted ? `text-muted-foreground ${isRTL ? "" : "italic"}` : ""
        }`}
      />
    </div>
  );
}

function ParenPart({ text }: { text: string }) {
  return (
    <div className="mask-reveal inline-block">
      <SplitText
        as="h2"
        text={text}
        mode="chars"
        stagger={0.08}
        duration={0.7}
        className="text-4xl sm:text-6xl md:text-7xl font-medium tracking-[-0.04em] text-muted-foreground"
      />
    </div>
  );
}

function LiveHour({ fa }: { fa?: boolean }) {
  const [h, setH] = useState("--");
  useEffect(() => {
    const fmt = new Intl.DateTimeFormat("en-GB", {
      hour: "2-digit",
      hour12: false,
      timeZone: "Asia/Tehran",
    });
    const tick = () => setH(fmt.format(new Date()));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <span className="text-4xl sm:text-6xl md:text-7xl font-medium tracking-[-0.04em] tabular-nums">
      {fa ? toFaDigits(h) : h}
    </span>
  );
}

function LiveMinute({ fa }: { fa?: boolean }) {
  const [m, setM] = useState("--");
  useEffect(() => {
    const fmt = new Intl.DateTimeFormat("en-GB", {
      minute: "2-digit",
      hour12: false,
      timeZone: "Asia/Tehran",
    });
    const tick = () => setM(fmt.format(new Date()));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <span className="text-4xl sm:text-6xl md:text-7xl font-medium tracking-[-0.04em] tabular-nums">
      {fa ? toFaDigits(m) : m}
    </span>
  );
}
