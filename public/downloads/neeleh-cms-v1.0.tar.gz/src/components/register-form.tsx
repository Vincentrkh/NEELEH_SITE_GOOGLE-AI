"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle2, Loader2 } from "lucide-react";

type Success = { studentName: string; courseTitle: string };

/**
 * فرم ثبت‌نام دوره — ساخت حساب + ثبت درخواست در یک مرحله.
 * اگر کاربر از قبل لاگین باشد، فیلدهای نام/موبایل/رمز از قبل پر می‌شوند.
 */
export function RegisterForm({
  slug,
  initialName,
  initialPhone,
  isLoggedIn,
}: {
  slug: string;
  initialName?: string;
  initialPhone?: string;
  isLoggedIn?: boolean;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [success, setSuccess] = useState<Success | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setBusy(true);
    try {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          slug,
          name: fd.get("name"),
          phone: fd.get("phone"),
          password: fd.get("password"),
          email: fd.get("email"),
          field: fd.get("field"),
          education: fd.get("education"),
          note: fd.get("note"),
        }),
      });
      const data = (await res.json()) as {
        error?: string;
        studentName?: string;
        courseTitle?: string;
      };
      if (!res.ok) {
        toast({ title: "ثبت‌نام انجام نشد", description: data.error, variant: "destructive" });
        return;
      }
      setSuccess({ studentName: data.studentName!, courseTitle: data.courseTitle! });
      router.refresh();
    } catch {
      toast({ title: "خطا", description: "ارتباط برقرار نشد — دوباره تلاش کنید.", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  if (success) {
    return (
      <div className="rounded-lg border border-border bg-card p-8 text-center sm:p-10">
        <div className="mx-auto grid size-14 place-items-center rounded-full bg-emerald-100 text-emerald-700">
          <CheckCircle2 className="size-7" aria-hidden="true" />
        </div>
        <h2 className="mt-5 text-xl font-bold">ثبت‌نام شما ثبت شد ✓</h2>
        <p className="mx-auto mt-3 max-w-md text-sm leading-8 text-muted-foreground">
          <strong className="text-foreground">{success.studentName}</strong> عزیز،
          درخواست ثبت‌نام شما در دوره «{success.courseTitle}» با وضعیت «در
          انتظار تایید» ثبت شد. همکاران ما برای هماهنگی پرداخت و کلاس با شما
          تماس می‌گیرند.
        </p>
        <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
          <Link
            href="/panel"
            className="flex min-h-[48px] items-center justify-center rounded-md bg-foreground text-background px-8 text-sm font-medium transition-opacity hover:opacity-85"
          >
            ورود به پنل هنرجویی
          </Link>
          <Link
            href="/courses"
            className="flex min-h-[48px] items-center justify-center rounded-md border border-border px-8 text-sm font-medium transition-colors hover:bg-secondary"
          >
            مشاهده دوره‌های دیگر
          </Link>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-5 rounded-lg border border-border bg-card p-6 sm:p-8">
      {isLoggedIn && (
        <div className="rounded-md bg-emerald-50 border border-emerald-200 px-4 py-3 text-sm text-emerald-800">
          شما وارد شده‌اید — می‌توانید مستقیم ثبت‌نام کنید.
        </div>
      )}

      <div className="grid gap-5 sm:grid-cols-2">
        <div className="grid gap-2">
          <label htmlFor="reg-name" className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
            نام و نام خانوادگی *
          </label>
          <input
            id="reg-name"
            name="name"
            required
            minLength={3}
            defaultValue={initialName}
            placeholder="مثلاً امیر کریمی"
            autoComplete="name"
            className="bg-transparent border-b border-border py-3 text-sm outline-none focus:border-foreground transition-colors min-h-[44px]"
          />
        </div>
        <div className="grid gap-2">
          <label htmlFor="reg-phone" className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
            شماره موبایل * (نام کاربری)
          </label>
          <input
            id="reg-phone"
            name="phone"
            required
            inputMode="tel"
            dir="ltr"
            defaultValue={initialPhone}
            disabled={isLoggedIn}
            className="bg-transparent border-b border-border py-3 text-sm outline-none focus:border-foreground transition-colors text-start min-h-[44px] disabled:opacity-60"
            placeholder="0912 345 6789"
            autoComplete="tel"
          />
        </div>
      </div>

      {!isLoggedIn && (
        <div className="grid gap-5 sm:grid-cols-2">
          <div className="grid gap-2">
            <label htmlFor="reg-pass" className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
              رمز عبور پنل هنرجویی *
            </label>
            <input
              id="reg-pass"
              name="password"
              type="password"
              required
              minLength={6}
              dir="ltr"
              className="bg-transparent border-b border-border py-3 text-sm outline-none focus:border-foreground transition-colors text-start min-h-[44px]"
              placeholder="حداقل ۶ کاراکتر"
              autoComplete="new-password"
            />
          </div>
          <div className="grid gap-2">
            <label htmlFor="reg-email" className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
              ایمیل (اختیاری)
            </label>
            <input
              id="reg-email"
              name="email"
              type="email"
              dir="ltr"
              className="bg-transparent border-b border-border py-3 text-sm outline-none focus:border-foreground transition-colors text-start min-h-[44px]"
              placeholder="you@example.com"
              autoComplete="email"
            />
          </div>
        </div>
      )}

      <div className="grid gap-5 sm:grid-cols-2">
        <div className="grid gap-2">
          <label htmlFor="reg-field" className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
            رشته تحصیلی
          </label>
          <input
            id="reg-field"
            name="field"
            placeholder="مثلاً معماری"
            className="bg-transparent border-b border-border py-3 text-sm outline-none focus:border-foreground transition-colors min-h-[44px]"
          />
        </div>
        <div className="grid gap-2">
          <label htmlFor="reg-edu" className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
            سوابق تحصیلی
          </label>
          <input
            id="reg-edu"
            name="education"
            placeholder="مثلاً کارشناسی معماری"
            className="bg-transparent border-b border-border py-3 text-sm outline-none focus:border-foreground transition-colors min-h-[44px]"
          />
        </div>
      </div>

      <div className="grid gap-2">
        <label htmlFor="reg-note" className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
          توضیحات (اختیاری)
        </label>
        <textarea
          id="reg-note"
          name="note"
          rows={3}
          placeholder="مثلاً: سابقه کار با اتوکد دارم؛ می‌خواهم برای استخدام در دفتر تقویت شوم."
          className="w-full bg-transparent border border-border rounded-md p-3 text-sm outline-none focus:border-foreground transition-colors resize-y min-h-[44px]"
        />
      </div>

      <button
        type="submit"
        disabled={busy}
        className="flex min-h-[52px] items-center justify-center gap-2 bg-foreground text-background rounded-md px-6 text-sm font-medium uppercase tracking-[0.12em] hover:opacity-90 transition-opacity disabled:opacity-50"
      >
        {busy && <Loader2 className="size-4 animate-spin" aria-hidden="true" />}
        ثبت‌نام و رزرو صندلی
      </button>
      <p className="text-xs leading-5 text-muted-foreground">
        با ثبت‌نام، حساب هنرجویی شما ساخته می‌شود و به پنل دانلود فایل‌ها و
        حضور و غیاب دسترسی خواهید داشت. پرداخت شهریه پس از تماس کارشناسان
        انجام می‌شود.
      </p>
    </form>
  );
}
