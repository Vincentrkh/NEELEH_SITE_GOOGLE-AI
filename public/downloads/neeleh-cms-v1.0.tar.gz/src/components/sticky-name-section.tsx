"use client";

import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { useLang } from "./language-provider";

/**
 * StickyNameSection — the signature "bleibt / gleich" sticky section.
 *
 * A 180vh tall section whose inner is `position: sticky`; the combined
 * name "ARIA KAVIANI" stays pinned while the section scrolls past, and
 * the wordmark grows in width from 35vw → 100vw with scroll progress.
 *
 * At the bottom of the section: the footer meta line
 * "'26 © All Right Reserved · made w/ care"
 */
export function StickyNameSection() {
  const { t, isRTL } = useLang();
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end end"],
  });

  const width = useTransform(scrollYProgress, [0, 1], ["35vw", "100vw"]);
  const opacity = useTransform(scrollYProgress, [0, 0.1, 0.9, 1], [0, 1, 1, 0.6]);

  return (
    <section
      ref={ref}
      className="relative h-[180vh] border-t border-border"
      aria-label={t.a11y.stickyName}
    >
      <div className="sticky top-0 h-screen flex flex-col items-center justify-center overflow-hidden">
        <motion.div
          style={{ width, opacity }}
          className="flex items-center justify-center text-foreground"
        >
          <span className="font-medium tracking-[-0.05em] leading-[0.85] text-[clamp(4rem,22vw,22rem)] whitespace-nowrap">
            {t.brand.stickyA}
          </span>
          <span className="font-serif-display italic font-normal tracking-[-0.04em] leading-[0.85] text-[clamp(4rem,22vw,22rem)] whitespace-nowrap text-muted-foreground">
            {t.brand.stickyB}
          </span>
        </motion.div>

        {/* Bottom meta row pinned below */}
        <div className="absolute bottom-6 sm:bottom-8 left-0 right-0">
          <div className="mx-auto max-w-[1800px] px-5 sm:px-8 lg:px-12">
            <div className="flex items-center justify-between text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              <span>{t.sticky.copyright}</span>
              <span className="hidden sm:inline">{t.sticky.version}</span>
              <span>
                {t.sticky.madeWith}{" "}
                <span
                  className={`text-foreground ${
                    isRTL ? "fa-serif" : "font-serif-display italic"
                  }`}
                >
                  {t.sticky.madeWithAccent}
                </span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
