"use client";

import { useEffect, useState } from "react";
import { GooDefs } from "@/components/goo-defs";
import { Preloader } from "@/components/preloader";
import { CustomCursor } from "@/components/custom-cursor";
import { SiteHeader } from "@/components/site-header";
import { HeroSection } from "@/components/hero-section";
import {
  FluidReveal,
  DEFAULT_BRUSH_RADIUS,
} from "@/components/fluid-reveal";
import {
  BrushSettings,
  DEFAULT_REVEAL_BG,
  type RevealBg,
} from "@/components/brush-settings";
import { OrbitTiles, type OrbitTile } from "@/components/orbit-tiles";
import { WorkSection } from "@/components/work-section";
import { AwardsSection } from "@/components/awards-section";
import { StickyNameSection } from "@/components/sticky-name-section";
import { PhilosophySection } from "@/components/philosophy-section";
import { ContactSection } from "@/components/contact-section";
import { useLenis } from "@/hooks/use-lenis";

/**
 * بخش تعاملی صفحه اصلی — همان ساختار پورتفولیو فعلی، دست‌نخورده.
 * این کامپوننت کلاینت است چون از useLenis، useState و useEffect استفاده می‌کند.
 * توسط page.tsx (Server Component) رندر می‌شود تا داده‌های دیتابیس هم تزریق شوند.
 */

const PROJECT_TILES: OrbitTile[] = [
  { src: "/images/hero.png", alt: "Neeleh studio", href: "#top" },
  { src: "/images/tier-beginner.png", alt: "Tier 1 — Foundation (Phase 2, SketchUp, Revit BIM)", href: "#work" },
  { src: "/images/tier-intermediate.png", alt: "Tier 2 — Intermediate (Rhino, Enscape/V-Ray, Excel)", href: "#work" },
  { src: "/images/tier-pro.png", alt: "Tier 3 — Advanced (Grasshopper, Automation, AI)", href: "#awards" },
];

export function HomeInteractive() {
  useLenis();

  const [brushRadius, setBrushRadius] = useState(DEFAULT_BRUSH_RADIUS);
  const [revealBg, setRevealBg] = useState<RevealBg>(DEFAULT_REVEAL_BG);

  useEffect(() => {
    document.documentElement.classList.remove("dark");
  }, []);

  return (
    <div className="relative min-h-screen flex flex-col grain">
      <GooDefs />
      <Preloader />
      <CustomCursor />
      <SiteHeader />

      <main className="flex-1 relative">
        <FluidReveal
          maskColor="rgb(255, 255, 255)"
          brushRadius={brushRadius}
          revealBackground={revealBg.value}
          revealContent={<OrbitTiles tiles={PROJECT_TILES} />}
        >
          <HeroSection />
        </FluidReveal>
        <WorkSection />
        <AwardsSection />
        <StickyNameSection />
        <PhilosophySection />
        <ContactSection />
      </main>

      <BrushSettings
        value={brushRadius}
        onChange={setBrushRadius}
        bg={revealBg}
        onBgChange={setRevealBg}
      />
    </div>
  );
}
