"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useToast } from "@/hooks/use-toast";
import { SETTINGS_GROUPS } from "@/lib/settings";
import { Loader2, Save, RotateCcw } from "lucide-react";

type Setting = { key: string; value: string; label: string | null; type: string | null };

export function SettingsEditor({ initialSettings }: { initialSettings: Setting[] }) {
  const router = useRouter();
  const { toast } = useToast();
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const map: Record<string, string> = {};
    for (const s of initialSettings) {
      map[s.key] = s.value;
    }
    setSettings(map);
  }, [initialSettings]);

  function update(key: string, value: string) {
    setSettings((s) => ({ ...s, [key]: value }));
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const items = SETTINGS_GROUPS.flatMap((g) => g.items).map((item) => ({
        key: item.key,
        value: settings[item.key] ?? "",
        label: item.label,
        type: item.type ?? "text",
      }));
      const res = await fetch("/api/dashboard/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ settings: items }),
      });
      if (!res.ok) {
        toast({ title: "خطا", description: "ذخیره نشد", variant: "destructive" });
        return;
      }
      toast({ title: "تنظیمات ذخیره شد", description: "تغییرات در سایت اعمال شد" });
      router.refresh();
    } catch {
      toast({ title: "خطا", description: "ارتباط برقرار نشد", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-8">
      {SETTINGS_GROUPS.map((group) => (
        <fieldset
          key={group.key}
          className="space-y-5 rounded-lg border border-border bg-card p-5 sm:p-6"
        >
          <legend className="px-2 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            {group.label}
          </legend>
          <div className="grid gap-5 sm:grid-cols-2">
            {group.items.map((item) => (
              <div key={item.key} className={item.type === "textarea" ? "sm:col-span-2" : ""}>
                <label className="block text-xs uppercase tracking-[0.14em] text-muted-foreground mb-2">
                  {item.label}
                </label>
                {item.type === "textarea" ? (
                  <textarea
                    value={settings[item.key] ?? ""}
                    onChange={(e) => update(item.key, e.target.value)}
                    rows={3}
                    className="w-full bg-transparent border border-border rounded-md p-3 text-sm outline-none focus:border-foreground transition-colors resize-y min-h-[44px]"
                  />
                ) : (
                  <input
                    type="text"
                    value={settings[item.key] ?? ""}
                    onChange={(e) => update(item.key, e.target.value)}
                    dir={item.key.startsWith("social.") || item.key.includes("email") ? "ltr" : undefined}
                    className="w-full bg-transparent border-b border-border py-3 text-sm outline-none focus:border-foreground transition-colors min-h-[44px] text-start"
                  />
                )}
                <code className="text-[10px] text-muted-foreground/60 mt-1 block" dir="ltr">
                  {item.key}
                </code>
              </div>
            ))}
          </div>
        </fieldset>
      ))}

      {/* Submit */}
      <div className="flex items-center justify-end gap-3 sticky bottom-4 z-10">
        <button
          type="submit"
          disabled={busy}
          className="flex min-h-[48px] items-center gap-2 bg-foreground text-background rounded-md px-6 text-sm font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
        >
          {busy ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
          ذخیره تنظیمات
        </button>
      </div>
    </form>
  );
}
