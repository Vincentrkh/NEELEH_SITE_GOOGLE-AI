"use client";

import { motion } from "framer-motion";
import { useState } from "react";
import { SplitText } from "./split-text";
import { useLang } from "./language-provider";
import { toFaDigits } from "@/lib/i18n";

type CourseRow = {
  id: string;
  /** 1 | 2 | 3 → tier badge */
  tier: 1 | 2 | 3;
  title: string;
  description: string;
  /** EN key into t.work.disciplines (translated) */
  discipline: string;
  /** Each entry: a syllabus bullet (translated) */
  syllabus: string[];
};

/** Pulls the live 9-course catalog from the i18n dictionary. */
function useCourses(): CourseRow[] {
  const { t } = useLang();
  return t.courses.map((c) => ({
    id: c.id,
    tier: c.tier as 1 | 2 | 3,
    title: c.title,
    description: c.description,
    discipline: c.discipline,
    syllabus: c.syllabus,
  }));
}

const TIER_BADGE_CLASSES: Record<1 | 2 | 3, string> = {
  1: "border-emerald-500/40 text-emerald-700 bg-emerald-50",
  2: "border-amber-500/40 text-amber-700 bg-amber-50",
  3: "border-rose-500/40 text-rose-700 bg-rose-50",
};

export function AwardsSection() {
  const { t, isRTL } = useLang();
  const courses = useCourses();

  return (
    <section
      id="awards"
      className="relative py-24 sm:py-36 border-t border-border overflow-hidden"
    >
      <div className="mx-auto max-w-[1800px] px-5 sm:px-8 lg:px-12">
        {/* Heading */}
        <div className="grid grid-cols-12 gap-6 mb-12 sm:mb-20 items-end">
          <div className="col-span-6 md:col-span-3">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
                {t.awards.index}
              </div>
              <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                {t.awards.label}
              </div>
            </motion.div>
          </div>
          <div className="col-span-12 md:col-span-9 mt-6 md:mt-0">
            <div className="flex flex-wrap items-end gap-x-4 sm:gap-x-8 gap-y-2">
              {t.awards.heading.map((word, i) => (
                <HeadingWord
                  key={`${word}-${i}`}
                  text={word}
                  delay={i * 0.1}
                  muted={i > 0}
                />
              ))}
            </div>
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="mt-6 text-base sm:text-lg leading-relaxed text-muted-foreground max-w-md"
            >
              {t.awards.sub}
            </motion.p>
          </div>
        </div>

        {/* Table header row (visible only on md+) */}
        <div className="hidden md:grid grid-cols-12 gap-4 border-b border-border pb-3 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
          <div className="col-span-1">{isRTL ? "ردیف" : "No."}</div>
          <div className="col-span-4">{isRTL ? "عنوان دوره" : "Course"}</div>
          <div className="col-span-2">{isRTL ? "سطح" : "Tier"}</div>
          <div className="col-span-5">{t.awards.syllabusLabel}</div>
        </div>

        {/* Course rows */}
        <div className="border-t md:border-t-0 border-border">
          {courses.map((c, i) => (
            <CourseRowCard key={c.id} course={c} index={i} />
          ))}
        </div>
      </div>

      {/* Marquee ticker */}
      <div className="mt-20 sm:mt-28 overflow-hidden border-y border-border py-5 sm:py-7 bg-foreground/[0.02]">
        <Marquee>
          {t.awards.marquee.map((item, i) => (
            <span
              key={i}
              className={`flex items-center gap-8 sm:gap-12 text-3xl sm:text-5xl whitespace-nowrap px-6 sm:px-10 ${
                isRTL ? "fa-serif" : "font-serif-display italic"
              }`}
            >
              {item}
              <span className="text-2xl text-muted-foreground">✦</span>
            </span>
          ))}
        </Marquee>
      </div>
    </section>
  );
}

function HeadingWord({
  text,
  delay,
  muted,
}: {
  text: string;
  delay: number;
  muted?: boolean;
}) {
  return (
    <div className="mask-reveal">
      <SplitText
        as="h2"
        text={text}
        mode="chars"
        stagger={0.04}
        duration={0.7}
        delay={delay}
        className={`text-4xl sm:text-6xl md:text-7xl font-medium tracking-[-0.04em] leading-[0.95] ${
          muted ? "text-muted-foreground" : "text-foreground"
        }`}
      />
    </div>
  );
}

function CourseRowCard({ course, index }: { course: CourseRow; index: number }) {
  const { lang, t, isRTL } = useLang();
  const [open, setOpen] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16, filter: "blur(6px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{
        duration: 0.5,
        delay: Math.min(index * 0.04, 0.25),
        ease: [0.22, 1, 0.36, 1],
      }}
      className="group border-b border-border"
    >
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="w-full grid grid-cols-12 gap-4 items-center py-4 sm:py-5 hover:bg-foreground/[0.025] transition-colors text-start min-h-[64px]"
      >
        {/* Index */}
        <div className="col-span-2 md:col-span-1 text-sm font-mono text-muted-foreground tabular-nums">
          {lang === "fa" ? toFaDigits(course.id) : course.id}
        </div>

        {/* Title + description (mobile shows description under title) */}
        <div className="col-span-10 md:col-span-4">
          <div className="text-base sm:text-lg md:text-xl font-medium tracking-tight leading-snug">
            {course.title}
          </div>
          <p className="md:hidden mt-1.5 text-xs leading-relaxed text-muted-foreground line-clamp-2">
            {course.description}
          </p>
        </div>

        {/* Tier badge */}
        <div className="hidden md:block md:col-span-2">
          <span
            className={`inline-flex items-center gap-1.5 border px-2 py-1 text-[10px] uppercase tracking-[0.12em] ${TIER_BADGE_CLASSES[course.tier]}`}
          >
            {t.awards.titles[`tier${course.tier}`]}
          </span>
        </div>

        {/* Syllabus preview — first 2 items on desktop, full list expands */}
        <div className="hidden md:block md:col-span-5">
          <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
            {course.syllabus.slice(0, open ? 99 : 2).map((s, i) => (
              <span key={i} className="flex items-center gap-2">
                <span className="size-1 rounded-full bg-foreground/40" aria-hidden />
                {s}
              </span>
            ))}
            {!open && course.syllabus.length > 2 && (
              <span className="text-clay hover:underline">
                +{course.syllabus.length - 2} {isRTL ? "بیشتر" : "more"}
              </span>
            )}
          </div>
        </div>

        {/* Toggle arrow */}
        <div className="hidden md:flex md:col-span-12 justify-end pt-2">
          <motion.span
            animate={{ rotate: open ? 90 : 0 }}
            transition={{ duration: 0.3 }}
            className="text-sm text-muted-foreground"
            aria-hidden
          >
            {isRTL ? "←" : "→"}
          </motion.span>
        </div>
      </button>

      {/* Mobile expanded — always show syllabus as a stacked list */}
      <div className="md:hidden pb-5">
        <ul className="space-y-2 ps-2 text-sm leading-relaxed text-muted-foreground">
          {course.syllabus.map((s, i) => (
            <li key={i} className="flex gap-2">
              <span className="mt-2 size-1 rounded-full bg-foreground/40 shrink-0" aria-hidden />
              <span>{s}</span>
            </li>
          ))}
        </ul>
      </div>
      {/* Desktop expanded */}
      {open && (
        <div className="hidden md:block pb-5">
          <p className="text-sm leading-relaxed text-muted-foreground max-w-3xl mb-3">
            {course.description}
          </p>
          <ul className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm leading-relaxed text-foreground/80">
            {course.syllabus.map((s, i) => (
              <li key={i} className="flex gap-2">
                <span className="mt-2 size-1 rounded-full bg-foreground/40 shrink-0" aria-hidden />
                <span>{s}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </motion.div>
  );
}

function Marquee({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="flex shrink-0 animate-marquee"
      style={{ "--duration": "55s" } as React.CSSProperties}
    >
      <div className="flex shrink-0">{children}</div>
      <div className="flex shrink-0" aria-hidden>
        {children}
      </div>
    </div>
  );
}
