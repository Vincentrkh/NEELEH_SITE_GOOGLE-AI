import Link from "next/link";
import { db } from "@/lib/db";
import { faDate, faNumber } from "@/lib/format";
import { ArrowUpRight, Clock, Newspaper } from "lucide-react";

export const dynamic = "force-dynamic";

/**
 * Latest Posts — بخش آخرین مقالات وبلاگ در صفحه اصلی.
 * ۳ مقاله منتشر شده از دیتابیس می‌خواند.
 */
export async function LatestPostsSection() {
  let posts;
  try {
    posts = await db.post.findMany({
      where: { status: "PUBLISHED" },
      orderBy: { publishedAt: "desc" },
      take: 3,
      select: {
        id: true,
        slug: true,
        title: true,
        excerpt: true,
        coverUrl: true,
        readingMins: true,
        publishedAt: true,
        author: { select: { name: true } },
      },
    });
  } catch {
    return null;
  }

  if (posts.length === 0) return null;

  return (
    <section className="border-t border-border">
      <div className="mx-auto max-w-[1800px] px-5 sm:px-8 lg:px-12 py-16 sm:py-24">
        <div className="flex items-end justify-between gap-4 mb-10">
          <div>
            <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
              [ بلاگ ]
            </p>
            <h2 className="text-3xl sm:text-5xl font-medium tracking-[-0.03em]">
              یادداشت‌های معماری
            </h2>
          </div>
          <Link
            href="/blog"
            className="group flex min-h-[44px] items-center gap-1 text-xs uppercase tracking-[0.14em] text-muted-foreground hover:text-foreground transition-colors"
          >
            همه مقالات
            <ArrowUpRight className="size-3.5 rtl:-scale-x-100 group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform" />
          </Link>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {posts.map((p) => (
            <Link
              key={p.id}
              href={`/blog/${p.slug}`}
              className="group rounded-lg border border-border bg-card overflow-hidden hover:border-foreground/30 transition-colors"
            >
              {p.coverUrl ? (
                <div className="h-40 overflow-hidden bg-secondary/40">
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={p.coverUrl}
                    alt={p.title}
                    className="size-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
              ) : (
                <div className="h-40 bg-secondary/40 flex items-center justify-center">
                  <Newspaper className="size-8 text-muted-foreground" />
                </div>
              )}
              <div className="p-5">
                <h3 className="text-base font-medium leading-snug mb-2 group-hover:text-foreground transition-colors line-clamp-2">
                  {p.title}
                </h3>
                <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2 mb-3">
                  {p.excerpt}
                </p>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span>{p.author.name}</span>
                  <span>•</span>
                  <span>{faDate(p.publishedAt)}</span>
                  {p.readingMins > 0 && (
                    <>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Clock className="size-3" />
                        {faNumber(p.readingMins)} دقیقه
                      </span>
                    </>
                  )}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
