"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { dict, type Dict, type Lang } from "@/lib/i18n";

/**
 * LanguageProvider — client-side bilingual switching (EN default, FA optional).
 *
 * - Persists the choice to localStorage ("site-lang").
 * - Updates <html lang> and <html dir> so the whole document mirrors in RTL
 *   and picks up the Persian font stack (see globals.css).
 * - All text comes from the dictionary via useLang().t — no extra routes,
 *   so the site stays a single page in this sandbox.
 */

const STORAGE_KEY = "site-lang";

type LangContextValue = {
  lang: Lang;
  isRTL: boolean;
  t: Dict;
  setLang: (lang: Lang) => void;
};

const LangContext = createContext<LangContextValue | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  // Server render + first client render are English (matches the <html lang="en">
  // server markup). The stored preference is applied right after hydration.
  const [lang, setLangState] = useState<Lang>("en");

  useEffect(() => {
    let stored: string | null = null;
    try {
      stored = window.localStorage.getItem(STORAGE_KEY);
    } catch {
      /* private mode etc. — ignore */
    }
    if (stored === "fa" || stored === "en") {
      setLangState(stored);
    }
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.lang = lang;
    root.dir = lang === "fa" ? "rtl" : "ltr";
  }, [lang]);

  const setLang = useCallback((next: Lang) => {
    setLangState(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, next);
    } catch {
      /* ignore */
    }
  }, []);

  const value = useMemo<LangContextValue>(
    () => ({
      lang,
      isRTL: lang === "fa",
      t: dict[lang],
      setLang,
    }),
    [lang, setLang]
  );

  return <LangContext.Provider value={value}>{children}</LangContext.Provider>;
}

export function useLang(): LangContextValue {
  const ctx = useContext(LangContext);
  if (!ctx) {
    throw new Error("useLang must be used inside <LanguageProvider>");
  }
  return ctx;
}
