import Link from "next/link";
import { getSiteSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

/**
 * Footer پویا — اطلاعات تماس و شبکه‌های اجتماعی از تنظیمات دیتابیس خوانده می‌شوند.
 * اگر دیتابیس در دسترس نباشد، fallback به مقادیر پیش‌فرض.
 */
export async function SiteFooter() {
  const s = await getSiteSettings();

  const socials = [
    { label: "Instagram", href: s["social.instagram"] || "https://instagram.com", handle: "@neeleh.academy" },
    { label: "Telegram", href: s["social.telegram"] || "https://telegram.org", handle: "@neeleh" },
    { label: "LinkedIn", href: s["social.linkedin"] || "https://linkedin.com", handle: "in/neeleh-academy" },
    { label: "YouTube", href: s["social.youtube"] || "https://youtube.com", handle: "@neeleh" },
    { label: "Behance", href: s["social.behance"] || "https://behance.net", handle: "/neeleh" },
  ].filter((x) => x.href);

  return (
    <footer className="mt-auto border-t border-border bg-background pb-[env(safe-area-inset-bottom)]">
      <div className="mx-auto max-w-[1800px] px-5 sm:px-8 lg:px-12 py-10 sm:py-12">
        <div className="grid gap-8 sm:grid-cols-3">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2.5 mb-3">
              <span className="grid size-8 place-items-center rounded-md bg-foreground text-background font-bold text-lg">
                ن
              </span>
              <span className="font-bold">آکادمی نیله</span>
            </div>
            <p className="max-w-xs text-sm leading-6 text-muted-foreground">
              {s["hero.tagline"]} — {s["stats.years"]} سال تجربه حرفه‌ای، از
              نقشه‌کشی اجرایی تا معماری در عصر هوش مصنوعی.
            </p>
          </div>

          {/* Quick links */}
          <nav aria-label="لینک‌های فوتر">
            <h3 className="text-sm font-semibold mb-3">دسترسی سریع</h3>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li>
                <Link href="/courses" className="flex min-h-[44px] items-center hover:text-foreground transition-colors">
                  همه دوره‌ها
                </Link>
              </li>
              <li>
                <Link href="/courses?tier=BEGINNER" className="flex min-h-[44px] items-center hover:text-foreground transition-colors">
                  دوره‌های مبتدی
                </Link>
              </li>
              <li>
                <Link href="/courses?tier=PRO" className="flex min-h-[44px] items-center hover:text-foreground transition-colors">
                  دوره‌های حرفه‌ای
                </Link>
              </li>
              <li>
                <Link href="/blog" className="flex min-h-[44px] items-center hover:text-foreground transition-colors">
                  بلاگ
                </Link>
              </li>
              <li>
                <Link href="/login" className="flex min-h-[44px] items-center hover:text-foreground transition-colors">
                  ورود هنرجویان
                </Link>
              </li>
            </ul>
          </nav>

          {/* Contact */}
          <div>
            <h3 className="text-sm font-semibold mb-3">تماس با آکادمی</h3>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li>برگزاری کلاس‌ها: حضوری — در محل آکادمی</li>
              <li dir="ltr" className="text-start">{s["contact.phone"]}</li>
              <li dir="ltr" className="text-start">{s["contact.email"]}</li>
              <li>{s["contact.hours"]}</li>
            </ul>
          </div>
        </div>

        <div className="mt-8 flex flex-col items-center justify-between gap-2 border-t border-border pt-6 text-xs text-muted-foreground sm:flex-row">
          <span>© {new Date().getFullYear()} آکادمی معماری نیله — تمامی حقوق محفوظ است.</span>
          <span>{s["hero.tagline"]}.</span>
        </div>
      </div>
    </footer>
  );
}
