import Link from "next/link";
import { db } from "@/lib/db";
import { faNumber, faPrice, TIER_LABEL, REG_STATUS_LABEL } from "@/lib/format";
import { ArrowUpRight, Clock, Users } from "lucide-react";

export const dynamic = "force-dynamic";

const TIER_BADGE: Record<string, string> = {
  BEGINNER: "border-emerald-500/40 text-emerald-700 bg-emerald-50",
  INTERMEDIATE: "border-amber-500/40 text-amber-700 bg-amber-50",
  PRO: "border-rose-500/40 text-rose-700 bg-rose-50",
};

/**
 * Featured Courses — بخش دوره‌های برجسته صفحه اصلی.
 * ۳ دوره featured از دیتابیس می‌خواند.
 * اگر دوره‌ای نبود، چیزی نمایش نمی‌دهد (نه خطا).
 */
export async function FeaturedCoursesSection() {
  let courses;
  try {
    courses = await db.course.findMany({
      where: { featured: true, published: true },
      orderBy: { sortOrder: "asc" },
      take: 3,
      include: {
        _count: {
          select: {
            registrations: { where: { status: { not: "CANCELLED" } } },
          },
        },
      },
    });
  } catch {
    return null;
  }

  if (courses.length === 0) return null;

  return (
    <section className="border-t border-border bg-secondary/30">
      <div className="mx-auto max-w-[1800px] px-5 sm:px-8 lg:px-12 py-16 sm:py-24">
        <div className="flex items-end justify-between gap-4 mb-10">
          <div>
            <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
              [ دوره‌های برجسته ]
            </p>
            <h2 className="text-3xl sm:text-5xl font-medium tracking-[-0.03em]">
              از کجا شروع کنید؟
            </h2>
          </div>
          <Link
            href="/courses"
            className="group flex min-h-[44px] items-center gap-1 text-xs uppercase tracking-[0.14em] text-muted-foreground hover:text-foreground transition-colors"
          >
            همه دوره‌ها
            <ArrowUpRight className="size-3.5 rtl:-scale-x-100 group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform" />
          </Link>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {courses.map((c) => {
            const remaining = Math.max(0, c.capacity - c._count.registrations);
            return (
              <Link
                key={c.id}
                href={`/courses/${c.slug}`}
                className="group rounded-lg border border-border bg-card overflow-hidden hover:border-foreground/30 transition-colors"
              >
                <div className="h-32 bg-gradient-to-br from-secondary to-secondary/40 relative">
                  {c.bannerUrl && (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={c.bannerUrl}
                      alt=""
                      className="absolute inset-0 size-full object-cover opacity-70"
                    />
                  )}
                  <span
                    className={`absolute top-3 start-3 inline-flex items-center gap-1.5 border px-2 py-0.5 text-[10px] uppercase tracking-[0.14em] bg-background/80 backdrop-blur ${TIER_BADGE[c.tier]}`}
                  >
                    {TIER_LABEL[c.tier]}
                  </span>
                </div>
                <div className="p-5">
                  <h3 className="text-base font-medium leading-snug mb-2 group-hover:text-foreground transition-colors line-clamp-2">
                    {c.title}
                  </h3>
                  <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2 mb-4">
                    {c.description}
                  </p>
                  <div className="flex items-center justify-between pt-3 border-t border-border">
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      {c.durationHrs > 0 && (
                        <span className="flex items-center gap-1">
                          <Clock className="size-3" />
                          {faNumber(c.durationHrs)} ساعت
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Users className="size-3" />
                        {faNumber(remaining)} صندلی
                      </span>
                    </div>
                    <span className="text-sm font-medium tabular-nums">
                      {c.price > 0 ? faPrice(c.price) : "تماس"}
                    </span>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
