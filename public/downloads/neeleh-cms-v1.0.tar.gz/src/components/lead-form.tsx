"use client";

import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Loader2, CheckCircle2, Send } from "lucide-react";

/** فرم مشاوره رایگان — در صفحه اصلی و صفحه تماس استفاده می‌شود. */
export function LeadForm() {
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [success, setSuccess] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setBusy(true);
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: fd.get("name"),
          phone: fd.get("phone"),
          email: fd.get("email"),
          message: fd.get("message"),
        }),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) {
        toast({ title: "ارسال نشد", description: data.error, variant: "destructive" });
        return;
      }
      setSuccess(true);
      toast({ title: "درخواست شما ثبت شد ✓" });
    } catch {
      toast({ title: "خطا", description: "ارتباط برقرار نشد", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  if (success) {
    return (
      <div className="rounded-lg border border-emerald-300 bg-emerald-50 p-8 text-center">
        <CheckCircle2 className="size-10 mx-auto text-emerald-600 mb-3" />
        <h3 className="text-lg font-medium mb-2">درخواست شما ثبت شد</h3>
        <p className="text-sm text-emerald-800 leading-relaxed">
          همکاران ما در اولین فرصت با شما تماس می‌گیرند تا مسیر پیشنهادی را
          هماهنگ کنیم.
        </p>
        <button
          type="button"
          onClick={() => setSuccess(false)}
          className="mt-5 inline-flex min-h-[44px] items-center rounded-md border border-emerald-300 px-5 text-sm hover:bg-emerald-100 transition-colors"
        >
          ارسال درخواست دیگر
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="space-y-5 rounded-lg border border-border bg-card p-6 sm:p-8">
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="lead-name" className="block text-xs uppercase tracking-[0.14em] text-muted-foreground mb-2">
            نام و نام خانوادگی *
          </label>
          <input
            id="lead-name"
            name="name"
            required
            minLength={3}
            placeholder="مثلاً امیر کریمی"
            className="w-full bg-transparent border-b border-border py-3 text-sm outline-none focus:border-foreground transition-colors min-h-[44px]"
          />
        </div>
        <div>
          <label htmlFor="lead-phone" className="block text-xs uppercase tracking-[0.14em] text-muted-foreground mb-2">
            شماره موبایل *
          </label>
          <input
            id="lead-phone"
            name="phone"
            required
            inputMode="tel"
            dir="ltr"
            placeholder="0912 345 6789"
            autoComplete="tel"
            className="w-full bg-transparent border-b border-border py-3 text-sm outline-none focus:border-foreground transition-colors text-start min-h-[44px]"
          />
        </div>
      </div>

      <div>
        <label htmlFor="lead-email" className="block text-xs uppercase tracking-[0.14em] text-muted-foreground mb-2">
          ایمیل (اختیاری)
        </label>
        <input
          id="lead-email"
          name="email"
          type="email"
          dir="ltr"
          placeholder="you@example.com"
          className="w-full bg-transparent border-b border-border py-3 text-sm outline-none focus:border-foreground transition-colors text-start min-h-[44px]"
        />
      </div>

      <div>
        <label htmlFor="lead-message" className="block text-xs uppercase tracking-[0.14em] text-muted-foreground mb-2">
          پیام شما
        </label>
        <textarea
          id="lead-message"
          name="message"
          rows={4}
          placeholder="درباره سوابق، هدف شغلی و دوره مورد نظرتان بنویسید..."
          className="w-full bg-transparent border border-border rounded-md p-3 text-sm outline-none focus:border-foreground transition-colors resize-y min-h-[44px]"
        />
      </div>

      <button
        type="submit"
        disabled={busy}
        className="w-full flex min-h-[52px] items-center justify-center gap-2 bg-foreground text-background rounded-md px-6 text-sm font-medium uppercase tracking-[0.12em] hover:opacity-90 transition-opacity disabled:opacity-50"
      >
        {busy ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
        ارسال درخواست مشاوره
      </button>
    </form>
  );
}
