"use client";

import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { SplitText } from "./split-text";
import { useLang } from "@/components/language-provider";

/**
 * HeroSection — top of page.
 *
 * Matches bleibtgleich.dev hero layout:
 * - Black mask-icon graphic, top-left
 * - Status text top-right ("Based in Tehran" / "Working w/ selected clients")
 * - Big brand wordmark "Neeleh / Academy" middle-right
 * - Vertical "Designer & Developer" label to left of name
 * - Big descriptors "Design Digital Products UX/UI & Web- flow dev." bottom area
 * - Persistent "neeleh" (left) / "academy" (right) watermark at bottom corners
 *   (stays visible across the whole hero scroll)
 *
 * Each heading is its own h1 with per-char staggered mask reveal.
 */

export function HeroSection() {
  const ref = useRef<HTMLDivElement>(null);
  const { t } = useLang();
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  // Hero content drifts up & fades as we scroll past it
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "-20%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.85], [1, 0]);

  return (
    <section
      id="top"
      ref={ref}
      className="relative min-h-[100svh] flex flex-col overflow-hidden pt-20"
    >
      {/* Main content */}
      <motion.div
        style={{ y, opacity }}
        className="flex-1 relative px-5 sm:px-8 lg:px-12 py-12 sm:py-16"
      >
        {/* === Top row: mask-icon + status === */}
        <div className="flex items-start justify-between">
          {/* Black mask-icon graphic, top-left */}
          <MaskIcon />

          {/* Status text, opposite corner (mirrors with direction) */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5, duration: 0.8 }}
            className="text-end text-xs leading-relaxed text-foreground"
          >
            <div className="uppercase">{t.hero.basedIn}</div>
            <div className="uppercase text-muted-foreground">
              {t.hero.workingWith}
            </div>
          </motion.div>
        </div>

        {/* === Middle: name + vertical label === */}
        <div className="mt-16 sm:mt-24 md:mt-32 grid grid-cols-12 gap-4 items-center">
          {/* Vertical "Designer & Developer" label, left */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.4, duration: 0.8 }}
            className="col-span-12 md:col-span-3 lg:col-span-2 flex md:flex-col gap-3 md:gap-2 md:[writing-mode:vertical-rl] md:rotate-180"
          >
            <span className="text-xs uppercase text-foreground">
              {t.hero.roleA}
            </span>
            <span className="text-xs uppercase text-muted-foreground">
              {t.hero.roleB}
            </span>
          </motion.div>

          {/* Big name, center-end (kept Latin in both locales) */}
          <div className="col-span-12 md:col-span-9 lg:col-span-10 space-y-0">
            <HeroLine
              text={t.brand.heroLine1}
              delay={0.5}
              className="font-medium tracking-[-0.04em] leading-[0.88] text-[clamp(3rem,11vw,11rem)]"
            />
            <HeroLine
              text={t.brand.heroLine2}
              delay={0.65}
              className="font-medium tracking-[-0.04em] leading-[0.88] text-[clamp(3rem,11vw,11rem)]"
            />
          </div>
        </div>

        {/* === Bottom: big descriptors === */}
        <div className="mt-12 sm:mt-16 grid grid-cols-2 sm:grid-cols-4 gap-x-4 sm:gap-x-8 gap-y-0">
          {t.hero.descriptors.map((word, i) => (
            <HeroLine
              key={`${word}-${i}`}
              text={word}
              delay={0.85 + i * 0.1}
              className={`font-medium tracking-[-0.03em] leading-[1] text-[clamp(1.8rem,5.5vw,5.5rem)] ${
                i === 0 || i === 6 ? "text-foreground" : "text-muted-foreground"
              }`}
            />
          ))}
          {/* tagline — the 8th cell of the same grid (beside the last 3 words) */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.7, duration: 0.8 }}
            className="self-end text-xs sm:text-sm leading-relaxed text-muted-foreground max-w-[20rem]"
          >
            {t.hero.tagline}{" "}
            <span className="font-serif-display fa-serif italic text-foreground">
              {t.hero.taglineAccent}
            </span>
          </motion.div>
        </div>
      </motion.div>

      {/* === Persistent bottom watermark: brand lowercase (Latin, kept) === */}
      <div className="pointer-events-none absolute bottom-0 left-0 right-0 flex items-end justify-between overflow-hidden">
        <div className="font-medium tracking-[-0.05em] leading-[0.8] text-[clamp(4rem,18vw,18rem)] text-foreground/[0.04] select-none -translate-x-[6%] rtl:translate-x-[6%]">
          {t.brand.watermark1}
        </div>
        <div className="font-medium tracking-[-0.05em] leading-[0.8] text-[clamp(4rem,18vw,18rem)] text-foreground/[0.04] select-none translate-x-[6%] rtl:-translate-x-[6%]">
          {t.brand.watermark2}
        </div>
      </div>
    </section>
  );
}

/**
 * Black mask-icon graphic — signature element top-left of hero.
 * A solid black blob with two white circle "eyes" connected by a thin line.
 */
function MaskIcon() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.2, duration: 1, ease: [0.22, 1, 0.36, 1] }}
      className="relative w-16 h-16 sm:w-20 sm:h-20"
      aria-hidden
    >
      <svg viewBox="0 0 80 80" className="w-full h-full">
        {/* Organic blob body */}
        <path
          d="M 22 18
             C 12 22, 8 34, 12 46
             C 16 58, 28 66, 42 64
             C 56 62, 68 52, 68 38
             C 68 24, 58 14, 44 14
             C 36 14, 28 16, 22 18 Z"
          fill="currentColor"
          className="text-foreground"
        />
        {/* Left eye */}
        <circle cx="30" cy="38" r="4" fill="var(--background)" />
        {/* Right eye */}
        <circle cx="50" cy="38" r="4" fill="var(--background)" />
        {/* Eye connector */}
        <rect
          x="30"
          y="36.5"
          width="20"
          height="1.5"
          fill="var(--background)"
        />
      </svg>
    </motion.div>
  );
}

function HeroLine({
  text,
  delay,
  className,
}: {
  text: string;
  delay: number;
  className?: string;
}) {
  return (
    <div className="mask-reveal">
      <SplitText
        as="h1"
        text={text}
        mode="chars"
        trigger="mount"
        delay={delay}
        stagger={0.04}
        duration={0.8}
        className={className}
      />
    </div>
  );
}
