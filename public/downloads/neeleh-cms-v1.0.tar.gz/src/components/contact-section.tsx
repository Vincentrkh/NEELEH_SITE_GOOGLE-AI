"use client";

import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { SplitText } from "./split-text";
import { useLang } from "./language-provider";

const SOCIALS = [
  { label: "Instagram", href: "https://instagram.com", handle: "@neeleh.academy" },
  { label: "Telegram", href: "https://telegram.org", handle: "@neeleh" },
  { label: "LinkedIn", href: "https://linkedin.com", handle: "in/neeleh-academy" },
  { label: "YouTube", href: "https://youtube.com", handle: "@neeleh" },
  { label: "Behance", href: "https://behance.net", handle: "/neeleh" },
];

const EMAIL = "hello@neeleh.academy";

/**
 * ContactSection — matches bleibtgleich.dev's contact page:
 * - Solid red background (#E31E24 / similar warm red)
 * - Big circular graphic with a black mask-head silhouette in the center
 *   surrounded by smaller circular "buttons" (some with @, some solid)
 * - Two thin horizontal lines framing the central graphic top & bottom
 * - Big wordmark "kaviani" at the bottom center
 * - Footer text: "'26 © All Right Reserved" (left) + "made w/ hate" (right)
 */
export function ContactSection() {
  const { t, isRTL } = useLang();

  return (
    <section
      id="contact"
      className="relative overflow-hidden bg-[#E31E24] text-black"
    >
      {/* === Top horizontal line framing the graphic === */}
      <div className="h-px w-full bg-black/30" />

      {/* === Main graphic area: circle + mask head === */}
      <div className="relative flex items-center justify-center py-16 sm:py-24">
        <ContactDial />
      </div>

      {/* === Bottom horizontal line framing === */}
      <div className="h-px w-full bg-black/30" />

      {/* === Tagline / availability row === */}
      <div className="px-5 sm:px-8 lg:px-12 py-8 sm:py-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-end">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="md:col-span-7"
          >
            <div className="text-xs uppercase tracking-[0.18em] mb-3 text-black/60">
              {t.contact.availability}
            </div>
            <div className="mask-reveal">
              <SplitText
                as="h2"
                text={t.contact.cta}
                mode="chars"
                stagger={0.025}
                duration={0.7}
                className={`text-3xl sm:text-5xl md:text-6xl text-black ${
                  isRTL ? "fa-serif" : "font-serif-display italic"
                }`}
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="md:col-span-4 md:col-start-9 md:text-end"
          >
            <p className="text-sm sm:text-base leading-relaxed text-black/80">
              {t.contact.blurb}
            </p>
          </motion.div>
        </div>
      </div>

      {/* === Big email with mask-reveal hover === */}
      <motion.div
        initial={{ opacity: 0, y: 24, filter: "blur(10px)" }}
        whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="px-5 sm:px-8 lg:px-12 py-10 sm:py-14 border-t border-black/20"
      >
        <div className="text-[10px] uppercase tracking-[0.18em] text-black/60 mb-6">
          {t.contact.writeTo}
        </div>

        <a
          href={`mailto:${EMAIL}`}
          className="group block"
          aria-label={`Email ${EMAIL}`}
        >
          {/* overflow-hidden lives on this inner box so the resting state
              clips the translated duplicate; the <a> also holds the label. */}
          <div className="relative overflow-hidden">
            <div className="font-medium tracking-[-0.03em] leading-[0.9] text-[clamp(1.8rem,7vw,7rem)] text-black transition-transform duration-500 ease-[cubic-bezier(0.76,0,0.24,1)] group-hover:-translate-y-full">
              {EMAIL}
            </div>
            <div
              aria-hidden
              className="absolute inset-0 font-medium tracking-[-0.03em] leading-[0.9] text-[clamp(1.8rem,7vw,7rem)] text-black/30 translate-y-full transition-transform duration-500 ease-[cubic-bezier(0.76,0,0.24,1)] group-hover:translate-y-0"
            >
              {EMAIL}
            </div>
          </div>

          <div className="mt-4 flex items-center gap-2 text-xs uppercase tracking-[0.16em] text-black/60 group-hover:text-black transition-colors">
            <span>{t.contact.openMail}</span>
            <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1 rtl:-scale-x-100 rtl:group-hover:-translate-x-1" />
          </div>
        </a>
      </motion.div>

      {/* === Socials grid === */}
      <div className="px-5 sm:px-8 lg:px-12 pb-10">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-px bg-black/20 border border-black/20">
          {SOCIALS.map((s) => (
            <motion.a
              key={s.label}
              href={s.href}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.4 }}
              className="group flex flex-col gap-1 bg-[#E31E24] p-5 hover:bg-black hover:text-[#E31E24] transition-colors"
            >
              <span className="text-[10px] uppercase tracking-[0.14em] opacity-60 group-hover:opacity-100">
                {s.label}
              </span>
              <span className="text-sm tracking-tight flex items-center gap-1">
                {s.handle}
                <ArrowUpRight className="h-3 w-3 opacity-0 -translate-x-1 rtl:translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 rtl:group-hover:translate-x-0 transition-all" />
              </span>
            </motion.a>
          ))}
        </div>
      </div>

      {/* === Big wordmark at bottom center === */}
      <div className="overflow-hidden border-t border-black/20">
        <div className="font-medium tracking-[-0.05em] leading-[0.8] text-[clamp(3rem,18vw,18rem)] text-center text-black py-8 sm:py-12 select-none">
          {t.brand.watermark2}
        </div>
      </div>

      {/* === Footer text: '26 © / made w/ hate === */}
      <div className="px-5 sm:px-8 lg:px-12 py-6 flex items-center justify-between text-[10px] uppercase tracking-[0.18em] text-black">
        <span>{t.sticky.copyright}</span>
        <span className="hidden sm:inline">{t.sticky.version}</span>
        <span>
          {t.contact.madeWith}{" "}
          <span className={isRTL ? "fa-serif" : "font-serif-display italic"}>
            {t.contact.madeWithAccent}
          </span>
        </span>
      </div>
    </section>
  );
}

/**
 * ContactDial — the signature circular graphic of the contact section:
 * a thin circle outline containing a black mask-head silhouette,
 * surrounded by smaller circular "buttons" (some with @ symbol, some solid).
 */
function ContactDial() {
  // 8 satellite buttons arranged around the dial
  const satellites = Array.from({ length: 8 }, (_, i) => {
    const angle = (i / 8) * Math.PI * 2 - Math.PI / 2;
    const r = 46; // % from center
    return {
      x: 50 + Math.cos(angle) * r,
      y: 50 + Math.sin(angle) * r,
      hasSymbol: i % 3 === 0, // every 3rd button has @ symbol
      solid: i % 4 === 0,
    };
  });

  return (
    <div className="relative w-[min(70vw,38rem)] aspect-square">
      {/* Thin circle outline */}
      <div className="absolute inset-0 rounded-full border border-black/40" />

      {/* Inner thin circle */}
      <div className="absolute inset-[12%] rounded-full border border-black/15" />

      {/* Satellite buttons around the dial */}
      {satellites.map((s, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, scale: 0.5 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, delay: i * 0.05 }}
          style={{ left: `${s.x}%`, top: `${s.y}%` }}
          className="absolute -translate-x-1/2 -translate-y-1/2"
        >
          <div
            className={`flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10 rounded-full border border-black/40 text-[10px] ${
              s.solid ? "bg-black text-[#E31E24]" : "bg-transparent text-black/60"
            }`}
          >
            {s.hasSymbol ? "@" : ""}
          </div>
        </motion.div>
      ))}

      {/* Center: black mask-head silhouette */}
      <div className="absolute inset-[28%] flex items-center justify-center">
        <svg viewBox="0 0 100 100" className="w-full h-full">
          {/* Organic blob head */}
          <path
            d="M 28 22
               C 14 26, 8 42, 12 58
               C 16 74, 30 86, 50 84
               C 70 82, 88 70, 88 48
               C 88 28, 72 14, 52 14
               C 42 14, 34 18, 28 22 Z"
            fill="black"
          />
          {/* Left eye */}
          <circle cx="38" cy="48" r="5" fill="#E31E24" />
          {/* Right eye */}
          <circle cx="62" cy="48" r="5" fill="#E31E24" />
          {/* Eye connector bar */}
          <rect x="38" y="46" width="24" height="2" fill="#E31E24" />
        </svg>
      </div>
    </div>
  );
}
