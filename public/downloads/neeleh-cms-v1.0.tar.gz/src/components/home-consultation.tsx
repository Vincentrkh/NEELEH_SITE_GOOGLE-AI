import { db } from "@/lib/db";
import { getSiteSettings } from "@/lib/settings";
import { LeadForm } from "@/components/lead-form";
import { faNumber } from "@/lib/format";

export const dynamic = "force-dynamic";

/**
 * Consultation Section — بخش مشاوره رایگان با فرم لید.
 * محتوای متنی (عنوان، توضیحات، آمار) از تنظیمات دیتابیس خوانده می‌شود.
 */
export async function ConsultationSection() {
  const settings = await getSiteSettings();
  let leadsCount = 0;
  try {
    leadsCount = await db.lead.count();
  } catch {
    // اگر دیتابیس در دسترس نبود
  }

  return (
    <section id="consult" className="border-t border-border bg-secondary/30 scroll-mt-20">
      <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12 py-16 sm:py-24">
        <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-10 lg:gap-16">
          {/* Text column */}
          <div>
            <p className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground mb-3">
              [ مشاوره رایگان ]
            </p>
            <h2 className="text-3xl sm:text-5xl font-medium tracking-[-0.03em] leading-tight mb-6">
              مسیر خود را
              <br />
              با هم بچینیم
            </h2>
            <p className="text-base leading-relaxed text-muted-foreground max-w-md mb-8">
              مطمئن نیستید کدام دوره مناسب شماست؟ شماره‌تان را بگذارید؛ در یک
              جلسه کوتاه تلفنی، بر اساس سوابق و هدف شغلی‌تان مسیر پیشنهادی را
              می‌چینیم.
            </p>

            {/* Benefits */}
            <ul className="space-y-3 text-sm text-muted-foreground mb-8">
              {[
                "بررسی سوابق تحصیلی و رشته شما",
                "پیشنهاد لایه و دوره مناسب",
                "اطلاع از تاریخ شروع کلاس‌ها و ظرفیت",
              ].map((t) => (
                <li key={t} className="flex items-start gap-2">
                  <span className="mt-1.5 size-1.5 rounded-full bg-foreground shrink-0" />
                  <span className="leading-7">{t}</span>
                </li>
              ))}
            </ul>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4 pt-6 border-t border-border">
              <div>
                <div className="text-2xl font-medium tabular-nums">
                  {faNumber(300 + leadsCount)}+
                </div>
                <div className="text-xs text-muted-foreground mt-1">
                  نفر از مشاوره استفاده کرده‌اند
                </div>
              </div>
              <div>
                <div className="text-2xl font-medium tabular-nums">
                  {settings["stats.years"]}
                </div>
                <div className="text-xs text-muted-foreground mt-1">
                  سال تجربه حرفه‌ای
                </div>
              </div>
            </div>
          </div>

          {/* Form column */}
          <LeadForm />
        </div>
      </div>
    </section>
  );
}
