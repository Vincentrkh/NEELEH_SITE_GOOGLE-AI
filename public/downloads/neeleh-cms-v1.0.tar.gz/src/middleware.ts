import { NextResponse, type NextRequest } from "next/server";

/**
 * Middleware سبک برای:
 * ۱) هدایت کاربر لاگین‌نشده از /dashboard به /login.
 * ۲) هدایت کاربر لاگین‌شده از /login به /dashboard.
 *
 * برای تأیید اعتبار توکن فقط بررسی ساختار می‌کنیم (signature در Server Component
 * دقیق‌تر تأیید می‌شود). اگر توکن نامعتبر به نظر برسد، کوکی را پاک می‌کنیم.
 *
 * توجه: این middleware فقط هدایت می‌کند؛ auth اصلی در getCurrentUser انجام می‌شود.
 * بررسی کامل signature اینجا انجام نمی‌شود تا از Edge runtime محدودیت‌ها (عدم
 * پشتیبانی از Node.js crypto) جلوگیری کنیم — در عوض، getCurrentUser در lib/auth.ts
 * اعتبارسنجی را با HMAC انجام می‌دهد.
 */

const COOKIE_NAME = "neeleh_session";

function hasValidCookieShape(token: string | undefined): boolean {
  if (!token) return false;
  // فقط بررسی ساختار: payload.signature که هر دو non-empty باشند
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return false;
  // payload باید base64url یک JSON معتبر باشد — بررسی طول کوتاه
  try {
    const json = JSON.parse(
      Buffer.from(payload, "base64url").toString()
    ) as { uid?: string; iat?: number };
    if (!json.uid || !json.iat) return false;
    // منقضی شده؟
    const TTL_MS = 60 * 60 * 24 * 30 * 1000; // ۳۰ روز
    if (Date.now() - json.iat > TTL_MS) return false;
    return true;
  } catch {
    return false;
  }
}

export function middleware(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  const path = req.nextUrl.pathname;
  const isAuthPage = path === "/login";
  const isDashboard = path.startsWith("/dashboard");
  const isPanel = path.startsWith("/panel");

  // اگر کوکی نامعتبر است (از نظر ساختار)، پاکش می‌کنیم
  const loggedIn = hasValidCookieShape(token);
  if (token && !loggedIn) {
    const res = NextResponse.next();
    res.cookies.delete(COOKIE_NAME);
    if (isDashboard) {
      return NextResponse.redirect(new URL(`/login?next=${path}`, req.url));
    }
    if (isPanel) {
      return NextResponse.redirect(new URL("/login?next=/panel", req.url));
    }
    return res;
  }

  // اگر لاگین است و می‌خواهد به /login برود → به /dashboard
  if (loggedIn && isAuthPage) {
    return NextResponse.redirect(new URL("/dashboard", req.url));
  }

  // اگر لاگین نیست و می‌خواهد به /dashboard یا /panel برود → به /login
  if (!loggedIn && (isDashboard || isPanel)) {
    const next = isDashboard ? path : "/panel";
    return NextResponse.redirect(new URL(`/login?next=${next}`, req.url));
  }

  return NextResponse.next();
}

export const config = {
  // فقط مسیرهای نیازدار auth را پردازش کن — کل سایت نه، چون صفحه اصلی
  // هیچ وابستگی به auth ندارد و پردازش middleware اضافه‌اش می‌کند.
  matcher: ["/dashboard/:path*", "/panel/:path*", "/login"],
};
